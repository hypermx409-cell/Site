/**
 * ZenithzCloud Central Pricing Data
 * Source: https://zenithzcloud.com/ (live website inspection)
 * Last verified: 2026-10-26
 * 
 * NOTE: The live website was not accessible during development.
 * All data below is based on the master prompt specifications.
 * Items marked with `verified: false` need confirmation from the live site.
 */

export type CPUFamily = 
  | 'intel-xeon-v4'
  | 'amd-epyc-7f72'
  | 'intel-xeon-platinum'
  | 'amd-ryzen-9'
  | 'amd-ryzen-9000'
  | 'amd-epyc-7f72-vps'
  | 'dedicated-ryzen-9'
  | 'dedicated-epyc-7f72'
  | 'bot-epyc-7f72';

export type StorageType = 'Gen 5 SSD' | 'Gen 5 SATA SSD' | 'NVMe SSD' | 'Gen 5 NVMe';

export type Location = 
  | 'india'
  | 'germany'
  | 'singapore'
  | 'tokyo'
  | 'uae'
  | 'london'
  | 'turkey'
  | 'netherlands'
  | 'france'
  | 'usa'
  | 'australia'
  | 'brazil';

export type ServiceCategory = 'minecraft' | 'vps' | 'dedicated' | 'bot' | 'games';

export interface BasePlan {
  id: string;
  name: string;
  cpuFamily: CPUFamily;
  cpuModel: string;
  ramGB: number;
  storageGB: number;
  storageType: StorageType;
  vCores: number;
  priceMonthlyINR: number;
  bandwidth: string;
  locations: Location[];
  features: string[];
  verified: boolean;
  orderUrl?: string;
  badge?: 'popular' | 'best-value' | 'new' | 'coming-soon';
}

export interface MinecraftPlan extends BasePlan {
  category?: 'minecraft';
  ramOptions: number[];
}

export interface VPSPlan extends BasePlan {
  category?: 'vps';
  osOptions: string[];
}

export interface DedicatedPlan extends BasePlan {
  category?: 'dedicated';
}

export interface BotHostingPlan extends BasePlan {
  category?: 'bot';
  runtimes: string[];
}

export type AnyPlan = MinecraftPlan | VPSPlan | DedicatedPlan | BotHostingPlan;

export const CPU_FAMILIES: Record<CPUFamily, {
  name: string;
  description: string;
  category: ServiceCategory[];
}> = {
  'intel-xeon-v4': {
    name: 'Intel Xeon v4',
    description: 'Cost-effective Intel architecture for general workloads',
    category: ['minecraft'],
  },
  'amd-epyc-7f72': {
    name: 'AMD EPYC 7F72',
    description: 'High-frequency EPYC for demanding game servers',
    category: ['minecraft', 'bot'],
  },
  'intel-xeon-platinum': {
    name: 'Intel Xeon Platinum',
    description: 'Premium Intel Xeon Scalable for maximum performance',
    category: ['minecraft'],
  },
  'amd-ryzen-9': {
    name: 'AMD Ryzen 9',
    description: 'High-clock Ryzen 9 for single-threaded performance',
    category: ['minecraft'],
  },
  'amd-ryzen-9000': {
    name: 'AMD Ryzen 9000 Series',
    description: 'Latest Zen 5 architecture for VPS workloads',
    category: ['vps'],
  },
  'amd-epyc-7f72-vps': {
    name: 'AMD EPYC 7F72',
    description: 'Enterprise EPYC for VPS hosting',
    category: ['vps'],
  },
  'dedicated-ryzen-9': {
    name: 'AMD Ryzen 9',
    description: 'Ryzen 9 dedicated bare metal',
    category: ['dedicated'],
  },
  'dedicated-epyc-7f72': {
    name: 'AMD EPYC 7F72',
    description: 'EPYC 7F72 dedicated bare metal',
    category: ['dedicated'],
  },
  'bot-epyc-7f72': {
    name: 'AMD EPYC 7F72',
    description: 'Optimized for Discord bot workloads',
    category: ['bot'],
  },
};

export const LOCATIONS_DATA: Record<Location, {
  name: string;
  country: string;
  flag: string;
  status: 'available' | 'advertised' | 'coming-soon';
  latencyMs?: number;
  latencyVerified: boolean;
  providerType: 'owned' | 'rented' | 'unknown';
}> = {
  india: {
    name: 'Mumbai',
    country: 'India',
    flag: '🇮🇳',
    status: 'available',
    latencyMs: 29,
    latencyVerified: false,
    providerType: 'owned',
  },
  germany: {
    name: 'Frankfurt',
    country: 'Germany',
    flag: '🇩🇪',
    status: 'advertised',
    latencyMs: 39,
    latencyVerified: false,
    providerType: 'rented',
  },
  singapore: {
    name: 'Singapore',
    country: 'Singapore',
    flag: '🇸🇬',
    status: 'advertised',
    latencyMs: 45,
    latencyVerified: false,
    providerType: 'rented',
  },
  tokyo: {
    name: 'Tokyo',
    country: 'Japan',
    flag: '🇯🇵',
    status: 'coming-soon',
    latencyVerified: false,
    providerType: 'unknown',
  },
  uae: {
    name: 'Dubai',
    country: 'UAE',
    flag: '🇦🇪',
    status: 'coming-soon',
    latencyVerified: false,
    providerType: 'unknown',
  },
  london: {
    name: 'London',
    country: 'UK',
    flag: '🇬🇧',
    status: 'coming-soon',
    latencyVerified: false,
    providerType: 'unknown',
  },
  turkey: {
    name: 'Istanbul',
    country: 'Turkey',
    flag: '🇹🇷',
    status: 'coming-soon',
    latencyVerified: false,
    providerType: 'unknown',
  },
  netherlands: {
    name: 'Amsterdam',
    country: 'Netherlands',
    flag: '🇳🇱',
    status: 'coming-soon',
    latencyVerified: false,
    providerType: 'unknown',
  },
  france: {
    name: 'Paris',
    country: 'France',
    flag: '🇫🇷',
    status: 'coming-soon',
    latencyVerified: false,
    providerType: 'unknown',
  },
  usa: {
    name: 'New York',
    country: 'USA',
    flag: '🇺🇸',
    status: 'coming-soon',
    latencyVerified: false,
    providerType: 'unknown',
  },
  australia: {
    name: 'Sydney',
    country: 'Australia',
    flag: '🇦🇺',
    status: 'coming-soon',
    latencyVerified: false,
    providerType: 'unknown',
  },
  brazil: {
    name: 'São Paulo',
    country: 'Brazil',
    flag: '🇧🇷',
    status: 'coming-soon',
    latencyVerified: false,
    providerType: 'unknown',
  },
};

export const COMMON_MINECRAFT_FEATURES = [
  'DDR4 RAM',
  'Gen 5 SATA SSD',
  'Unlimited Bandwidth',
  'DDoS Protection',
  '24/7 Uptime & Support',
  'Custom Minecraft Control Panel',
  'Plugin & Mod Management',
  'One-Click Add-ons',
  'Automatic Recovery & Backups',
  'Resource Scaling',
  'Multiple Server Locations',
  'Vanilla, Paper, Spigot, Forge, Fabric',
  'All Major Minecraft Versions',
  'Plan Upgrades & Location Selection',
];

const COMMON_VPS_FEATURES = [
  'DDR4 RAM',
  'Gen 5 NVMe Storage',
  'Unlimited Bandwidth',
  'DDoS Protection',
  'India Location (Ryzen 9000)',
  'Root & SSH Access',
  'Browser Console',
  'Start, Stop, Restart Controls',
  'OS Reinstall',
  'Snapshots & Backups',
  'Resource Monitoring',
  'Network & IP Information',
  'Operating System Selection',
];

export const VPS_OS_OPTIONS = [
  'Ubuntu',
  'Windows',
  'Fedora',
  'Debian',
  'Kali Linux',
  'Custom ISO',
];

const COMMON_DEDICATED_FEATURES = [
  'Dedicated Bare-Metal Hosting',
  'India Location',
  'DDR4 RAM',
  'Gen 5 SSD',
  'Unlimited Bandwidth',
  'Free Backups',
  'Root Access',
  'Priority Support',
  'DDoS Protection',
];

const COMMON_BOT_FEATURES = [
  'NVMe SSD Storage',
  'Unlimited Bandwidth',
  'Network Protection',
  '24/7 Hosting',
  'India, Germany, Singapore Locations',
];

export const MINECRAFT_PLANS: MinecraftPlan[] = [
  // AMD EPYC 7F72 Plans
  { id: 'mc-epyc-2gb', name: '2 GB', cpuFamily: 'amd-epyc-7f72', cpuModel: 'AMD EPYC 7F72', ramGB: 2, storageGB: 5, storageType: 'Gen 5 SATA SSD', vCores: 1, priceMonthlyINR: 118, bandwidth: 'Unlimited', locations: ['india', 'germany', 'singapore'], features: COMMON_MINECRAFT_FEATURES, verified: false, ramOptions: [2,4,6,8,12,16,24,32,48,64,96,128,160,192,224,256] },
  { id: 'mc-epyc-4gb', name: '4 GB', cpuFamily: 'amd-epyc-7f72', cpuModel: 'AMD EPYC 7F72', ramGB: 4, storageGB: 10, storageType: 'Gen 5 SATA SSD', vCores: 2, priceMonthlyINR: 236, bandwidth: 'Unlimited', locations: ['india', 'germany', 'singapore'], features: COMMON_MINECRAFT_FEATURES, verified: false, ramOptions: [2,4,6,8,12,16,24,32,48,64,96,128,160,192,224,256] },
  { id: 'mc-epyc-6gb', name: '6 GB', cpuFamily: 'amd-epyc-7f72', cpuModel: 'AMD EPYC 7F72', ramGB: 6, storageGB: 15, storageType: 'Gen 5 SATA SSD', vCores: 2, priceMonthlyINR: 354, bandwidth: 'Unlimited', locations: ['india', 'germany', 'singapore'], features: COMMON_MINECRAFT_FEATURES, verified: false, ramOptions: [2,4,6,8,12,16,24,32,48,64,96,128,160,192,224,256] },
  { id: 'mc-epyc-8gb', name: '8 GB', cpuFamily: 'amd-epyc-7f72', cpuModel: 'AMD EPYC 7F72', ramGB: 8, storageGB: 20, storageType: 'Gen 5 SATA SSD', vCores: 4, priceMonthlyINR: 472, bandwidth: 'Unlimited', locations: ['india', 'germany', 'singapore'], features: COMMON_MINECRAFT_FEATURES, verified: false, ramOptions: [2,4,6,8,12,16,24,32,48,64,96,128,160,192,224,256] },
  { id: 'mc-epyc-12gb', name: '12 GB', cpuFamily: 'amd-epyc-7f72', cpuModel: 'AMD EPYC 7F72', ramGB: 12, storageGB: 30, storageType: 'Gen 5 SATA SSD', vCores: 6, priceMonthlyINR: 708, bandwidth: 'Unlimited', locations: ['india', 'germany', 'singapore'], features: COMMON_MINECRAFT_FEATURES, verified: false, ramOptions: [2,4,6,8,12,16,24,32,48,64,96,128,160,192,224,256] },
  { id: 'mc-epyc-16gb', name: '16 GB', cpuFamily: 'amd-epyc-7f72', cpuModel: 'AMD EPYC 7F72', ramGB: 16, storageGB: 40, storageType: 'Gen 5 SATA SSD', vCores: 8, priceMonthlyINR: 944, bandwidth: 'Unlimited', locations: ['india', 'germany', 'singapore'], features: COMMON_MINECRAFT_FEATURES, verified: false, ramOptions: [2,4,6,8,12,16,24,32,48,64,96,128,160,192,224,256], badge: 'popular' },
  { id: 'mc-epyc-24gb', name: '24 GB', cpuFamily: 'amd-epyc-7f72', cpuModel: 'AMD EPYC 7F72', ramGB: 24, storageGB: 60, storageType: 'Gen 5 SATA SSD', vCores: 10, priceMonthlyINR: 1416, bandwidth: 'Unlimited', locations: ['india', 'germany', 'singapore'], features: COMMON_MINECRAFT_FEATURES, verified: false, ramOptions: [2,4,6,8,12,16,24,32,48,64,96,128,160,192,224,256] },
  { id: 'mc-epyc-32gb', name: '32 GB', cpuFamily: 'amd-epyc-7f72', cpuModel: 'AMD EPYC 7F72', ramGB: 32, storageGB: 80, storageType: 'Gen 5 SATA SSD', vCores: 12, priceMonthlyINR: 1888, bandwidth: 'Unlimited', locations: ['india', 'germany', 'singapore'], features: COMMON_MINECRAFT_FEATURES, verified: false, ramOptions: [2,4,6,8,12,16,24,32,48,64,96,128,160,192,224,256] },
  { id: 'mc-epyc-48gb', name: '48 GB', cpuFamily: 'amd-epyc-7f72', cpuModel: 'AMD EPYC 7F72', ramGB: 48, storageGB: 120, storageType: 'Gen 5 SATA SSD', vCores: 16, priceMonthlyINR: 2832, bandwidth: 'Unlimited', locations: ['india', 'germany', 'singapore'], features: COMMON_MINECRAFT_FEATURES, verified: false, ramOptions: [2,4,6,8,12,16,24,32,48,64,96,128,160,192,224,256] },
  { id: 'mc-epyc-64gb', name: '64 GB', cpuFamily: 'amd-epyc-7f72', cpuModel: 'AMD EPYC 7F72', ramGB: 64, storageGB: 160, storageType: 'Gen 5 SATA SSD', vCores: 18, priceMonthlyINR: 3776, bandwidth: 'Unlimited', locations: ['india', 'germany', 'singapore'], features: COMMON_MINECRAFT_FEATURES, verified: false, ramOptions: [2,4,6,8,12,16,24,32,48,64,96,128,160,192,224,256] },
  { id: 'mc-epyc-96gb', name: '96 GB', cpuFamily: 'amd-epyc-7f72', cpuModel: 'AMD EPYC 7F72', ramGB: 96, storageGB: 240, storageType: 'Gen 5 SATA SSD', vCores: 20, priceMonthlyINR: 5664, bandwidth: 'Unlimited', locations: ['india', 'germany', 'singapore'], features: COMMON_MINECRAFT_FEATURES, verified: false, ramOptions: [2,4,6,8,12,16,24,32,48,64,96,128,160,192,224,256] },
  { id: 'mc-epyc-128gb', name: '128 GB', cpuFamily: 'amd-epyc-7f72', cpuModel: 'AMD EPYC 7F72', ramGB: 128, storageGB: 320, storageType: 'Gen 5 SATA SSD', vCores: 22, priceMonthlyINR: 7552, bandwidth: 'Unlimited', locations: ['india', 'germany', 'singapore'], features: COMMON_MINECRAFT_FEATURES, verified: false, ramOptions: [2,4,6,8,12,16,24,32,48,64,96,128,160,192,224,256] },
  { id: 'mc-epyc-160gb', name: '160 GB', cpuFamily: 'amd-epyc-7f72', cpuModel: 'AMD EPYC 7F72', ramGB: 160, storageGB: 400, storageType: 'Gen 5 SATA SSD', vCores: 24, priceMonthlyINR: 9440, bandwidth: 'Unlimited', locations: ['india', 'germany', 'singapore'], features: COMMON_MINECRAFT_FEATURES, verified: false, ramOptions: [2,4,6,8,12,16,24,32,48,64,96,128,160,192,224,256] },
  { id: 'mc-epyc-192gb', name: '192 GB', cpuFamily: 'amd-epyc-7f72', cpuModel: 'AMD EPYC 7F72', ramGB: 192, storageGB: 480, storageType: 'Gen 5 SATA SSD', vCores: 24, priceMonthlyINR: 11328, bandwidth: 'Unlimited', locations: ['india', 'germany', 'singapore'], features: COMMON_MINECRAFT_FEATURES, verified: false, ramOptions: [2,4,6,8,12,16,24,32,48,64,96,128,160,192,224,256] },
  { id: 'mc-epyc-224gb', name: '224 GB', cpuFamily: 'amd-epyc-7f72', cpuModel: 'AMD EPYC 7F72', ramGB: 224, storageGB: 560, storageType: 'Gen 5 SATA SSD', vCores: 24, priceMonthlyINR: 13216, bandwidth: 'Unlimited', locations: ['india', 'germany', 'singapore'], features: COMMON_MINECRAFT_FEATURES, verified: false, ramOptions: [2,4,6,8,12,16,24,32,48,64,96,128,160,192,224,256] },
  { id: 'mc-epyc-256gb', name: '256 GB', cpuFamily: 'amd-epyc-7f72', cpuModel: 'AMD EPYC 7F72', ramGB: 256, storageGB: 640, storageType: 'Gen 5 SATA SSD', vCores: 24, priceMonthlyINR: 15104, bandwidth: 'Unlimited', locations: ['india', 'germany', 'singapore'], features: COMMON_MINECRAFT_FEATURES, verified: false, ramOptions: [2,4,6,8,12,16,24,32,48,64,96,128,160,192,224,256] },

  // Intel Xeon v4 Plans (₹29/GB)
  { id: 'mc-xeon-v4-2gb', name: '2 GB', cpuFamily: 'intel-xeon-v4', cpuModel: 'Intel Xeon v4', ramGB: 2, storageGB: 5, storageType: 'Gen 5 SATA SSD', vCores: 1, priceMonthlyINR: 58, bandwidth: 'Unlimited', locations: ['india', 'germany', 'singapore'], features: COMMON_MINECRAFT_FEATURES, verified: false, ramOptions: [2,4,6,8,12,16,24,32,48,64,96,128,160,192,224,256] },
  { id: 'mc-xeon-v4-4gb', name: '4 GB', cpuFamily: 'intel-xeon-v4', cpuModel: 'Intel Xeon v4', ramGB: 4, storageGB: 10, storageType: 'Gen 5 SATA SSD', vCores: 2, priceMonthlyINR: 116, bandwidth: 'Unlimited', locations: ['india', 'germany', 'singapore'], features: COMMON_MINECRAFT_FEATURES, verified: false, ramOptions: [2,4,6,8,12,16,24,32,48,64,96,128,160,192,224,256] },
  { id: 'mc-xeon-v4-6gb', name: '6 GB', cpuFamily: 'intel-xeon-v4', cpuModel: 'Intel Xeon v4', ramGB: 6, storageGB: 15, storageType: 'Gen 5 SATA SSD', vCores: 2, priceMonthlyINR: 174, bandwidth: 'Unlimited', locations: ['india', 'germany', 'singapore'], features: COMMON_MINECRAFT_FEATURES, verified: false, ramOptions: [2,4,6,8,12,16,24,32,48,64,96,128,160,192,224,256] },
  { id: 'mc-xeon-v4-8gb', name: '8 GB', cpuFamily: 'intel-xeon-v4', cpuModel: 'Intel Xeon v4', ramGB: 8, storageGB: 20, storageType: 'Gen 5 SATA SSD', vCores: 4, priceMonthlyINR: 232, bandwidth: 'Unlimited', locations: ['india', 'germany', 'singapore'], features: COMMON_MINECRAFT_FEATURES, verified: false, ramOptions: [2,4,6,8,12,16,24,32,48,64,96,128,160,192,224,256] },
  { id: 'mc-xeon-v4-12gb', name: '12 GB', cpuFamily: 'intel-xeon-v4', cpuModel: 'Intel Xeon v4', ramGB: 12, storageGB: 30, storageType: 'Gen 5 SATA SSD', vCores: 6, priceMonthlyINR: 348, bandwidth: 'Unlimited', locations: ['india', 'germany', 'singapore'], features: COMMON_MINECRAFT_FEATURES, verified: false, ramOptions: [2,4,6,8,12,16,24,32,48,64,96,128,160,192,224,256] },
  { id: 'mc-xeon-v4-16gb', name: '16 GB', cpuFamily: 'intel-xeon-v4', cpuModel: 'Intel Xeon v4', ramGB: 16, storageGB: 40, storageType: 'Gen 5 SATA SSD', vCores: 8, priceMonthlyINR: 464, bandwidth: 'Unlimited', locations: ['india', 'germany', 'singapore'], features: COMMON_MINECRAFT_FEATURES, verified: false, ramOptions: [2,4,6,8,12,16,24,32,48,64,96,128,160,192,224,256], badge: 'best-value' },
  { id: 'mc-xeon-v4-24gb', name: '24 GB', cpuFamily: 'intel-xeon-v4', cpuModel: 'Intel Xeon v4', ramGB: 24, storageGB: 60, storageType: 'Gen 5 SATA SSD', vCores: 10, priceMonthlyINR: 696, bandwidth: 'Unlimited', locations: ['india', 'germany', 'singapore'], features: COMMON_MINECRAFT_FEATURES, verified: false, ramOptions: [2,4,6,8,12,16,24,32,48,64,96,128,160,192,224,256] },
  { id: 'mc-xeon-v4-32gb', name: '32 GB', cpuFamily: 'intel-xeon-v4', cpuModel: 'Intel Xeon v4', ramGB: 32, storageGB: 80, storageType: 'Gen 5 SATA SSD', vCores: 12, priceMonthlyINR: 928, bandwidth: 'Unlimited', locations: ['india', 'germany', 'singapore'], features: COMMON_MINECRAFT_FEATURES, verified: false, ramOptions: [2,4,6,8,12,16,24,32,48,64,96,128,160,192,224,256] },
  { id: 'mc-xeon-v4-48gb', name: '48 GB', cpuFamily: 'intel-xeon-v4', cpuModel: 'Intel Xeon v4', ramGB: 48, storageGB: 120, storageType: 'Gen 5 SATA SSD', vCores: 16, priceMonthlyINR: 1392, bandwidth: 'Unlimited', locations: ['india', 'germany', 'singapore'], features: COMMON_MINECRAFT_FEATURES, verified: false, ramOptions: [2,4,6,8,12,16,24,32,48,64,96,128,160,192,224,256] },
  { id: 'mc-xeon-v4-64gb', name: '64 GB', cpuFamily: 'intel-xeon-v4', cpuModel: 'Intel Xeon v4', ramGB: 64, storageGB: 160, storageType: 'Gen 5 SATA SSD', vCores: 18, priceMonthlyINR: 1856, bandwidth: 'Unlimited', locations: ['india', 'germany', 'singapore'], features: COMMON_MINECRAFT_FEATURES, verified: false, ramOptions: [2,4,6,8,12,16,24,32,48,64,96,128,160,192,224,256] },
  { id: 'mc-xeon-v4-96gb', name: '96 GB', cpuFamily: 'intel-xeon-v4', cpuModel: 'Intel Xeon v4', ramGB: 96, storageGB: 240, storageType: 'Gen 5 SATA SSD', vCores: 20, priceMonthlyINR: 2784, bandwidth: 'Unlimited', locations: ['india', 'germany', 'singapore'], features: COMMON_MINECRAFT_FEATURES, verified: false, ramOptions: [2,4,6,8,12,16,24,32,48,64,96,128,160,192,224,256] },
  { id: 'mc-xeon-v4-128gb', name: '128 GB', cpuFamily: 'intel-xeon-v4', cpuModel: 'Intel Xeon v4', ramGB: 128, storageGB: 320, storageType: 'Gen 5 SATA SSD', vCores: 22, priceMonthlyINR: 3712, bandwidth: 'Unlimited', locations: ['india', 'germany', 'singapore'], features: COMMON_MINECRAFT_FEATURES, verified: false, ramOptions: [2,4,6,8,12,16,24,32,48,64,96,128,160,192,224,256] },
  { id: 'mc-xeon-v4-160gb', name: '160 GB', cpuFamily: 'intel-xeon-v4', cpuModel: 'Intel Xeon v4', ramGB: 160, storageGB: 400, storageType: 'Gen 5 SATA SSD', vCores: 24, priceMonthlyINR: 4640, bandwidth: 'Unlimited', locations: ['india', 'germany', 'singapore'], features: COMMON_MINECRAFT_FEATURES, verified: false, ramOptions: [2,4,6,8,12,16,24,32,48,64,96,128,160,192,224,256] },
  { id: 'mc-xeon-v4-192gb', name: '192 GB', cpuFamily: 'intel-xeon-v4', cpuModel: 'Intel Xeon v4', ramGB: 192, storageGB: 480, storageType: 'Gen 5 SATA SSD', vCores: 24, priceMonthlyINR: 5568, bandwidth: 'Unlimited', locations: ['india', 'germany', 'singapore'], features: COMMON_MINECRAFT_FEATURES, verified: false, ramOptions: [2,4,6,8,12,16,24,32,48,64,96,128,160,192,224,256] },
  { id: 'mc-xeon-v4-224gb', name: '224 GB', cpuFamily: 'intel-xeon-v4', cpuModel: 'Intel Xeon v4', ramGB: 224, storageGB: 560, storageType: 'Gen 5 SATA SSD', vCores: 24, priceMonthlyINR: 6496, bandwidth: 'Unlimited', locations: ['india', 'germany', 'singapore'], features: COMMON_MINECRAFT_FEATURES, verified: false, ramOptions: [2,4,6,8,12,16,24,32,48,64,96,128,160,192,224,256] },
  { id: 'mc-xeon-v4-256gb', name: '256 GB', cpuFamily: 'intel-xeon-v4', cpuModel: 'Intel Xeon v4', ramGB: 256, storageGB: 640, storageType: 'Gen 5 SATA SSD', vCores: 24, priceMonthlyINR: 7424, bandwidth: 'Unlimited', locations: ['india', 'germany', 'singapore'], features: COMMON_MINECRAFT_FEATURES, verified: false, ramOptions: [2,4,6,8,12,16,24,32,48,64,96,128,160,192,224,256] },

  // Intel Xeon Platinum (₹69/GB) - vCPU allocations need verification
  { id: 'mc-xeon-platinum-2gb', name: '2 GB', cpuFamily: 'intel-xeon-platinum', cpuModel: 'Intel Xeon Platinum', ramGB: 2, storageGB: 5, storageType: 'Gen 5 SATA SSD', vCores: 1, priceMonthlyINR: 138, bandwidth: 'Unlimited', locations: ['india', 'germany', 'singapore'], features: COMMON_MINECRAFT_FEATURES, verified: false, ramOptions: [2,4,6,8,12,16,24,32,48,64,96,128,160,192,224,256] },
  { id: 'mc-xeon-platinum-4gb', name: '4 GB', cpuFamily: 'intel-xeon-platinum', cpuModel: 'Intel Xeon Platinum', ramGB: 4, storageGB: 10, storageType: 'Gen 5 SATA SSD', vCores: 2, priceMonthlyINR: 276, bandwidth: 'Unlimited', locations: ['india', 'germany', 'singapore'], features: COMMON_MINECRAFT_FEATURES, verified: false, ramOptions: [2,4,6,8,12,16,24,32,48,64,96,128,160,192,224,256] },
  { id: 'mc-xeon-platinum-8gb', name: '8 GB', cpuFamily: 'intel-xeon-platinum', cpuModel: 'Intel Xeon Platinum', ramGB: 8, storageGB: 20, storageType: 'Gen 5 SATA SSD', vCores: 4, priceMonthlyINR: 552, bandwidth: 'Unlimited', locations: ['india', 'germany', 'singapore'], features: COMMON_MINECRAFT_FEATURES, verified: false, ramOptions: [2,4,6,8,12,16,24,32,48,64,96,128,160,192,224,256] },
  { id: 'mc-xeon-platinum-16gb', name: '16 GB', cpuFamily: 'intel-xeon-platinum', cpuModel: 'Intel Xeon Platinum', ramGB: 16, storageGB: 40, storageType: 'Gen 5 SATA SSD', vCores: 8, priceMonthlyINR: 1104, bandwidth: 'Unlimited', locations: ['india', 'germany', 'singapore'], features: COMMON_MINECRAFT_FEATURES, verified: false, ramOptions: [2,4,6,8,12,16,24,32,48,64,96,128,160,192,224,256] },
  { id: 'mc-xeon-platinum-32gb', name: '32 GB', cpuFamily: 'intel-xeon-platinum', cpuModel: 'Intel Xeon Platinum', ramGB: 32, storageGB: 80, storageType: 'Gen 5 SATA SSD', vCores: 12, priceMonthlyINR: 2208, bandwidth: 'Unlimited', locations: ['india', 'germany', 'singapore'], features: COMMON_MINECRAFT_FEATURES, verified: false, ramOptions: [2,4,6,8,12,16,24,32,48,64,96,128,160,192,224,256] },
  { id: 'mc-xeon-platinum-64gb', name: '64 GB', cpuFamily: 'intel-xeon-platinum', cpuModel: 'Intel Xeon Platinum', ramGB: 64, storageGB: 160, storageType: 'Gen 5 SATA SSD', vCores: 18, priceMonthlyINR: 4416, bandwidth: 'Unlimited', locations: ['india', 'germany', 'singapore'], features: COMMON_MINECRAFT_FEATURES, verified: false, ramOptions: [2,4,6,8,12,16,24,32,48,64,96,128,160,192,224,256] },
  { id: 'mc-xeon-platinum-128gb', name: '128 GB', cpuFamily: 'intel-xeon-platinum', cpuModel: 'Intel Xeon Platinum', ramGB: 128, storageGB: 320, storageType: 'Gen 5 SATA SSD', vCores: 22, priceMonthlyINR: 8832, bandwidth: 'Unlimited', locations: ['india', 'germany', 'singapore'], features: COMMON_MINECRAFT_FEATURES, verified: false, ramOptions: [2,4,6,8,12,16,24,32,48,64,96,128,160,192,224,256] },
  { id: 'mc-xeon-platinum-256gb', name: '256 GB', cpuFamily: 'intel-xeon-platinum', cpuModel: 'Intel Xeon Platinum', ramGB: 256, storageGB: 640, storageType: 'Gen 5 SATA SSD', vCores: 24, priceMonthlyINR: 17664, bandwidth: 'Unlimited', locations: ['india', 'germany', 'singapore'], features: COMMON_MINECRAFT_FEATURES, verified: false, ramOptions: [2,4,6,8,12,16,24,32,48,64,96,128,160,192,224,256] },

  // AMD Ryzen 9 (₹189/GB) - vCPU allocations need verification
  { id: 'mc-ryzen9-2gb', name: '2 GB', cpuFamily: 'amd-ryzen-9', cpuModel: 'AMD Ryzen 9', ramGB: 2, storageGB: 5, storageType: 'Gen 5 SATA SSD', vCores: 1, priceMonthlyINR: 378, bandwidth: 'Unlimited', locations: ['india', 'germany', 'singapore'], features: COMMON_MINECRAFT_FEATURES, verified: false, ramOptions: [2,4,6,8,12,16,24,32,48,64,96,128,160,192,224,256] },
  { id: 'mc-ryzen9-4gb', name: '4 GB', cpuFamily: 'amd-ryzen-9', cpuModel: 'AMD Ryzen 9', ramGB: 4, storageGB: 10, storageType: 'Gen 5 SATA SSD', vCores: 2, priceMonthlyINR: 756, bandwidth: 'Unlimited', locations: ['india', 'germany', 'singapore'], features: COMMON_MINECRAFT_FEATURES, verified: false, ramOptions: [2,4,6,8,12,16,24,32,48,64,96,128,160,192,224,256] },
  { id: 'mc-ryzen9-8gb', name: '8 GB', cpuFamily: 'amd-ryzen-9', cpuModel: 'AMD Ryzen 9', ramGB: 8, storageGB: 20, storageType: 'Gen 5 SATA SSD', vCores: 4, priceMonthlyINR: 1512, bandwidth: 'Unlimited', locations: ['india', 'germany', 'singapore'], features: COMMON_MINECRAFT_FEATURES, verified: false, ramOptions: [2,4,6,8,12,16,24,32,48,64,96,128,160,192,224,256] },
  { id: 'mc-ryzen9-16gb', name: '16 GB', cpuFamily: 'amd-ryzen-9', cpuModel: 'AMD Ryzen 9', ramGB: 16, storageGB: 40, storageType: 'Gen 5 SATA SSD', vCores: 8, priceMonthlyINR: 3024, bandwidth: 'Unlimited', locations: ['india', 'germany', 'singapore'], features: COMMON_MINECRAFT_FEATURES, verified: false, ramOptions: [2,4,6,8,12,16,24,32,48,64,96,128,160,192,224,256] },
  { id: 'mc-ryzen9-32gb', name: '32 GB', cpuFamily: 'amd-ryzen-9', cpuModel: 'AMD Ryzen 9', ramGB: 32, storageGB: 80, storageType: 'Gen 5 SATA SSD', vCores: 12, priceMonthlyINR: 6048, bandwidth: 'Unlimited', locations: ['india', 'germany', 'singapore'], features: COMMON_MINECRAFT_FEATURES, verified: false, ramOptions: [2,4,6,8,12,16,24,32,48,64,96,128,160,192,224,256] },
  { id: 'mc-ryzen9-64gb', name: '64 GB', cpuFamily: 'amd-ryzen-9', cpuModel: 'AMD Ryzen 9', ramGB: 64, storageGB: 160, storageType: 'Gen 5 SATA SSD', vCores: 16, priceMonthlyINR: 12096, bandwidth: 'Unlimited', locations: ['india', 'germany', 'singapore'], features: COMMON_MINECRAFT_FEATURES, verified: false, ramOptions: [2,4,6,8,12,16,24,32,48,64,96,128,160,192,224,256] },
  { id: 'mc-ryzen9-128gb', name: '128 GB', cpuFamily: 'amd-ryzen-9', cpuModel: 'AMD Ryzen 9', ramGB: 128, storageGB: 320, storageType: 'Gen 5 SATA SSD', vCores: 22, priceMonthlyINR: 24192, bandwidth: 'Unlimited', locations: ['india', 'germany', 'singapore'], features: COMMON_MINECRAFT_FEATURES, verified: false, ramOptions: [2,4,6,8,12,16,24,32,48,64,96,128,160,192,224,256] },
  { id: 'mc-ryzen9-256gb', name: '256 GB', cpuFamily: 'amd-ryzen-9', cpuModel: 'AMD Ryzen 9', ramGB: 256, storageGB: 640, storageType: 'Gen 5 SATA SSD', vCores: 24, priceMonthlyINR: 48384, bandwidth: 'Unlimited', locations: ['india', 'germany', 'singapore'], features: COMMON_MINECRAFT_FEATURES, verified: false, ramOptions: [2,4,6,8,12,16,24,32,48,64,96,128,160,192,224,256] },
];

export const VPS_PLANS: VPSPlan[] = [
  // AMD Ryzen 9000 Series (₹179/GB)
  { id: 'vps-ryzen9000-4gb', name: '4 GB', cpuFamily: 'amd-ryzen-9000', cpuModel: 'AMD Ryzen 9000 Series', ramGB: 4, storageGB: 60, storageType: 'Gen 5 NVMe', vCores: 2, priceMonthlyINR: 717, bandwidth: 'Unlimited', locations: ['india'], features: COMMON_VPS_FEATURES, verified: false, osOptions: VPS_OS_OPTIONS, badge: 'popular' },
  { id: 'vps-ryzen9000-6gb', name: '6 GB', cpuFamily: 'amd-ryzen-9000', cpuModel: 'AMD Ryzen 9000 Series', ramGB: 6, storageGB: 90, storageType: 'Gen 5 NVMe', vCores: 3, priceMonthlyINR: 1077, bandwidth: 'Unlimited', locations: ['india'], features: COMMON_VPS_FEATURES, verified: false, osOptions: VPS_OS_OPTIONS },
  { id: 'vps-ryzen9000-8gb', name: '8 GB', cpuFamily: 'amd-ryzen-9000', cpuModel: 'AMD Ryzen 9000 Series', ramGB: 8, storageGB: 120, storageType: 'Gen 5 NVMe', vCores: 4, priceMonthlyINR: 1436, bandwidth: 'Unlimited', locations: ['india'], features: COMMON_VPS_FEATURES, verified: false, osOptions: VPS_OS_OPTIONS },
  { id: 'vps-ryzen9000-10gb', name: '10 GB', cpuFamily: 'amd-ryzen-9000', cpuModel: 'AMD Ryzen 9000 Series', ramGB: 10, storageGB: 150, storageType: 'Gen 5 NVMe', vCores: 4, priceMonthlyINR: 1794, bandwidth: 'Unlimited', locations: ['india'], features: COMMON_VPS_FEATURES, verified: false, osOptions: VPS_OS_OPTIONS },
  { id: 'vps-ryzen9000-12gb', name: '12 GB', cpuFamily: 'amd-ryzen-9000', cpuModel: 'AMD Ryzen 9000 Series', ramGB: 12, storageGB: 180, storageType: 'Gen 5 NVMe', vCores: 5, priceMonthlyINR: 2153, bandwidth: 'Unlimited', locations: ['india'], features: COMMON_VPS_FEATURES, verified: false, osOptions: VPS_OS_OPTIONS },
  { id: 'vps-ryzen9000-14gb', name: '14 GB', cpuFamily: 'amd-ryzen-9000', cpuModel: 'AMD Ryzen 9000 Series', ramGB: 14, storageGB: 210, storageType: 'Gen 5 NVMe', vCores: 5, priceMonthlyINR: 2513, bandwidth: 'Unlimited', locations: ['india'], features: COMMON_VPS_FEATURES, verified: false, osOptions: VPS_OS_OPTIONS },
  { id: 'vps-ryzen9000-16gb', name: '16 GB', cpuFamily: 'amd-ryzen-9000', cpuModel: 'AMD Ryzen 9000 Series', ramGB: 16, storageGB: 240, storageType: 'Gen 5 NVMe', vCores: 6, priceMonthlyINR: 2871, bandwidth: 'Unlimited', locations: ['india'], features: COMMON_VPS_FEATURES, verified: false, osOptions: VPS_OS_OPTIONS },
  { id: 'vps-ryzen9000-20gb', name: '20 GB', cpuFamily: 'amd-ryzen-9000', cpuModel: 'AMD Ryzen 9000 Series', ramGB: 20, storageGB: 300, storageType: 'Gen 5 NVMe', vCores: 7, priceMonthlyINR: 3588, bandwidth: 'Unlimited', locations: ['india'], features: COMMON_VPS_FEATURES, verified: false, osOptions: VPS_OS_OPTIONS },
  { id: 'vps-ryzen9000-24gb', name: '24 GB', cpuFamily: 'amd-ryzen-9000', cpuModel: 'AMD Ryzen 9000 Series', ramGB: 24, storageGB: 360, storageType: 'Gen 5 NVMe', vCores: 7, priceMonthlyINR: 4307, bandwidth: 'Unlimited', locations: ['india'], features: COMMON_VPS_FEATURES, verified: false, osOptions: VPS_OS_OPTIONS },
  { id: 'vps-ryzen9000-32gb', name: '32 GB', cpuFamily: 'amd-ryzen-9000', cpuModel: 'AMD Ryzen 9000 Series', ramGB: 32, storageGB: 480, storageType: 'Gen 5 NVMe', vCores: 8, priceMonthlyINR: 5742, bandwidth: 'Unlimited', locations: ['india'], features: COMMON_VPS_FEATURES, verified: false, osOptions: VPS_OS_OPTIONS },

  // AMD EPYC 7F72 VPS - Need to fetch actual matrix from live site
  // Placeholder plans - marked as unverified
  { id: 'vps-epyc-4gb', name: '4 GB', cpuFamily: 'amd-epyc-7f72-vps', cpuModel: 'AMD EPYC 7F72', ramGB: 4, storageGB: 60, storageType: 'Gen 5 NVMe', vCores: 2, priceMonthlyINR: 576, bandwidth: 'Unlimited', locations: ['india', 'germany', 'singapore'], features: COMMON_VPS_FEATURES, verified: false, osOptions: VPS_OS_OPTIONS },
  { id: 'vps-epyc-8gb', name: '8 GB', cpuFamily: 'amd-epyc-7f72-vps', cpuModel: 'AMD EPYC 7F72', ramGB: 8, storageGB: 120, storageType: 'Gen 5 NVMe', vCores: 4, priceMonthlyINR: 1152, bandwidth: 'Unlimited', locations: ['india', 'germany', 'singapore'], features: COMMON_VPS_FEATURES, verified: false, osOptions: VPS_OS_OPTIONS },
  { id: 'vps-epyc-16gb', name: '16 GB', cpuFamily: 'amd-epyc-7f72-vps', cpuModel: 'AMD EPYC 7F72', ramGB: 16, storageGB: 240, storageType: 'Gen 5 NVMe', vCores: 8, priceMonthlyINR: 2304, bandwidth: 'Unlimited', locations: ['india', 'germany', 'singapore'], features: COMMON_VPS_FEATURES, verified: false, osOptions: VPS_OS_OPTIONS },
  { id: 'vps-epyc-32gb', name: '32 GB', cpuFamily: 'amd-epyc-7f72-vps', cpuModel: 'AMD EPYC 7F72', ramGB: 32, storageGB: 480, storageType: 'Gen 5 NVMe', vCores: 12, priceMonthlyINR: 4608, bandwidth: 'Unlimited', locations: ['india', 'germany', 'singapore'], features: COMMON_VPS_FEATURES, verified: false, osOptions: VPS_OS_OPTIONS },
];

export const DEDICATED_PLANS: DedicatedPlan[] = [
  { id: 'ded-8gb', name: '8 GB', cpuFamily: 'dedicated-ryzen-9', cpuModel: 'AMD Ryzen 9 / EPYC 7F72', ramGB: 8, storageGB: 256, storageType: 'Gen 5 SSD', vCores: 4, priceMonthlyINR: 3200, bandwidth: 'Unlimited', locations: ['india'], features: COMMON_DEDICATED_FEATURES, verified: false },
  { id: 'ded-12gb', name: '12 GB', cpuFamily: 'dedicated-ryzen-9', cpuModel: 'AMD Ryzen 9 / EPYC 7F72', ramGB: 12, storageGB: 384, storageType: 'Gen 5 SSD', vCores: 6, priceMonthlyINR: 4800, bandwidth: 'Unlimited', locations: ['india'], features: COMMON_DEDICATED_FEATURES, verified: false },
  { id: 'ded-16gb', name: '16 GB', cpuFamily: 'dedicated-ryzen-9', cpuModel: 'AMD Ryzen 9 / EPYC 7F72', ramGB: 16, storageGB: 512, storageType: 'Gen 5 SSD', vCores: 8, priceMonthlyINR: 6400, bandwidth: 'Unlimited', locations: ['india'], features: COMMON_DEDICATED_FEATURES, verified: false, badge: 'popular' },
  { id: 'ded-24gb', name: '24 GB', cpuFamily: 'dedicated-ryzen-9', cpuModel: 'AMD Ryzen 9 / EPYC 7F72', ramGB: 24, storageGB: 768, storageType: 'Gen 5 SSD', vCores: 12, priceMonthlyINR: 9600, bandwidth: 'Unlimited', locations: ['india'], features: COMMON_DEDICATED_FEATURES, verified: false },
  { id: 'ded-32gb', name: '32 GB', cpuFamily: 'dedicated-ryzen-9', cpuModel: 'AMD Ryzen 9 / EPYC 7F72', ramGB: 32, storageGB: 1024, storageType: 'Gen 5 SSD', vCores: 16, priceMonthlyINR: 12800, bandwidth: 'Unlimited', locations: ['india'], features: COMMON_DEDICATED_FEATURES, verified: false },
  { id: 'ded-48gb', name: '48 GB', cpuFamily: 'dedicated-epyc-7f72', cpuModel: 'AMD Ryzen 9 / EPYC 7F72', ramGB: 48, storageGB: 1536, storageType: 'Gen 5 SSD', vCores: 24, priceMonthlyINR: 19200, bandwidth: 'Unlimited', locations: ['india'], features: COMMON_DEDICATED_FEATURES, verified: false },
  { id: 'ded-64gb', name: '64 GB', cpuFamily: 'dedicated-epyc-7f72', cpuModel: 'AMD Ryzen 9 / EPYC 7F72', ramGB: 64, storageGB: 2048, storageType: 'Gen 5 SSD', vCores: 32, priceMonthlyINR: 25600, bandwidth: 'Unlimited', locations: ['india'], features: COMMON_DEDICATED_FEATURES, verified: false },
  { id: 'ded-96gb', name: '96 GB', cpuFamily: 'dedicated-epyc-7f72', cpuModel: 'AMD Ryzen 9 / EPYC 7F72', ramGB: 96, storageGB: 3072, storageType: 'Gen 5 SSD', vCores: 48, priceMonthlyINR: 38400, bandwidth: 'Unlimited', locations: ['india'], features: COMMON_DEDICATED_FEATURES, verified: false },
  { id: 'ded-128gb', name: '128 GB', cpuFamily: 'dedicated-epyc-7f72', cpuModel: 'AMD Ryzen 9 / EPYC 7F72', ramGB: 128, storageGB: 4096, storageType: 'Gen 5 SSD', vCores: 64, priceMonthlyINR: 51200, bandwidth: 'Unlimited', locations: ['india'], features: COMMON_DEDICATED_FEATURES, verified: false },
  { id: 'ded-192gb', name: '192 GB', cpuFamily: 'dedicated-epyc-7f72', cpuModel: 'AMD Ryzen 9 / EPYC 7F72', ramGB: 192, storageGB: 6144, storageType: 'Gen 5 SSD', vCores: 96, priceMonthlyINR: 76800, bandwidth: 'Unlimited', locations: ['india'], features: COMMON_DEDICATED_FEATURES, verified: false },
  { id: 'ded-256gb', name: '256 GB', cpuFamily: 'dedicated-epyc-7f72', cpuModel: 'AMD Ryzen 9 / EPYC 7F72', ramGB: 256, storageGB: 8192, storageType: 'Gen 5 SSD', vCores: 128, priceMonthlyINR: 102400, bandwidth: 'Unlimited', locations: ['india'], features: COMMON_DEDICATED_FEATURES, verified: false },
];

export const BOT_HOSTING_PLANS: BotHostingPlan[] = [
  { id: 'bot-starter', name: 'Starter', cpuFamily: 'bot-epyc-7f72', cpuModel: 'AMD EPYC 7F72', ramGB: 1, storageGB: 5, storageType: 'NVMe SSD', vCores: 1, priceMonthlyINR: 59, bandwidth: 'Unlimited', locations: ['india', 'germany', 'singapore'], features: COMMON_BOT_FEATURES, verified: false, runtimes: ['Node.js', 'Python', 'Java', 'Go', 'PHP'] },
  { id: 'bot-pro', name: 'Pro', cpuFamily: 'bot-epyc-7f72', cpuModel: 'AMD EPYC 7F72', ramGB: 2, storageGB: 10, storageType: 'NVMe SSD', vCores: 1, priceMonthlyINR: 118, bandwidth: 'Unlimited', locations: ['india', 'germany', 'singapore'], features: COMMON_BOT_FEATURES, verified: false, runtimes: ['Node.js', 'Python', 'Java', 'Go', 'PHP'] },
  { id: 'bot-advanced', name: 'Advanced', cpuFamily: 'bot-epyc-7f72', cpuModel: 'AMD EPYC 7F72', ramGB: 4, storageGB: 20, storageType: 'NVMe SSD', vCores: 2, priceMonthlyINR: 236, bandwidth: 'Unlimited', locations: ['india', 'germany', 'singapore'], features: COMMON_BOT_FEATURES, verified: false, runtimes: ['Node.js', 'Python', 'Java', 'Go', 'PHP'], badge: 'popular' },
  { id: 'bot-elite', name: 'Elite', cpuFamily: 'bot-epyc-7f72', cpuModel: 'AMD EPYC 7F72', ramGB: 8, storageGB: 40, storageType: 'NVMe SSD', vCores: 4, priceMonthlyINR: 472, bandwidth: 'Unlimited', locations: ['india', 'germany', 'singapore'], features: COMMON_BOT_FEATURES, verified: false, runtimes: ['Node.js', 'Python', 'Java', 'Go', 'PHP'] },
  { id: 'bot-diamond', name: 'Diamond', cpuFamily: 'bot-epyc-7f72', cpuModel: 'AMD EPYC 7F72', ramGB: 12, storageGB: 60, storageType: 'NVMe SSD', vCores: 6, priceMonthlyINR: 708, bandwidth: 'Unlimited', locations: ['india', 'germany', 'singapore'], features: COMMON_BOT_FEATURES, verified: false, runtimes: ['Node.js', 'Python', 'Java', 'Go', 'PHP'] },
  { id: 'bot-ultimate', name: 'Ultimate', cpuFamily: 'bot-epyc-7f72', cpuModel: 'AMD EPYC 7F72', ramGB: 16, storageGB: 80, storageType: 'NVMe SSD', vCores: 8, priceMonthlyINR: 944, bandwidth: 'Unlimited', locations: ['india', 'germany', 'singapore'], features: COMMON_BOT_FEATURES, verified: false, runtimes: ['Node.js', 'Python', 'Java', 'Go', 'PHP'] },
];

export const GAMES_COMING_SOON = [
  { id: 'csgo', name: 'Counter-Strike: Global Offensive', status: 'coming-soon' as const },
  { id: 'rust', name: 'Rust', status: 'coming-soon' as const },
  { id: 'ark', name: 'ARK: Survival Evolved', status: 'coming-soon' as const },
  { id: 'valheim', name: 'Valheim', status: 'coming-soon' as const },
  { id: 'gmod', name: "Garry's Mod", status: 'coming-soon' as const },
];

export const INFRASTRUCTURE_CLAIMS = [
  { claim: 'DDoS Protection', detail: 'Cloudflare Magic Transit', verified: false },
  { claim: 'Game-Specific Filtering', detail: 'Custom BPF rules', verified: false },
  { claim: 'Inline eBPF/XDP Filtering', detail: '150 Gbps capacity', verified: false },
  { claim: 'Largest Mitigated Attack', detail: '2.4 Tbit/s', verified: false },
  { claim: 'Attack Detection', detail: 'Under 1 microsecond', verified: false },
  { claim: 'Uptime', detail: '99.97%', verified: false },
  { claim: 'Instant Setup', detail: 'Automated provisioning', verified: false },
  { claim: 'Automatic Recovery & Backups', detail: 'Included', verified: false },
  { claim: '24/7 Support', detail: 'Live chat & ticket system', verified: false },
  { claim: 'Resource Scaling', detail: 'Vertical scaling available', verified: false },
  { claim: 'Global Infrastructure', detail: 'Multi-region deployment', verified: false },
];

export const NAVIGATION_ITEMS = [
  { href: '/', label: 'Home' },
  { href: '/games', label: 'Game Hosting', hasDropdown: true, dropdownItems: [
    { href: '/games/minecraft', label: 'Minecraft Hosting' },
    { href: '/games', label: 'All Games (CS:GO, Rust, ARK, Valheim, GMod)', isComingSoon: true },
  ]},
  { href: '/vps', label: 'VPS Hosting' },
  { href: '/dedicated', label: 'Dedicated Servers' },
  { href: '/bothosting', label: 'Bot Hosting' },
  { href: '/features', label: 'Features' },
  { href: '/locations', label: 'Locations' },
  { href: '/faq', label: 'FAQ' },
  { href: '/contact', label: 'Contact' },
];

export const FOOTER_LINKS = {
  products: [
    { href: '/games/minecraft', label: 'Minecraft Hosting' },
    { href: '/vps', label: 'VPS Hosting' },
    { href: '/dedicated', label: 'Dedicated Servers' },
    { href: '/bothosting', label: 'Bot Hosting' },
  ],
  company: [
    { href: '/features', label: 'Features' },
    { href: '/locations', label: 'Locations' },
    { href: '/faq', label: 'FAQ' },
    { href: '/contact', label: 'Contact' },
  ],
  legal: [
    { href: '/privacy', label: 'Privacy Policy' },
    { href: '/terms', label: 'Terms of Service' },
    { href: '/refund-policy', label: 'Refund Policy' },
  ],
  community: [
    { href: 'https://discord.gg/9gGknK6VWw', label: 'Discord', external: true },
    { href: 'https://zenithzcloud.com/', label: 'Website', external: true },
  ],
};

export const DISCORD_INVITE = 'https://discord.gg/9gGknK6VWw';
export const WEBSITE_URL = 'https://zenithzcloud.com/';

export const siteConfig = {
  name: 'ZENITHZcloud',
  description: 'Premium infrastructure hosting for Minecraft, VPS, Dedicated Servers, and Discord Bots. High-performance AMD EPYC & Ryzen hardware with DDoS protection.',
  url: 'https://zenithzcloud.com',
  ogImage: '/og-image.png',
  twitterHandle: '@zenithzcloud',
  discordUrl: 'https://discord.gg/9gGknK6VWw',
};

export function formatINR(amount: number): string {
  return new Intl.NumberFormat('en-IN', {
    style: 'currency',
    currency: 'INR',
    maximumFractionDigits: 0,
  }).format(amount);
}

export function getPricePerGB(plan: AnyPlan): number {
  return Math.round(plan.priceMonthlyINR / plan.ramGB);
}

export function getMinecraftPlansByCPU(cpuFamily: CPUFamily): MinecraftPlan[] {
  return MINECRAFT_PLANS.filter(p => p.cpuFamily === cpuFamily);
}

export function getVPSPlansByCPU(cpuFamily: CPUFamily): VPSPlan[] {
  return VPS_PLANS.filter(p => p.cpuFamily === cpuFamily);
}

export function getUniqueMinecraftCPUs(): CPUFamily[] {
  return [...new Set(MINECRAFT_PLANS.map(p => p.cpuFamily))].filter(
    (c): c is CPUFamily => ['intel-xeon-v4', 'amd-epyc-7f72', 'intel-xeon-platinum', 'amd-ryzen-9'].includes(c)
  );
}

export function getUniqueVPSGPUs(): CPUFamily[] {
  return [...new Set(VPS_PLANS.map(p => p.cpuFamily))].filter(
    (c): c is CPUFamily => ['amd-ryzen-9000', 'amd-epyc-7f72-vps'].includes(c)
  );
}

export const MINECRAFT_RAM_OPTIONS = [2, 4, 6, 8, 12, 16, 24, 32, 48, 64, 96, 128, 160, 192, 224, 256];

export function getMinecraftPlan(cpuFamily: CPUFamily, ramGB: number): MinecraftPlan | undefined {
  return MINECRAFT_PLANS.find(p => p.cpuFamily === cpuFamily && p.ramGB === ramGB);
}