import { Metadata } from 'next';

export const siteConfig = {
  name: 'ZENITHZcloud',
  description: 'Premium infrastructure hosting for Minecraft, VPS, Dedicated Servers, and Discord Bots. High-performance AMD EPYC & Ryzen hardware with DDoS protection.',
  url: 'https://zenithzcloud.com',
  ogImage: '/og-image.png',
  twitterHandle: '@zenithzcloud',
  discordUrl: 'https://discord.gg/9gGknK6VWw',
};

export function generateMetadata({
  title,
  description,
  path,
  image,
  noIndex = false,
}: {
  title?: string;
  description?: string;
  path?: string;
  image?: string;
  noIndex?: boolean;
} = {}): Metadata {
  const pageTitle = title ? `${title} | ${siteConfig.name}` : siteConfig.name;
  const pageDescription = description || siteConfig.description;
  const pageUrl = path ? `${siteConfig.url}${path}` : siteConfig.url;
  const pageImage = image || siteConfig.ogImage;

  return {
    title: pageTitle,
    description: pageDescription,
    metadataBase: new URL(siteConfig.url),
    alternates: {
      canonical: pageUrl,
    },
    openGraph: {
      type: 'website',
      locale: 'en_US',
      url: pageUrl,
      title: pageTitle,
      description: pageDescription,
      siteName: siteConfig.name,
      images: [
        {
          url: pageImage,
          width: 1200,
          height: 630,
          alt: pageTitle,
        },
      ],
    },
    twitter: {
      card: 'summary_large_image',
      title: pageTitle,
      description: pageDescription,
      images: [pageImage],
      creator: siteConfig.twitterHandle,
    },
    robots: {
      index: !noIndex,
      follow: !noIndex,
      googleBot: {
        index: !noIndex,
        follow: !noIndex,
        'max-video-preview': -1,
        'max-image-preview': 'large',
        'max-snippet': -1,
      },
    },
    icons: {
      icon: '/favicon.ico',
      shortcut: '/favicon-16x16.png',
      apple: '/apple-touch-icon.png',
    },
    manifest: '/site.webmanifest',
  };
}

export function generateProductMetadata({
  productName,
  category,
  startingPrice,
  cpuModel,
}: {
  productName: string;
  category: string;
  startingPrice: number;
  cpuModel: string;
}): Metadata {
  const title = `${productName} - ${category} | ${siteConfig.name}`;
  const description = `${productName} hosting on ${cpuModel} starting from ₹${startingPrice}/mo. DDoS protection, unlimited bandwidth, 24/7 support.`;

  return generateMetadata({ title, description });
}