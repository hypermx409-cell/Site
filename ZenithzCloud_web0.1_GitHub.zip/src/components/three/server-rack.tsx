'use client';

import * as React from 'react';
import { Canvas, useFrame, useThree } from '@react-three/fiber';
import { Html, OrbitControls } from '@react-three/drei';
import { Suspense, useMemo } from 'react';
import * as THREE from 'three';

interface ServerRackProps {
  className?: string;
}

export function ServerRackCanvas({ className }: ServerRackProps) {
  const [webglError, setWebglError] = React.useState(false);

  if (webglError) {
    return <ServerRackFallback className={className} />;
  }

  return (
    <div className={className} style={{ width: '100%', height: '100%', minHeight: 400 }}>
      <Canvas
        camera={{ position: [0, 0, 15], fov: 45 }}
        gl={{
          antialias: true,
          alpha: true,
          preserveDrawingBuffer: false,
          powerPreference: 'high-performance',
        }}
        style={{ outline: 'none' }}
        onCreated={({ gl }) => {
          gl.setPixelRatio(Math.min(window.devicePixelRatio, 2));
        }}
      >
        <Suspense fallback={<LoadingFallback />}>
          <Scene onError={setWebglError} />
        </Suspense>
      </Canvas>
    </div>
  );
}

function LoadingFallback() {
  return (
    <div className="absolute inset-0 flex items-center justify-center bg-black/50">
      <div className="text-center">
        <div className="h-8 w-8 animate-spin border-2 border-red-500 border-t-transparent rounded-full mx-auto mb-2" />
        <p className="text-sm text-gray-400">Loading 3D scene...</p>
      </div>
    </div>
  );
}

function Scene({ onError }: { onError: (err: boolean) => void }) {
  React.useEffect(() => {
    const handleError = (event: ErrorEvent) => {
      if (event.message.includes('WebGL') || event.message.includes('canvas')) {
        onError(true);
      }
    };
    window.addEventListener('error', handleError);
    return () => window.removeEventListener('error', handleError);
  }, [onError]);

  return (
    <>
      <ambientLight intensity={0.6} />
      <directionalLight position={[5, 10, 7]} intensity={1.2} castShadow />
      <directionalLight position={[-5, 5, -5]} intensity={0.5} />
      <pointLight position={[0, 8, 0]} intensity={0.3} color="#dc2626" />
      <ServerRack position={[0, -1, 0]} />
      <FloorPlane />
      <OrbitControls
        enablePan={false}
        enableZoom={true}
        maxPolarAngle={Math.PI / 2 - 0.05}
        minDistance={10}
        maxDistance={30}
        autoRotate={true}
        autoRotateSpeed={0.3}
      />
    </>
  );
}

function FloorPlane() {
  return (
    <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, -3.5, 0]} receiveShadow>
      <planeGeometry args={[50, 50]} />
      <meshStandardMaterial
        color="#0a0a0a"
        roughness={0.9}
        metalness={0.1}
        transparent
        opacity={0.5}
      />
    </mesh>
  );
}

interface RackMaterials {
  frame: THREE.MeshStandardMaterial;
  panel: THREE.MeshStandardMaterial;
  vent: THREE.MeshStandardMaterial;
  led: THREE.MeshBasicMaterial;
  ledDim: THREE.MeshBasicMaterial;
  accent: THREE.MeshStandardMaterial;
}

interface ServerRackComponentProps {
  position?: [number, number, number];
}

function ServerRack({ position = [0, 0, 0] }: ServerRackComponentProps) {
  const rackRef = React.useRef<THREE.Group>(null);

  useFrame((state) => {
    if (rackRef.current) {
      rackRef.current.rotation.y = state.clock.getElapsedTime() * 0.05;
    }
  });

  const rackMaterials = useMemo((): RackMaterials => ({
    frame: new THREE.MeshStandardMaterial({
      color: '#111111',
      roughness: 0.3,
      metalness: 0.8,
    }),
    panel: new THREE.MeshStandardMaterial({
      color: '#1a1a1a',
      roughness: 0.4,
      metalness: 0.6,
    }),
    vent: new THREE.MeshStandardMaterial({
      color: '#0a0a0a',
      roughness: 0.9,
      metalness: 0.1,
    }),
    led: new THREE.MeshBasicMaterial({
      color: '#dc2626',
      transparent: true,
      opacity: 0.9,
    }),
    ledDim: new THREE.MeshBasicMaterial({
      color: '#dc2626',
      transparent: true,
      opacity: 0.3,
    }),
    accent: new THREE.MeshStandardMaterial({
      color: '#dc2626',
      roughness: 0.2,
      metalness: 0.9,
      emissive: '#dc2626',
      emissiveIntensity: 0.3,
    }),
  }), []);

  return (
    <group ref={rackRef} position={position}>
      <RackFrame materials={rackMaterials} />
      <ServerUnits materials={rackMaterials} count={12} />
      <RackAccents materials={rackMaterials} />
    </group>
  );
}

function RackFrame({ materials }: { materials: RackMaterials }) {
  return (
    <group>
      {[-1.8, 1.8].map((x) =>
        [-1.5, 1.5].map((z) => (
          <mesh key={`${x}-${z}`} castShadow receiveShadow position={[x, 0, z]}>
            <boxGeometry args={[0.08, 6.5, 0.08]} />
            <meshStandardMaterial {...materials.frame} />
          </mesh>
        ))
      )}

      {[-3, -1, 1, 3].map((y) =>
        [-1.8, 1.8].map((x) => (
          <mesh key={`beam-${x}-${y}`} castShadow receiveShadow position={[x, y, 0]}>
            <boxGeometry args={[0.08, 0.06, 3.2]} />
            <meshStandardMaterial {...materials.frame} />
          </mesh>
        ))
      )}

      {[-1, 1].map((side) => (
        <mesh key={`side-${side}`} castShadow receiveShadow position={[side * 1.84, 0, 0]}>
          <planeGeometry args={[3.5, 6.5, 10, 10]} />
          <meshStandardMaterial
            {...materials.vent}
            side={THREE.DoubleSide}
            transparent
            opacity={0.6}
            wireframe={true}
          />
        </mesh>
      ))}

      <mesh castShadow receiveShadow position={[0, 0, -1.84]} rotation={[0, Math.PI, 0]}>
        <planeGeometry args={[3.5, 6.5, 5, 5]} />
        <meshStandardMaterial
          {...materials.vent}
          side={THREE.DoubleSide}
          transparent
          opacity={0.4}
          wireframe={true}
        />
      </mesh>
    </group>
  );
}

function ServerUnits({ materials, count }: { materials: RackMaterials; count: number }) {
  return (
    <group>
      {Array.from({ length: count }, (_, i) => (
        <ServerUnit
          key={i}
          index={i}
          materials={materials}
          position={[0, 2.5 - i * 0.5, 0]}
        />
      ))}
    </group>
  );
}

function ServerUnit({ index, materials, position }: { index: number; materials: RackMaterials; position: [number, number, number] }) {
  const isActive = index % 3 !== 0;

  return (
    <group position={position}>
      <mesh castShadow receiveShadow position={[0, 0, 0.3]}>
        <boxGeometry args={[3.4, 0.42, 2.8]} />
        <meshStandardMaterial {...materials.panel} />
      </mesh>

      <mesh castShadow receiveShadow position={[0, 0, 1.8]}>
        <boxGeometry args={[3.4, 0.42, 0.04]} />
        <meshStandardMaterial {...materials.frame} />
      </mesh>

      {[-1.4, -0.7, 0, 0.7, 1.4].map((x) => (
        <mesh key={`vent-${x}`} position={[x, 0, 1.82]}>
          <boxGeometry args={[0.3, 0.3, 0.02]} />
          <meshStandardMaterial {...materials.vent} />
        </mesh>
      ))}

      <mesh position={[-1.5, 0, 1.83]}>
        <cylinderGeometry args={[0.04, 0.04, 0.02, 16]} />
        <meshBasicMaterial
          {...(isActive ? materials.led : materials.ledDim)}
        />
      </mesh>

      <mesh position={[-1.3, 0, 1.83]}>
        <cylinderGeometry args={[0.03, 0.03, 0.02, 12]} />
        <meshBasicMaterial
          color="#22c55e"
          transparent
          opacity={isActive ? 0.9 : 0.2}
        />
      </mesh>

      {[1.3, 1.5].map((x) => (
        <mesh key={`drive-${x}`} position={[x, 0, 1.83]}>
          <cylinderGeometry args={[0.025, 0.025, 0.02, 8]} />
          <meshBasicMaterial
            color="#f59e0b"
            transparent
            opacity={isActive ? 0.8 : 0.1}
          />
        </mesh>
      ))}

      <mesh position={[1.65, 0, 1.83]}>
        <boxGeometry args={[0.08, 0.08, 0.02]} />
        <meshStandardMaterial {...materials.accent} />
      </mesh>
    </group>
  );
}

function RackAccents({ materials }: { materials: RackMaterials }) {
  return (
    <group>
      <mesh position={[0, 3.3, 0]} castShadow>
        <boxGeometry args={[3.6, 0.04, 3.2]} />
        <meshStandardMaterial {...materials.accent} />
      </mesh>

      <mesh position={[0, -3.3, 0]} castShadow>
        <boxGeometry args={[3.6, 0.04, 3.2]} />
        <meshStandardMaterial {...materials.accent} />
      </mesh>

      {[-1.8, 1.8].map((x) =>
        [-1.5, 1.5].map((z) =>
          [-3.3, 3.3].map((y) => (
            <mesh key={`${x}-${y}-${z}`} position={[x, y, z]} castShadow>
              <boxGeometry args={[0.08, 0.08, 0.08]} />
              <meshStandardMaterial {...materials.accent} />
            </mesh>
          ))
        )
      )}

      {[-1.6, 1.6].map((x) =>
        [2, 0, -2].map((y) => (
          <CableLoop key={`${x}-${y}`} position={[x, y, -1.9]} materials={materials} />
        ))
      )}
    </group>
  );
}

function CableLoop({ position, materials }: { position: [number, number, number]; materials: RackMaterials }) {
  const curve = useMemo(() => {
    const c = new THREE.CatmullRomCurve3([
      new THREE.Vector3(0, 0, 0),
      new THREE.Vector3(0, -0.3, -0.4),
      new THREE.Vector3(0, -0.6, -0.3),
      new THREE.Vector3(0, -0.8, 0),
    ]);
    return c;
  }, []);

  return (
    <mesh position={position} rotation={[0, Math.PI / 2, 0]}>
      <tubeGeometry args={[curve, 20, 0.03, 8, false]} />
      <meshStandardMaterial {...materials.frame} />
    </mesh>
  );
}

function ServerRackFallback({ className }: { className?: string }) {
  return (
    <div
      className={className}
      style={{ width: '100%', height: '100%', minHeight: 400 }}
      aria-label="Server rack illustration (WebGL not available)"
    >
      <div className="relative w-full h-full bg-gradient-to-b from-gray-950 to-black">
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,rgba(220,38,38,0.08)_0%,transparent_70%)]" />
        <div className="absolute inset-0 bg-grid-tight" />
        <div className="relative flex h-full items-center justify-center p-8">
          <div className="relative z-10 w-full max-w-md">
            <div className="relative">
              <div className="aspect-[4/5] rounded-xl border border-gray-800 bg-black/50 shadow-2xl shadow-black/50 overflow-hidden">
                <div className="absolute inset-0 bg-gradient-to-t from-red-600/10 via-transparent to-transparent" />
                <div className="relative h-full flex flex-col">
                  <div className="flex items-center justify-between border-b border-gray-800 px-4 py-3 bg-gray-900/50">
                    <div className="flex items-center space-x-2">
                      <div className="h-2 w-2 rounded-full bg-red-500" />
                      <div className="h-2 w-2 rounded-full bg-yellow-500" />
                      <div className="h-2 w-2 rounded-full bg-green-500" />
                    </div>
                    <span className="text-xs text-gray-400 font-mono">RACK-01</span>
                  </div>
                  <div className="flex-1 p-4 space-y-3 overflow-hidden">
                    {Array.from({ length: 12 }, (_, i) => (
                      <ServerUnitFallback key={i} index={i} active={i % 3 !== 0} />
                    ))}
                  </div>
                </div>
              </div>
              <div className="absolute -bottom-4 left-1/2 -translate-x-1/2 flex items-center space-x-2 text-xs text-gray-500">
                <span className="flex items-center space-x-1">
                  <span className="h-2 w-2 rounded-full bg-red-500" />
                  <span>Power</span>
                </span>
                <span className="flex items-center space-x-1">
                  <span className="h-2 w-2 rounded-full bg-green-500" />
                  <span>Healthy</span>
                </span>
                <span className="flex items-center space-x-1">
                  <span className="h-2 w-2 rounded-full bg-yellow-500" />
                  <span>Activity</span>
                </span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

function ServerUnitFallback({ index, active }: { index: number; active: boolean }) {
  return (
    <div
      className="flex items-center justify-between rounded-lg border p-2 transition-colors"
      style={{
        borderColor: active ? 'rgba(220,38,38,0.3)' : 'rgba(255,255,255,0.05)',
        backgroundColor: active ? 'rgba(220,38,38,0.03)' : 'transparent',
      }}
    >
      <div className="flex items-center space-x-3">
        <div className="w-8 text-right text-xs text-gray-500 font-mono">
          U{String(13 - index).padStart(2, '0')}
        </div>
        <div className="flex items-center space-x-1.5">
          <div
            className="h-1.5 w-1.5 rounded-full transition-all"
            style={{
              backgroundColor: active ? '#dc2626' : 'rgba(220,38,38,0.3)',
              boxShadow: active ? '0 0 8px rgba(220,38,38,0.6)' : 'none',
            }}
          />
          <div
            className="h-1.5 w-1.5 rounded-full transition-all"
            style={{
              backgroundColor: active ? '#22c55e' : 'rgba(34,197,94,0.2)',
            }}
          />
        </div>
        <span className="text-sm font-medium text-gray-200">
          {active ? 'ACTIVE' : 'STANDBY'}
        </span>
      </div>
      <div className="flex items-center space-x-1">
        <div
          className="h-1.5 w-1.5 rounded transition-all"
          style={{
            backgroundColor: active ? '#f59e0b' : 'rgba(245,158,11,0.1)',
          }}
        />
        <div
          className="h-1.5 w-1.5 rounded transition-all"
          style={{
            backgroundColor: active ? '#f59e0b' : 'rgba(245,158,11,0.1)',
          }}
        />
        <div
          className="h-2 w-2 rounded transition-all"
          style={{
            backgroundColor: '#dc2626',
            boxShadow: '0 0 6px rgba(220,38,38,0.5)',
          }}
        />
      </div>
    </div>
  );
}