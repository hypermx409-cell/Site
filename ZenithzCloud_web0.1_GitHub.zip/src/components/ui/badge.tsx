'use client';

import * as React from 'react';
import { cva, type VariantProps } from 'class-variance-authority';
import { cn } from '@/lib/utils';

const badgeVariants = cva(
  'inline-flex items-center rounded-full border px-2.5 py-0.5 text-xs font-semibold transition-colors focus:outline-none focus:ring-2 focus:ring-red-500 focus:ring-offset-2 focus:ring-offset-black',
  {
    variants: {
      variant: {
        default: 'border-gray-700 bg-gray-800 text-gray-100',
        secondary: 'border-gray-700 bg-gray-900 text-gray-300',
        destructive: 'border-red-600 bg-red-600/20 text-red-400',
        success: 'border-green-600 bg-green-600/20 text-green-400',
        warning: 'border-yellow-600 bg-yellow-600/20 text-yellow-400',
        premium: 'border-red-500 bg-red-600/20 text-red-300',
        outline: 'border-gray-600 bg-transparent text-gray-200',
      },
      size: {
        default: 'px-2.5 py-0.5 text-xs',
        sm: 'px-2 py-0.5 text-[10px]',
        lg: 'px-3 py-1 text-sm',
      },
    },
    defaultVariants: {
      variant: 'default',
      size: 'default',
    },
  }
);

export interface BadgeProps
  extends React.HTMLAttributes<HTMLDivElement>,
    VariantProps<typeof badgeVariants> {}

function Badge({ className, variant, size, ...props }: BadgeProps) {
  return <div className={cn(badgeVariants({ variant, size }), className)} {...props} />;
}

export { Badge, badgeVariants };