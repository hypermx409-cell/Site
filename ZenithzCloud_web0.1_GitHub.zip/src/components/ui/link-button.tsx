'use client';

import Link from 'next/link';
import { cn } from '@/lib/utils';

interface LinkButtonProps {
  href: string;
  children: React.ReactNode;
  variant?: 'premium' | 'secondary' | 'outline' | 'ghost';
  size?: 'sm' | 'md' | 'lg' | 'xl';
  className?: string;
  target?: string;
  rel?: string;
  loading?: boolean;
  disabled?: boolean;
  onClick?: () => void;
}

const variantStyles = {
  premium: 'bg-gradient-to-r from-red-600 to-red-700 text-white hover:from-red-700 hover:to-red-800 shadow-lg shadow-red-600/25',
  secondary: 'border border-gray-700 bg-gray-900 text-gray-100 hover:bg-gray-800 hover:border-gray-600',
  outline: 'border border-gray-700 bg-transparent text-gray-300 hover:bg-gray-800 hover:border-gray-600',
  ghost: 'text-gray-300 hover:bg-gray-800 hover:text-white',
};

const sizeStyles = {
  sm: 'h-9 rounded-md px-3 text-xs',
  md: 'h-10 px-4 py-2 text-sm',
  lg: 'h-11 rounded-lg px-8 text-base',
  xl: 'h-14 rounded-lg px-10 text-lg font-semibold',
};

const baseStyles = 'inline-flex items-center justify-center whitespace-nowrap rounded-md font-medium ring-offset-black transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-red-500 focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50';

export function LinkButton({
  href,
  children,
  variant = 'premium',
  size = 'md',
  className,
  target,
  rel,
  loading,
  disabled,
  onClick,
}: LinkButtonProps) {
  return (
    <Link
      href={href}
      target={target}
      rel={rel}
      className={cn(
        baseStyles,
        variantStyles[variant],
        sizeStyles[size],
        loading && 'opacity-50 cursor-wait',
        disabled && 'opacity-50 pointer-events-none',
        className
      )}
      onClick={(e) => {
        if (disabled) e.preventDefault();
        onClick?.();
      }}
      aria-busy={loading}
      aria-disabled={disabled}
    >
      {loading && (
        <svg
          className="mr-2 h-4 w-4 animate-spin"
          xmlns="http://www.w3.org/2000/svg"
          fill="none"
          viewBox="0 0 24 24"
          aria-hidden="true"
        >
          <circle
            className="opacity-25"
            cx="12"
            cy="12"
            r="10"
            stroke="currentColor"
            strokeWidth="4"
          />
          <path
            className="opacity-75"
            fill="currentColor"
            d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"
          />
        </svg>
      )}
      {children}
    </Link>
  );
}