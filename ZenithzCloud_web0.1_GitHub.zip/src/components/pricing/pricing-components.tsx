'use client';

import * as React from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { ChevronDown, Check, Loader2 } from 'lucide-react';
import { cn } from '@/lib/utils';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent } from '@/components/ui/card';
import { DropdownMenu, DropdownMenuTrigger, DropdownMenuContent, DropdownMenuItem, DropdownMenuLabel, DropdownMenuSeparator } from '@/components/ui/dropdown-menu';
import { formatINR, CPU_FAMILIES, getUniqueMinecraftCPUs, getUniqueVPSGPUs, type CPUFamily, type AnyPlan } from '@/data/plans';

interface CPUSelectorProps {
  category: 'minecraft' | 'vps';
  selectedCPU: CPUFamily;
  onSelect: (cpu: CPUFamily) => void;
  className?: string;
}

export function CPUSelector({ category, selectedCPU, onSelect, className }: CPUSelectorProps) {
  const [open, setOpen] = React.useState(false);
  const cpus = category === 'minecraft' ? getUniqueMinecraftCPUs() : getUniqueVPSGPUs();

  return (
    <DropdownMenu open={open} onOpenChange={setOpen}>
      <DropdownMenuTrigger asChild>
        <Button
          variant="outline"
          className={cn('w-full justify-between gap-2', className)}
          aria-haspopup="listbox"
          aria-label="Select CPU tier"
        >
          <div className="flex items-center space-x-3">
            <div className="h-8 w-8 rounded-lg bg-gradient-to-br from-red-600 to-red-700 flex items-center justify-center">
              <svg className="h-5 w-5 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 3v2m6-2v2M9 19v2m6-2v2M5 9H3m2 6H3m18-6h-2m2 6h-2M7 19h10a2 2 0 002-2V7a2 2 0 00-2-2H7a2 2 0 00-2 2v10a2 2 0 002 2zM9 9h6v6H9V9z" />
              </svg>
            </div>
            <div className="text-left">
              <span className="block text-sm font-medium text-white truncate">
                {CPU_FAMILIES[selectedCPU]?.name || 'Select CPU'}
              </span>
              <span className="block text-xs text-gray-400 truncate">
                {CPU_FAMILIES[selectedCPU]?.description || 'Choose a processor'}
              </span>
            </div>
          </div>
          <ChevronDown className={cn('h-4 w-4 text-gray-400 transition-transform', open && 'rotate-180')} />
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="end" className="w-[320px]">
        <DropdownMenuLabel className="px-2 py-1">CPU Tier</DropdownMenuLabel>
        <DropdownMenuSeparator />
        {cpus.map((cpu) => (
          <DropdownMenuItem
            key={cpu}
            onSelect={() => {
              onSelect(cpu);
              setOpen(false);
            }}
            className={cn('flex items-start gap-3 p-3', selectedCPU === cpu && 'bg-red-600/10')}
          >
            <div className="h-8 w-8 rounded-lg bg-gradient-to-br from-red-600 to-red-700 flex items-center justify-center flex-shrink-0">
              <svg className="h-5 w-5 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 3v2m6-2v2M9 19v2m6-2v2M5 9H3m2 6H3m18-6h-2m2 6h-2M7 19h10a2 2 0 002-2V7a2 2 0 00-2-2H7a2 2 0 002 2zM9 9h6v6H9V9z" />
              </svg>
            </div>
            <div className="flex-1 min-w-0 text-left">
              <span className="block text-sm font-medium text-white truncate">
                {CPU_FAMILIES[cpu].name}
              </span>
              <span className="block text-xs text-gray-400 truncate">
                {CPU_FAMILIES[cpu].description}
              </span>
            </div>
            {selectedCPU === cpu && <Check className="h-4 w-4 text-red-500 mt-0.5 flex-shrink-0" />}
          </DropdownMenuItem>
        ))}
      </DropdownMenuContent>
    </DropdownMenu>
  );
}

interface PlanCardProps {
  plan: AnyPlan;
  highlighted?: boolean;
  onOrder: (plan: AnyPlan) => void;
}

export function PlanCard({ plan, highlighted, onOrder }: PlanCardProps) {
  const pricePerGB = Math.round(plan.priceMonthlyINR / plan.ramGB);

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.3, delay: Math.random() * 0.2 }}
      className={cn(
        'relative flex flex-col',
        highlighted && 'z-10'
      )}
    >
      <Card
        variant={highlighted ? 'premium' : 'elevated'}
        padding="lg"
        className="flex flex-col h-full"
      >
        {plan.badge && (
          <div className="absolute -top-3 left-1/2 -translate-x-1/2">
            <Badge variant="premium" size="sm">
              {plan.badge === 'popular' && 'Most Popular'}
              {plan.badge === 'best-value' && 'Best Value'}
              {plan.badge === 'new' && 'New'}
              {plan.badge === 'coming-soon' && 'Coming Soon'}
            </Badge>
          </div>
        )}

        <div className="mb-6">
          <span className="text-xs font-semibold text-gray-400 uppercase tracking-wider">
            {plan.name}
          </span>
        </div>

        <div className="mb-6">
          <span className="text-4xl font-bold text-white">
            {formatINR(plan.priceMonthlyINR)}
          </span>
          <span className="text-gray-400 ml-1">/mo</span>
        </div>

        <div className="mb-6 space-y-3">
          <SpecRow label="RAM" value={`${plan.ramGB} GB DDR4`} />
          <SpecRow label="Storage" value={`${plan.storageGB} GB ${plan.storageType}`} />
          <SpecRow label="vCPU" value={`${plan.vCores} Cores`} />
          <SpecRow label="CPU" value={plan.cpuModel} />
          <SpecRow label="Bandwidth" value={plan.bandwidth} />
          <SpecRow label="Price/GB" value={`${formatINR(pricePerGB)}/GB`} />
        </div>

        <div className="mb-6 pt-4 border-t border-gray-800">
          <p className="text-xs text-gray-400 mb-2">Available in:</p>
          <div className="flex flex-wrap gap-1.5">
            {plan.locations.slice(0, 4).map((loc) => (
              <Badge key={loc} variant="outline" size="sm" className="text-xs">
                {loc.charAt(0).toUpperCase() + loc.slice(1)}
              </Badge>
            ))}
            {plan.locations.length > 4 && (
              <Badge variant="outline" size="sm" className="text-xs">
                +{plan.locations.length - 4} more
              </Badge>
            )}
          </div>
        </div>

        <div className="mt-auto pt-4">
          <Button
            variant={highlighted ? 'premium' : 'default'}
            size="lg"
            className="w-full"
            onClick={() => onOrder(plan)}
            disabled={plan.badge === 'coming-soon'}
          >
            {plan.badge === 'coming-soon' ? 'Coming Soon' : 'Order Now'}
          </Button>
        </div>
      </Card>

      {highlighted && (
        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          className="absolute -inset-1 rounded-xl border border-red-500/30 pointer-events-none"
          style={{ boxShadow: '0 0 40px rgba(220,38,38,0.15)' }}
        />
      )}
    </motion.div>
  );
}

function SpecRow({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex justify-between text-sm">
      <span className="text-gray-400">{label}</span>
      <span className="text-white font-medium text-right max-w-[60%] truncate">{value}</span>
    </div>
  );
}

interface PlanComparisonTableProps {
  plans: AnyPlan[];
  category: 'minecraft' | 'vps' | 'dedicated' | 'bot';
  onOrder: (plan: AnyPlan) => void;
}

export function PlanComparisonTable({ plans, category, onOrder }: PlanComparisonTableProps) {
  const [sortConfig, setSortConfig] = React.useState<{ key: string; direction: 'asc' | 'desc' }>({ key: 'priceMonthlyINR', direction: 'asc' });

  const sortedPlans = React.useMemo(() => {
    return [...plans].sort((a, b) => {
      let aVal: unknown = a[sortConfig.key as keyof typeof a];
      let bVal: unknown = b[sortConfig.key as keyof typeof b];

      if (typeof aVal === 'string') aVal = aVal.toLowerCase();
      if (typeof bVal === 'string') bVal = bVal.toLowerCase();

      if (aVal == null && bVal == null) return 0;
      if (aVal == null) return 1;
      if (bVal == null) return -1;
      if (aVal < bVal) return sortConfig.direction === 'asc' ? -1 : 1;
      if (aVal > bVal) return sortConfig.direction === 'asc' ? 1 : -1;
      return 0;
    });
  }, [plans, sortConfig]);

  const handleSort = (key: string) => {
    setSortConfig((prev) => ({
      key,
      direction: prev.key === key && prev.direction === 'asc' ? 'desc' : 'asc',
    }));
  };

  const columns = category === 'minecraft'
    ? [
        { key: 'ramGB', label: 'RAM', render: (p: AnyPlan) => `${p.ramGB} GB` },
        { key: 'storageGB', label: 'Storage', render: (p: AnyPlan) => `${p.storageGB} GB ${p.storageType}` },
        { key: 'vCores', label: 'vCPU', render: (p: AnyPlan) => `${p.vCores}` },
        { key: 'priceMonthlyINR', label: 'Price/Mo', render: (p: AnyPlan) => formatINR(p.priceMonthlyINR) },
        { key: 'pricePerGB', label: 'Price/GB', render: (p: AnyPlan) => `${formatINR(Math.round(p.priceMonthlyINR / p.ramGB))}/GB` },
      ]
    : category === 'vps'
    ? [
        { key: 'ramGB', label: 'RAM', render: (p: AnyPlan) => `${p.ramGB} GB` },
        { key: 'storageGB', label: 'NVMe', render: (p: AnyPlan) => `${p.storageGB} GB` },
        { key: 'vCores', label: 'vCPU', render: (p: AnyPlan) => `${p.vCores}` },
        { key: 'priceMonthlyINR', label: 'Price/Mo', render: (p: AnyPlan) => formatINR(p.priceMonthlyINR) },
        { key: 'pricePerGB', label: 'Price/GB', render: (p: AnyPlan) => `${formatINR(Math.round(p.priceMonthlyINR / p.ramGB))}/GB` },
      ]
    : category === 'dedicated'
    ? [
        { key: 'ramGB', label: 'RAM', render: (p: AnyPlan) => `${p.ramGB} GB` },
        { key: 'storageGB', label: 'Storage', render: (p: AnyPlan) => `${p.storageGB} GB ${p.storageType}` },
        { key: 'vCores', label: 'vCPU', render: (p: AnyPlan) => `${p.vCores}` },
        { key: 'priceMonthlyINR', label: 'Price/Mo', render: (p: AnyPlan) => formatINR(p.priceMonthlyINR) },
        { key: 'pricePerGB', label: 'Price/GB', render: (p: AnyPlan) => `${formatINR(Math.round(p.priceMonthlyINR / p.ramGB))}/GB` },
      ]
    : [
        { key: 'ramGB', label: 'RAM', render: (p: AnyPlan) => `${p.ramGB} GB` },
        { key: 'storageGB', label: 'Storage', render: (p: AnyPlan) => `${p.storageGB} GB ${p.storageType}` },
        { key: 'vCores', label: 'vCPU', render: (p: AnyPlan) => `${p.vCores}` },
        { key: 'priceMonthlyINR', label: 'Price/Mo', render: (p: AnyPlan) => formatINR(p.priceMonthlyINR) },
        { key: 'pricePerGB', label: 'Price/GB', render: (p: AnyPlan) => `${formatINR(Math.round(p.priceMonthlyINR / p.ramGB))}/GB` },
      ];

  return (
    <div className="overflow-x-auto rounded-xl border border-gray-800">
      <table className="w-full text-sm">
        <thead>
          <tr className="border-b border-gray-800 bg-gray-900/50">
            <th className="px-4 py-3 text-left font-medium text-gray-300">Plan</th>
            {columns.map((col) => (
              <th
                key={col.key}
                className="px-4 py-3 text-left font-medium text-gray-300 cursor-pointer hover:text-white select-none"
                onClick={() => handleSort(col.key)}
              >
                <div className="flex items-center gap-1">
                  {col.label}
                  {sortConfig.key === col.key && (
                    <span className="text-red-500">
                      {sortConfig.direction === 'asc' ? '▲' : '▼'}
                    </span>
                  )}
                </div>
              </th>
            ))}
            <th className="px-4 py-3 text-left font-medium text-gray-300">Action</th>
          </tr>
        </thead>
        <tbody>
          <AnimatePresence mode="popLayout">
            {sortedPlans.map((plan, index) => (
              <motion.tr
                key={plan.id}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                transition={{ duration: 0.2, delay: index * 0.03 }}
                className={cn(
                  'border-b border-gray-800/50 hover:bg-gray-900/50 transition-colors',
                  index % 2 === 0 && 'bg-black/30'
                )}
              >
                <td className="px-4 py-3">
                  <div>
                    <span className="font-medium text-white">{plan.name}</span>
                    {plan.badge && (
                      <Badge variant="premium" size="sm" className="ml-2">
                        {plan.badge === 'popular' && 'Popular'}
                        {plan.badge === 'best-value' && 'Best Value'}
                        {plan.badge === 'new' && 'New'}
                      </Badge>
                    )}
                  </div>
                </td>
                {columns.map((col) => (
                  <td key={col.key} className="px-4 py-3 text-gray-300">
                    {col.render(plan)}
                  </td>
                ))}
                <td className="px-4 py-3">
                  <Button
                    size="sm"
                    variant={plan.badge === 'popular' ? 'premium' : 'outline'}
                    onClick={() => onOrder(plan)}
                    disabled={plan.badge === 'coming-soon'}
                  >
                    {plan.badge === 'coming-soon' ? 'Coming Soon' : 'Order'}
                  </Button>
                </td>
              </motion.tr>
            ))}
          </AnimatePresence>
        </tbody>
      </table>
    </div>
  );
}

interface RAMSliderProps {
  plans: AnyPlan[];
  selectedRAM: number;
  onChange: (ram: number) => void;
  cpuFamily: CPUFamily;
}

export function RAMSlider({ plans, selectedRAM, onChange, cpuFamily }: RAMSliderProps) {
  const ramOptions = [...new Set(plans.map(p => p.ramGB))].sort((a, b) => a - b);
  const cpuName = CPU_FAMILIES[cpuFamily]?.name || '';

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <span className="text-sm font-medium text-white">{cpuName}</span>
        <span className="text-sm text-gray-400">
          Selected: <span className="text-white font-semibold">{selectedRAM} GB</span>
        </span>
      </div>

      <div className="relative">
        <input
          type="range"
          min={Math.min(...ramOptions)}
          max={Math.max(...ramOptions)}
          step={ramOptions[1] - ramOptions[0] || 2}
          value={selectedRAM}
          onChange={(e) => {
            const val = parseInt(e.target.value);
            const closest = ramOptions.reduce((prev, curr) =>
              Math.abs(curr - val) < Math.abs(prev - val) ? curr : prev
            );
            onChange(closest);
          }}
          className="w-full h-2 bg-gray-800 rounded-lg appearance-none cursor-pointer accent-red-600"
          aria-label="Select RAM"
        />
        <div className="absolute bottom-full left-0 right-0 mb-2 flex justify-between text-xs text-gray-500">
          {ramOptions.filter((_, i) => i % 3 === 0).map((ram) => (
            <span key={ram} className={cn('transition-colors', selectedRAM === ram && 'text-red-500 font-medium')}>
              {ram}GB
            </span>
          ))}
        </div>
      </div>

      <div className="flex flex-wrap gap-1.5" role="group" aria-label="Quick RAM selection">
        {ramOptions.map((ram) => (
          <button
            key={ram}
            onClick={() => onChange(ram)}
            className={cn(
              'px-3 py-1.5 rounded-lg text-sm font-medium transition-all',
              selectedRAM === ram
                ? 'bg-red-600 text-white shadow-lg shadow-red-600/25'
                : 'bg-gray-800 text-gray-300 hover:bg-gray-700 hover:text-white'
            )}
            aria-pressed={selectedRAM === ram}
          >
            {ram} GB
          </button>
        ))}
      </div>
    </div>
  );
}