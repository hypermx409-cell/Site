'use client';

import * as React from 'react';
import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { motion, AnimatePresence } from 'framer-motion';
import { Menu, X, ChevronDown } from 'lucide-react';
import { cn } from '@/lib/utils';
import { Button } from '@/components/ui/button';
import {
  DropdownMenu,
  DropdownMenuTrigger,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuLabel,
} from '@/components/ui/dropdown-menu';
import { NAVIGATION_ITEMS, DISCORD_INVITE } from '@/data/plans';

export function Header() {
  const pathname = usePathname();
  const [mobileMenuOpen, setMobileMenuOpen] = React.useState(false);
  const [scrolled, setScrolled] = React.useState(false);

  React.useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 20);
    };
    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const isActive = (href: string) => {
    if (href === '/') return pathname === '/';
    return pathname.startsWith(href);
  };

  return (
    <header
      className={cn(
        'fixed top-0 left-0 right-0 z-50 transition-all duration-300',
        scrolled
          ? 'bg-black/95 backdrop-blur-sm border-b border-gray-800 shadow-lg shadow-black/50'
          : 'bg-transparent'
      )}
    >
      <nav className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8" aria-label="Main navigation">
        <div className="flex h-16 items-center justify-between">
          <Link href="/" className="flex items-center space-x-2" aria-label="ZENITHZcloud Home">
            <span className="font-mono text-2xl font-bold tracking-tight">
              <span className="text-red-500">ZENITHZ</span><span className="text-white">cloud</span>
            </span>
          </Link>

          <div className="hidden md:flex md:items-center md:space-x-1">
            {NAVIGATION_ITEMS.map((item) => (
              <NavItem key={item.href} item={item} isActive={isActive(item.href)} />
            ))}
          </div>

          <div className="hidden md:flex md:items-center md:space-x-3">
            <Link href={DISCORD_INVITE} target="_blank" rel="noopener noreferrer" className="text-sm font-medium text-gray-300 hover:text-white transition-colors">
              Discord
            </Link>
            <Button asChild variant="premium" size="sm">
              <Link href="/contact">Get Started</Link>
            </Button>
          </div>

          <button
            className="md:hidden p-2 text-gray-300 hover:text-white transition-colors"
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            aria-expanded={mobileMenuOpen}
            aria-controls="mobile-menu"
            aria-label={mobileMenuOpen ? 'Close menu' : 'Open menu'}
          >
            {mobileMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
          </button>
        </div>

        <AnimatePresence>
          {mobileMenuOpen && (
            <motion.div
              id="mobile-menu"
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: 'auto' }}
              exit={{ opacity: 0, height: 0 }}
              className="md:hidden overflow-hidden bg-black/95 border-t border-gray-800"
            >
              <div className="px-4 py-4 space-y-4">
                {NAVIGATION_ITEMS.map((item) => (
                  <MobileNavItem key={item.href} item={item} isActive={isActive(item.href)} />
                ))}
                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <Button variant="ghost" className="w-full justify-start">
                      Community
                    </Button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent align="start">
                    <DropdownMenuLabel>Join Us</DropdownMenuLabel>
                    <DropdownMenuSeparator />
                    <DropdownMenuItem asChild>
                      <a href={DISCORD_INVITE} target="_blank" rel="noopener noreferrer" className="w-full">
                        Discord Community
                      </a>
                    </DropdownMenuItem>
                  </DropdownMenuContent>
                </DropdownMenu>
                <Button asChild variant="premium" className="w-full">
                  <Link href="/contact">Get Started</Link>
                </Button>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </nav>
    </header>
  );
}

function NavItem({ item, isActive }: { item: typeof NAVIGATION_ITEMS[0]; isActive: boolean }) {
  if (item.hasDropdown && item.dropdownItems) {
    return (
      <DropdownMenu>
        <DropdownMenuTrigger asChild>
          <Button
            variant="ghost"
            className={cn(
              'h-10 px-3 text-sm font-medium transition-all',
              isActive ? 'text-red-400' : 'text-gray-300 hover:text-white'
            )}
          >
            {item.label}
            <ChevronDown className="ml-1 h-4 w-4" />
          </Button>
        </DropdownMenuTrigger>
        <DropdownMenuContent align="start" className="w-72">
          {item.dropdownItems.map((subItem) => (
            <DropdownMenuItem key={subItem.href} asChild>
              <Link
                href={subItem.href}
                className={cn(
                  'flex w-full items-center justify-between px-2 py-1.5 text-sm transition-colors',
                  subItem.isComingSoon ? 'text-gray-500' : 'text-gray-300 hover:text-white'
                )}
              >
                {subItem.label}
                {subItem.isComingSoon && (
                  <span className="ml-2 text-xs text-yellow-500">Coming Soon</span>
                )}
              </Link>
            </DropdownMenuItem>
          ))}
        </DropdownMenuContent>
      </DropdownMenu>
    );
  }

  return (
    <Link
      href={item.href}
      className={cn(
        'h-10 px-3 text-sm font-medium rounded-md transition-all',
        isActive
          ? 'bg-red-600/20 text-red-400 hover:bg-red-600/30'
          : 'text-gray-300 hover:text-white hover:bg-gray-800'
      )}
      aria-current={isActive ? 'page' : undefined}
    >
      {item.label}
    </Link>
  );
}

function MobileNavItem({ item, isActive }: { item: typeof NAVIGATION_ITEMS[0]; isActive: boolean }) {
  if (item.hasDropdown && item.dropdownItems) {
    return (
      <div className="space-y-2 border-t border-gray-800 pt-4">
        <p className="px-2 text-xs font-semibold text-gray-500 uppercase tracking-wider">
          {item.label}
        </p>
        {item.dropdownItems.map((subItem) => (
          <Link
            key={subItem.href}
            href={subItem.href}
            className={cn(
              'block px-2 py-2 text-sm rounded-md transition-colors',
              subItem.isComingSoon ? 'text-gray-500' : isActive ? 'text-red-400 bg-red-600/10' : 'text-gray-300 hover:text-white hover:bg-gray-800'
            )}
          >
            <span className="flex items-center justify-between">
              {subItem.label}
              {subItem.isComingSoon && (
                <span className="text-xs text-yellow-500">Coming Soon</span>
              )}
            </span>
          </Link>
        ))}
      </div>
    );
  }

  return (
    <Link
      href={item.href}
      className={cn(
        'block px-2 py-2 text-sm font-medium rounded-md transition-colors',
        isActive ? 'text-red-400 bg-red-600/10' : 'text-gray-300 hover:text-white hover:bg-gray-800'
      )}
      onClick={() => setMobileMenuOpen(false)}
    >
      {item.label}
    </Link>
  );
}

function setMobileMenuOpen(_open: boolean) {}