'use client';

import * as React from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import Link from 'next/link';
import { ArrowRight, Check, Server, Shield, Zap, Globe, Clock, Cpu, Loader2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { CPUSelector, PlanCard, PlanComparisonTable, RAMSlider } from '@/components/pricing/pricing-components';
import { formatINR, getMinecraftPlansByCPU, getUniqueMinecraftCPUs, MINECRAFT_RAM_OPTIONS, CPU_FAMILIES, type MinecraftPlan, type CPUFamily, type AnyPlan, DISCORD_INVITE } from '@/data/plans';

const cpuFamilies = getUniqueMinecraftCPUs();

export default function MinecraftPage() {
  const [selectedCPU, setSelectedCPU] = React.useState<CPUFamily>(cpuFamilies[0]);
  const [selectedRAM, setSelectedRAM] = React.useState<number>(MINECRAFT_RAM_OPTIONS[2]); // 6GB default
  const [viewMode, setViewMode] = React.useState<'cards' | 'table'>('cards');
  const [orderingPlan, setOrderingPlan] = React.useState<string | null>(null);

  const plans = getMinecraftPlansByCPU(selectedCPU);
  const filteredPlans = plans.filter(p => p.ramGB === selectedRAM);
  const allPlansForTable = plans;

  const handleOrder = (plan: AnyPlan) => {
    setOrderingPlan(plan.id);
    // In production, redirect to actual order link
    window.open(DISCORD_INVITE, '_blank', 'noopener,noreferrer');
    setTimeout(() => setOrderingPlan(null), 2000);
  };

  const currentPlan = filteredPlans[0];

  return (
    <>
      <section className="relative min-h-[50vh] flex items-center overflow-hidden">
        <div className="absolute inset-0 bg-radial-bottom" />
        <div className="absolute inset-0 bg-grid" />

        <div className="relative z-10 container py-16 lg:py-24">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="max-w-3xl"
          >
            <Badge variant="premium" className="mb-4">Minecraft Hosting</Badge>
            <h1 className="text-display-lg text-white mb-4">Minecraft Server Hosting</h1>
            <p className="text-body-lg text-gray-400 mb-6">
              Four CPU tiers, 16 RAM configurations, three global locations.
              Starting from <span className="text-red-500 font-semibold">{formatINR(29)}/GB</span>.
            </p>
            <div className="flex flex-wrap gap-4 text-sm text-gray-400">
              <div className="flex items-center gap-2">
                <Check className="h-4 w-4 text-green-500" />
                <span>Instant Setup</span>
              </div>
              <div className="flex items-center gap-2">
                <Check className="h-4 w-4 text-green-500" />
                <span>DDoS Protected</span>
              </div>
              <div className="flex items-center gap-2">
                <Check className="h-4 w-4 text-green-500" />
                <span>Custom Panel</span>
              </div>
              <div className="flex items-center gap-2">
                <Check className="h-4 w-4 text-green-500" />
                <span>Mod/Plugin Support</span>
              </div>
            </div>
          </motion.div>
        </div>
      </section>

      <section className="section">
        <div className="container">
          <div className="mb-8">
            <CPUSelector
              category="minecraft"
              selectedCPU={selectedCPU}
              onSelect={setSelectedCPU}
            />
          </div>

          <div className="mb-10">
            <RAMSlider
              plans={plans}
              selectedRAM={selectedRAM}
              onChange={setSelectedRAM}
              cpuFamily={selectedCPU}
            />
          </div>

          {currentPlan && (
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="mb-12"
            >
              <Card variant="premium" padding="xl">
                <CardContent className="grid md:grid-cols-[1fr_auto] gap-8 items-center">
                  <div>
                    <div className="flex items-center gap-4 mb-6">
                      <span className="text-2xl font-bold text-white">
                        {formatINR(currentPlan.priceMonthlyINR)}
                        <span className="text-gray-400 font-normal text-lg ml-1">/mo</span>
                      </span>
                      <Badge variant="premium" size="lg">
                        {currentPlan.ramGB} GB RAM
                      </Badge>
                      {currentPlan.badge && (
                        <Badge variant={currentPlan.badge === 'popular' ? 'premium' : 'success'} size="sm">
                          {currentPlan.badge === 'popular' && 'Most Popular'}
                          {currentPlan.badge === 'best-value' && 'Best Value'}
                        </Badge>
                      )}
                    </div>

                    <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
                      <SpecItem label="CPU" value={currentPlan.cpuModel} />
                      <SpecItem label="RAM" value={`${currentPlan.ramGB} GB DDR4`} />
                      <SpecItem label="Storage" value={`${currentPlan.storageGB} GB ${currentPlan.storageType}`} />
                      <SpecItem label="vCPU" value={`${currentPlan.vCores} Cores`} />
                    </div>

                    <div className="flex flex-wrap gap-2 mb-6">
                      {currentPlan.locations.slice(0, 5).map((loc) => (
                        <Badge key={loc} variant="outline" size="sm">
                          {loc.charAt(0).toUpperCase() + loc.slice(1)}
                        </Badge>
                      ))}
                    </div>
                  </div>

                  <div className="flex flex-col sm:flex-row gap-4 w-full md:w-auto">
                    <Button
                      size="xl"
                      variant="premium"
                      className="w-full sm:w-auto"
                      onClick={() => handleOrder(currentPlan)}
                      disabled={orderingPlan === currentPlan.id}
                    >
                      {orderingPlan === currentPlan.id ? (
                        <>
                          <Loader2 className="h-5 w-5 animate-spin mr-2" />
                          Redirecting...
                        </>
                      ) : (
                        'Order Now'
                      )}
                    </Button>
                    <Button
                      size="xl"
                      variant="secondary"
                      className="w-full sm:w-auto"
                      asChild
                    >
                      <Link href={DISCORD_INVITE} target="_blank" rel="noopener noreferrer">
                        Ask on Discord
                      </Link>
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          )}

          <div className="mb-8 flex items-center justify-between">
            <h2 className="text-heading-lg text-white">
              All {CPU_FAMILIES[selectedCPU].name} Plans
            </h2>
            <div className="flex gap-2">
              <Button
                variant={viewMode === 'cards' ? 'default' : 'outline'}
                size="sm"
                onClick={() => setViewMode('cards')}
              >
                Cards
              </Button>
              <Button
                variant={viewMode === 'table' ? 'default' : 'outline'}
                size="sm"
                onClick={() => setViewMode('table')}
              >
                Table
              </Button>
            </div>
          </div>

          <AnimatePresence mode="wait">
            {viewMode === 'cards' ? (
              <motion.div
                key="cards"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -20 }}
                className="grid sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6"
              >
                {plans.map((plan, i) => (
                  <motion.div
                    key={plan.id}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: i * 0.05 }}
                  >
                    <PlanCard plan={plan} highlighted={plan.badge === 'popular' || plan.badge === 'best-value'} onOrder={handleOrder} />
                  </motion.div>
                ))}
              </motion.div>
            ) : (
              <motion.div
                key="table"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -20 }}
              >
                <PlanComparisonTable plans={allPlansForTable} category="minecraft" onOrder={handleOrder} />
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </section>

      <section className="section bg-gradient-to-b from-gray-950 to-black border-y border-gray-800">
        <div className="container">
          <h2 className="text-display-sm text-white text-center mb-12">Why Choose Our Minecraft Hosting?</h2>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {[
              { icon: Server, title: 'Custom Control Panel', desc: 'Intuitive panel built for Minecraft with one-click modpacks, plugin management, and real-time metrics.' },
              { icon: Cpu, title: 'Multiple CPU Tiers', desc: 'Choose from Intel Xeon v4 (budget), AMD EPYC 7F72 (balanced), Intel Xeon Platinum (premium), or AMD Ryzen 9 (high-clock).' },
              { icon: Shield, title: 'Game-Specific DDoS Protection', desc: 'Custom BPF rules and inline eBPF/XDP filtering at 150 Gbps designed for Minecraft traffic patterns.' },
              { icon: Zap, title: 'Instant Deployment', desc: 'Automated provisioning gets your server online in minutes. No manual setup required.' },
              { icon: Globe, title: 'Global Locations', desc: 'India (owned hardware), Germany & Singapore (rented). Low latency for your player base.' },
              { icon: Clock, title: '24/7 Expert Support', desc: 'Minecraft-savvy support team available via Discord and tickets around the clock.' },
            ].map((feature, i) => (
              <motion.div
                key={feature.title}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.08 }}
              >
                <Card variant="elevated" padding="lg" className="h-full">
                  <CardContent className="flex flex-col h-full">
                    <div className="h-12 w-12 rounded-xl bg-red-600/20 flex items-center justify-center mb-4">
                      <feature.icon className="h-6 w-6 text-red-500" />
                    </div>
                    <h3 className="text-heading-sm text-white mb-2">{feature.title}</h3>
                    <p className="text-body-sm text-gray-400 flex-1">{feature.desc}</p>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      <section className="section">
        <div className="container">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
            >
              <h2 className="text-display-sm text-white mb-4">Supported Versions & Types</h2>
              <p className="text-body-lg text-gray-400 mb-8">
                Run any Minecraft version with full support for all major server types.
              </p>
              <div className="grid grid-cols-2 gap-4 mb-8">
                {['Vanilla', 'Paper', 'Spigot', 'Purpur', 'Forge', 'Fabric', 'NeoForge', 'Mohist'].map((type) => (
                  <Badge key={type} variant="outline" className="text-sm px-3 py-2">{type}</Badge>
                ))}
              </div>
              <div className="flex flex-wrap gap-2 text-sm text-gray-400">
                {['1.21', '1.20.6', '1.20.4', '1.20.1', '1.19.4', '1.19.2', '1.18.2', '1.17.1', '1.16.5', '1.12.2'].map((ver) => (
                  <Badge key={ver} variant="secondary" size="sm">{ver}</Badge>
                ))}
              </div>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: 0.1 }}
            >
              <div className="aspect-video rounded-2xl border border-gray-800 overflow-hidden bg-black/50 relative">
                <div className="absolute inset-0 bg-gradient-to-br from-red-600/10 via-transparent to-transparent" />
                <div className="relative h-full flex items-center justify-center p-8">
                  <div className="text-center max-w-md">
                    <div className="text-5xl font-bold text-red-500 gradient-text-red mb-2">4</div>
                    <div className="text-gray-400 mb-6">CPU Families Available</div>
                    <div className="space-y-3 text-left">
                      {cpuFamilies.map((cpu) => (
                        <div key={cpu} className="flex items-center gap-3 p-3 bg-gray-900/50 rounded-xl border border-gray-800">
                          <div className="h-10 w-10 rounded-lg bg-gradient-to-br from-red-600 to-red-700 flex items-center justify-center">
                            <Cpu className="h-5 w-5 text-white" />
                          </div>
                          <div>
                            <div className="font-medium text-white">{CPU_FAMILIES[cpu].name}</div>
                            <div className="text-sm text-gray-400">{CPU_FAMILIES[cpu].description}</div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      <section className="section bg-gradient-to-b from-gray-950 to-black border-y border-gray-800">
        <div className="container text-center">
          <h2 className="text-display-sm text-white mb-4">Need a Custom Configuration?</h2>
          <p className="text-body-lg text-gray-400 mb-8 max-w-2xl mx-auto">
            Require more resources or a specific setup? Contact our team for custom hardware configurations and enterprise pricing.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button asChild size="lg" variant="premium">
              <Link href="/contact">Contact Sales</Link>
            </Button>
            <Button asChild size="lg" variant="secondary">
              <Link href={DISCORD_INVITE} target="_blank" rel="noopener noreferrer">
                Discord Support
              </Link>
            </Button>
          </div>
        </div>
      </section>
    </>
  );
}

function SpecItem({ label, value }: { label: string; value: string }) {
  return (
    <div className="p-3 bg-gray-900/50 rounded-xl border border-gray-800">
      <div className="text-xs text-gray-400 uppercase tracking-wider mb-1">{label}</div>
      <div className="font-medium text-white">{value}</div>
    </div>
  );
}