import { Metadata } from 'next';
import Link from 'next/link';
import { motion } from 'framer-motion';
import { ArrowRight, Server, Lock, Clock, Wifi, HardDrive, Cpu, Check } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { GAMES_COMING_SOON, COMMON_MINECRAFT_FEATURES, formatINR, DISCORD_INVITE } from '@/data/plans';
import { generateMetadata } from '@/lib/seo';

export const metadata: Metadata = generateMetadata({
  title: 'Game Server Hosting',
  description: 'Premium game server hosting for Minecraft, CS:GO, Rust, ARK, Valheim, and Garry\'s Mod. AMD EPYC & Ryzen hardware with DDoS protection.',
  path: '/games',
});

const minecraftFeatures = [
  'DDR4 RAM & Gen 5 SATA SSD',
  'Unlimited bandwidth',
  'DDoS protection with game-specific filtering',
  'Custom Minecraft control panel',
  'Plugin & mod management (Paper, Spigot, Forge, Fabric)',
  'One-click modpack installation',
  'Automatic backups & recovery',
  'Resource scaling & location selection',
  'Vanilla, Paper, Spigot, Forge, Fabric support',
  'All major Minecraft versions',
  '24/7 uptime & expert support',
  'Instant setup & automated provisioning',
];

export default function GamesPage() {
  return (
    <>
      <section className="relative min-h-[60vh] flex items-center overflow-hidden">
        <div className="absolute inset-0 bg-radial-bottom" />
        <div className="absolute inset-0 bg-grid" />

        <div className="relative z-10 container py-20 lg:py-28">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="max-w-3xl"
          >
            <Badge variant="premium" className="mb-4">Game Hosting</Badge>
            <h1 className="text-display-lg text-white mb-4">Game Server Hosting</h1>
            <p className="text-body-lg text-gray-400 mb-8">
              Low-latency game servers on enterprise hardware. Minecraft available now,
              with CS:GO, Rust, ARK, Valheim, and Garry's Mod coming soon.
            </p>
            <div className="flex flex-col sm:flex-row gap-4">
              <Button asChild size="lg" variant="premium">
                <Link href="/games/minecraft">Minecraft Hosting →</Link>
              </Button>
              <Button asChild size="lg" variant="secondary">
                <Link href={DISCORD_INVITE} target="_blank" rel="noopener noreferrer">
                  Join Discord for Updates
                </Link>
              </Button>
            </div>
          </motion.div>
        </div>
      </section>

      <section className="section">
        <div className="container">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="mb-12"
          >
            <h2 className="text-display-sm text-white mb-4">Available Now</h2>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
          >
            <Link
              href="/games/minecraft"
              className="group block card-base card-hover p-8 md:p-10 hover:border-red-500/30 transition-all duration-300"
            >
              <div className="grid md:grid-cols-[auto_1fr_auto] gap-8 items-center">
                <div className="h-20 w-20 rounded-2xl bg-gradient-to-br from-green-600 to-emerald-700 flex items-center justify-center flex-shrink-0 group-hover:scale-105 transition-transform">
                  <Server className="h-10 w-10 text-white" />
                </div>
                <div>
                  <h3 className="text-heading-lg text-white group-hover:text-red-400 transition-colors">Minecraft Server Hosting</h3>
                  <p className="mt-2 text-body text-gray-400 max-w-2xl">
                    Intel Xeon v4, AMD EPYC 7F72, Intel Xeon Platinum, and AMD Ryzen 9 options.
                    Starting from <span className="text-red-500 font-semibold">{formatINR(29)}/GB</span>.
                    Full mod & plugin support with custom control panel.
                  </p>
                  <div className="mt-4 flex flex-wrap gap-2">
                    {['Paper', 'Spigot', 'Forge', 'Fabric', 'Vanilla'].map((tech) => (
                      <Badge key={tech} variant="outline" size="sm">{tech}</Badge>
                    ))}
                  </div>
                </div>
                <ArrowRight className="h-8 w-8 text-gray-500 group-hover:text-red-500 group-hover:translate-x-1 transition-all flex-shrink-0" />
              </div>
            </Link>
          </motion.div>
        </div>
      </section>

      <section className="section bg-gradient-to-b from-gray-950 to-black border-y border-gray-800">
        <div className="container">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="mb-12"
          >
            <h2 className="text-display-sm text-white mb-4">Coming Soon</h2>
            <p className="text-body-lg text-gray-400 max-w-2xl">
              We're expanding our game hosting lineup. Join our Discord to get notified when these launch.
            </p>
          </motion.div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {GAMES_COMING_SOON.map((game, i) => (
              <motion.article
                key={game.id}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.1 }}
              >
                <Card variant="elevated" padding="lg" className="h-full relative opacity-60">
                  <Badge variant="warning" className="absolute top-4 right-4">Coming Soon</Badge>
                  <CardContent className="flex flex-col h-full">
                    <h3 className="text-heading-md text-white mb-2">{game.name}</h3>
                    <p className="text-body-sm text-gray-400 flex-1">
                      High-performance hosting coming soon. Optimized for low latency and high tick rates.
                    </p>
                    <Button variant="outline" className="mt-4 w-full" disabled>
                      Notify Me
                    </Button>
                  </CardContent>
                </Card>
              </motion.article>
            ))}
          </div>

          <div className="text-center mt-12">
            <Button asChild variant="secondary" size="lg">
              <Link href={DISCORD_INVITE} target="_blank" rel="noopener noreferrer">
                Join Discord for Launch Notifications
              </Link>
            </Button>
          </div>
        </div>
      </section>

      <section className="section">
        <div className="container">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center max-w-3xl mx-auto mb-12"
          >
            <h2 className="text-display-sm text-white mb-4">Minecraft Hosting Features</h2>
            <p className="text-body-lg text-gray-400">
              Everything you need to run a successful Minecraft server.
            </p>
          </motion.div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4 max-w-5xl mx-auto">
            {minecraftFeatures.map((feature, i) => (
              <motion.div
                key={feature}
                initial={{ opacity: 0, scale: 0.95 }}
                whileInView={{ opacity: 1, scale: 1 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.03 }}
              >
                <div className="flex items-center gap-3 p-4 card-base card-hover rounded-xl">
                  <Check className="h-5 w-5 text-green-500 flex-shrink-0" />
                  <span className="text-gray-300">{feature}</span>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      <section className="section bg-gradient-to-b from-gray-950 to-black border-y border-gray-800">
        <div className="container text-center">
          <h2 className="text-display-sm text-white mb-4">Ready to Start Your Server?</h2>
          <p className="text-body-lg text-gray-400 mb-8 max-w-2xl mx-auto">
            Deploy your Minecraft server in minutes. Choose your CPU, RAM, and location.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button asChild size="lg" variant="premium">
              <Link href="/games/minecraft">View Minecraft Plans</Link>
            </Button>
            <Button asChild size="lg" variant="secondary">
              <Link href={DISCORD_INVITE} target="_blank" rel="noopener noreferrer">
                Ask on Discord
              </Link>
            </Button>
          </div>
        </div>
      </section>
    </>
  );
}