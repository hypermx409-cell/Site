'use client';

import * as React from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import Link from 'next/link';
import { ArrowRight, Check, Bot, Shield, Zap, Globe, Clock, Cpu, Loader2, Code, Terminal, Database } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { PlanCard, PlanComparisonTable } from '@/components/pricing/pricing-components';
import { formatINR, BOT_HOSTING_PLANS, type BotHostingPlan, type AnyPlan, DISCORD_INVITE } from '@/data/plans';

export default function BotHostingPage() {
  const [viewMode, setViewMode] = React.useState<'cards' | 'table'>('cards');
  const [orderingPlan, setOrderingPlan] = React.useState<string | null>(null);

  const handleOrder = (plan: AnyPlan) => {
    setOrderingPlan(plan.id);
    window.open(DISCORD_INVITE, '_blank', 'noopener,noreferrer');
    setTimeout(() => setOrderingPlan(null), 2000);
  };

  const runtimes = ['Node.js', 'Python', 'Java', 'Go', 'PHP'];

  return (
    <>
      <section className="relative min-h-[50vh] flex items-center overflow-hidden">
        <div className="absolute inset-0 bg-radial-bottom" />
        <div className="absolute inset-0 bg-grid" />

        <div className="relative z-10 container py-16 lg:py-24">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="max-w-3xl"
          >
            <Badge variant="premium" className="mb-4">Bot Hosting</Badge>
            <h1 className="text-display-lg text-white mb-4">Discord Bot Hosting</h1>
            <p className="text-body-lg text-gray-400 mb-6">
              Reliable 24/7 hosting for your Discord bots on AMD EPYC 7F72 with NVMe SSD.
              Starting from <span className="text-red-500 font-semibold">{formatINR(59)}/mo</span>.
            </p>
            <div className="flex flex-wrap gap-4 text-sm text-gray-400">
              <div className="flex items-center gap-2">
                <Check className="h-4 w-4 text-green-500" />
                <span>NVMe SSD</span>
              </div>
              <div className="flex items-center gap-2">
                <Check className="h-4 w-4 text-green-500" />
                <span>Unlimited Bandwidth</span>
              </div>
              <div className="flex items-center gap-2">
                <Check className="h-4 w-4 text-green-500" />
                <span>Multi-Language</span>
              </div>
              <div className="flex items-center gap-2">
                <Check className="h-4 w-4 text-green-500" />
                <span>3 Locations</span>
              </div>
              <div className="flex items-center gap-2">
                <Check className="h-4 w-4 text-green-500" />
                <span>DDoS Protected</span>
              </div>
              <div className="flex items-center gap-2">
                <Check className="h-4 w-4 text-green-500" />
                <span>24/7 Uptime</span>
              </div>
            </div>
          </motion.div>
        </div>
      </section>

      <section className="section">
        <div className="container">
          <div className="mb-8 flex items-center justify-between">
            <h2 className="text-heading-lg text-white">All Bot Hosting Plans</h2>
            <div className="flex gap-2">
              <Button
                variant={viewMode === 'cards' ? 'default' : 'outline'}
                size="sm"
                onClick={() => setViewMode('cards')}
              >
                Cards
              </Button>
              <Button
                variant={viewMode === 'table' ? 'default' : 'outline'}
                size="sm"
                onClick={() => setViewMode('table')}
              >
                Table
              </Button>
            </div>
          </div>

          <AnimatePresence mode="wait">
            {viewMode === 'cards' ? (
              <motion.div
                key="cards"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -20 }}
                className="grid sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6"
              >
                {BOT_HOSTING_PLANS.map((plan, i) => (
                  <motion.div
                    key={plan.id}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: i * 0.05 }}
                  >
                    <PlanCard plan={plan} highlighted={plan.badge === 'popular'} onOrder={handleOrder} />
                  </motion.div>
                ))}
              </motion.div>
            ) : (
              <motion.div
                key="table"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -20 }}
              >
                <PlanComparisonTable plans={BOT_HOSTING_PLANS} category="bot" onOrder={handleOrder} />
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </section>

      <section className="section bg-gradient-to-b from-gray-950 to-black border-y border-gray-800">
        <div className="container">
          <h2 className="text-display-sm text-white text-center mb-12">Bot Hosting Features</h2>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6 mb-12">
            {[
              { icon: Cpu, title: 'AMD EPYC 7F72 CPU', desc: 'High-frequency EPYC processors optimized for bot workloads with consistent performance.' },
              { icon: Database, title: 'NVMe SSD Storage', desc: 'Fast NVMe storage for quick database operations and low-latency file I/O.' },
              { icon: Code, title: 'Multi-Runtime Support', desc: 'Native support for Node.js, Python, Java, Go, and PHP. Custom runtimes on request.' },
              { icon: Shield, title: 'DDoS Protection', desc: 'Enterprise-grade DDoS mitigation with game-specific filtering rules.' },
              { icon: Globe, title: '3 Global Locations', desc: 'India (Mumbai), Germany (Frankfurt), Singapore - deploy close to your users.' },
              { icon: Zap, title: 'Instant Deployment', desc: 'Git-based deployments with automatic dependency installation and process management.' },
            ].map((feature, i) => (
              <motion.div
                key={feature.title}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.08 }}
              >
                <Card variant="elevated" padding="lg" className="h-full">
                  <CardContent className="flex flex-col h-full">
                    <div className="h-12 w-12 rounded-xl bg-red-600/20 flex items-center justify-center mb-4">
                      <feature.icon className="h-6 w-6 text-red-500" />
                    </div>
                    <h3 className="text-heading-sm text-white mb-2">{feature.title}</h3>
                    <p className="text-body-sm text-gray-400 flex-1">{feature.desc}</p>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>

          <div className="mb-12">
            <h3 className="text-heading-md text-white mb-4 text-center">Supported Runtimes</h3>
            <div className="flex flex-wrap justify-center gap-3">
              {runtimes.map((runtime) => (
                <Badge key={runtime} variant="outline" className="text-sm px-4 py-2">
                  {runtime}
                </Badge>
              ))}
            </div>
          </div>

          <div className="grid md:grid-cols-3 gap-6">
            {[
              { icon: Terminal, title: 'Process Manager', desc: 'Built-in PM2/supervisor equivalent with auto-restart, log rotation, and health checks.' },
              { icon: Database, title: 'Database Included', desc: 'Redis, MongoDB, PostgreSQL, and SQLite available as managed add-ons.' },
              { icon: Shield, title: 'Environment Secrets', desc: 'Secure environment variable management with encryption at rest.' },
            ].map((feature, i) => (
              <motion.div
                key={feature.title}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.08 }}
              >
                <Card variant="elevated" padding="lg" className="h-full">
                  <CardContent className="flex flex-col h-full">
                    <div className="h-12 w-12 rounded-xl bg-red-600/20 flex items-center justify-center mb-4">
                      <feature.icon className="h-6 w-6 text-red-500" />
                    </div>
                    <h3 className="text-heading-sm text-white mb-2">{feature.title}</h3>
                    <p className="text-body-sm text-gray-400 flex-1">{feature.desc}</p>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      <section className="section">
        <div className="container">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
            >
              <h2 className="text-display-sm text-white mb-4">Built for Developers</h2>
              <p className="text-body-lg text-gray-400 mb-6">
                Deploy directly from Git, manage environment variables, view real-time logs,
                and scale resources vertically - all from a clean developer-focused dashboard.
              </p>
              <ul className="space-y-3 mb-8">
                {[
                  'Git-based deployments (GitHub, GitLab, Bitbucket)',
                  'Automatic dependency installation (npm, pip, maven, go mod, composer)',
                  'Real-time logs with search and filtering',
                  'Environment variable management with secret encryption',
                  'Vertical scaling with zero-downtime restart',
                  'Custom domain support with automatic SSL',
                  'Webhook notifications for deployments and errors',
                  'Cron job scheduler for recurring tasks',
                ].map((item, i) => (
                  <li key={i} className="flex items-center gap-3 text-gray-300">
                    <Check className="h-5 w-5 text-green-500 flex-shrink-0" />
                    <span>{item}</span>
                  </li>
                ))}
              </ul>
              <Button asChild size="lg" variant="premium">
                <Link href="/contact">Deploy Your Bot</Link>
              </Button>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: 0.1 }}
            >
              <div className="aspect-video rounded-2xl border border-gray-800 overflow-hidden bg-black/50 relative">
                <div className="absolute inset-0 bg-gradient-to-br from-red-600/10 via-transparent to-transparent" />
                <div className="relative h-full flex items-center justify-center p-8">
                  <div className="text-center max-w-md">
                    <div className="text-5xl font-bold text-red-500 gradient-text-red mb-2">{formatINR(59)}</div>
                    <div className="text-gray-400 mb-6">Starting per month</div>
                    <div className="grid grid-cols-3 gap-4 text-center">
                      <div className="p-4 bg-gray-900/50 rounded-xl border border-gray-800">
                        <div className="text-2xl font-bold text-white">6</div>
                        <div className="text-xs text-gray-400">Plans</div>
                      </div>
                      <div className="p-4 bg-gray-900/50 rounded-xl border border-gray-800">
                        <div className="text-2xl font-bold text-white">3</div>
                        <div className="text-xs text-gray-400">Locations</div>
                      </div>
                      <div className="p-4 bg-gray-900/50 rounded-xl border border-gray-800">
                        <div className="text-2xl font-bold text-white">5</div>
                        <div className="text-xs text-gray-400">Runtimes</div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      <section className="section bg-gradient-to-b from-gray-950 to-black border-y border-gray-800">
        <div className="container text-center">
          <h2 className="text-display-sm text-white mb-4">Ready to Host Your Bot?</h2>
          <p className="text-body-lg text-gray-400 mb-8 max-w-2xl mx-auto">
            Deploy your Discord bot in minutes. Choose your plan, connect your repository, and go live.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button asChild size="lg" variant="premium">
              <Link href="/contact">Get Started</Link>
            </Button>
            <Button asChild size="lg" variant="secondary">
              <Link href={DISCORD_INVITE} target="_blank" rel="noopener noreferrer">
                Join Discord
              </Link>
            </Button>
          </div>
        </div>
      </section>
    </>
  );
}