import { Metadata } from 'next';
import { motion } from 'framer-motion';
import { Check, Shield, Zap, Globe, Clock, Cpu, HardDrive, Server, Network, Database, Lock, Monitor, ArrowRight, Terminal, Code } from 'lucide-react';
import { LinkButton } from '@/components/ui/link-button';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { INFRASTRUCTURE_CLAIMS, DISCORD_INVITE, formatINR } from '@/data/plans';
import { generateMetadata } from '@/lib/seo';

export const metadata: Metadata = generateMetadata({
  title: 'Features & Infrastructure',
  description: 'Enterprise-grade infrastructure with DDoS protection, global locations, instant setup, and 24/7 support. AMD EPYC & Ryzen hardware.',
  path: '/features',
});

const features = [
  {
    category: 'Performance',
    items: [
      { icon: Cpu, title: 'AMD EPYC & Ryzen CPUs', desc: 'Latest generation AMD EPYC 7F72, Ryzen 9000 Series, and Intel Xeon Platinum/ v4 processors.' },
      { icon: Zap, title: 'NVMe & Gen 5 SSD Storage', desc: 'High-speed NVMe for VPS/bots, Gen 5 SATA SSD for Minecraft, Gen 5 SSD for dedicated.' },
      { icon: Server, title: 'DDR4 ECC Memory', desc: 'Error-correcting memory for data integrity across all hosting services.' },
      { icon: Network, title: '10 Gbps Network Uplinks', desc: 'High-capacity network connectivity with burst capability.' },
    ],
  },
  {
    category: 'Security',
    items: [
      { icon: Shield, title: 'Cloudflare Magic Transit', desc: 'Enterprise DDoS protection at network edge with 150 Gbps filtering capacity.' },
      { icon: Lock, title: 'Custom BPF/eBPF Rules', desc: 'Game-specific traffic filtering at kernel level for Minecraft and other protocols.' },
      { icon: Shield, title: 'Inline XDP Filtering', desc: 'eXpress Data Path processing at 150 Gbps for sub-microsecond attack detection.' },
      { icon: Database, title: 'Isolated Tenancy', desc: 'Hardware-level isolation for dedicated, container isolation for VPS and bot hosting.' },
    ],
  },
  {
    category: 'Reliability',
    items: [
      { icon: Clock, title: '99.97% Uptime SLA', desc: 'Redundant power, network, and cooling with automated failover systems.' },
      { icon: Database, title: 'Automated Backups', desc: 'Daily backups with 7-day retention. Free for dedicated, included for VPS/bots.' },
      { icon: Monitor, title: 'Real-Time Monitoring', desc: 'Resource metrics, alerting, and health checks accessible via control panel.' },
      { icon: ArrowRight, title: 'Auto Recovery', desc: 'Automatic service restart and failover on hardware or software failures.' },
    ],
  },
  {
    category: 'Developer Experience',
    items: [
      { icon: Globe, title: 'Global Locations', desc: 'India (owned), Germany & Singapore (rented), 8+ locations coming soon.' },
      { icon: Terminal, title: 'Full Root/SSH Access', desc: 'Complete control over your VPS and dedicated servers.' },
      { icon: Code, title: 'Custom ISO Support', desc: 'Upload and boot your own operating system images on VPS.' },
      { icon: Network, title: 'API & Webhooks', desc: 'Programmatic control for automation and integration (coming soon).' },
    ],
  },
];

const stats = [
  { value: '2.4 Tbps', label: 'Largest Mitigated Attack', verified: false },
  { value: '< 1 μs', label: 'Attack Detection Time', verified: false },
  { value: '150 Gbps', label: 'Inline Filtering Capacity', verified: false },
  { value: '99.97%', label: 'Uptime SLA', verified: false },
  { value: '3', label: 'Current Locations', verified: true },
  { value: '4', label: 'CPU Families', verified: true },
];

export default function FeaturesPage() {
  return (
    <>
      <section className="relative min-h-[50vh] flex items-center overflow-hidden">
        <div className="absolute inset-0 bg-radial-bottom" />
        <div className="absolute inset-0 bg-grid" />

        <div className="relative z-10 container py-16 lg:py-24">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="max-w-3xl"
          >
            <Badge variant="premium" className="mb-4">Infrastructure</Badge>
            <h1 className="text-display-lg text-white mb-4">Features & Infrastructure</h1>
            <p className="text-body-lg text-gray-400 mb-8">
              Enterprise-grade hosting infrastructure built on AMD EPYC & Ryzen hardware
              with Cloudflare Magic Transit DDoS protection and global reach.
            </p>
            <div className="flex flex-col sm:flex-row gap-4">
              <LinkButton href="/contact" size="lg" variant="premium">
                Get Started
              </LinkButton>
              <LinkButton href={DISCORD_INVITE} target="_blank" rel="noopener noreferrer" size="lg" variant="secondary">
                Technical Questions
              </LinkButton>
            </div>
          </motion.div>
        </div>
      </section>

      <section className="section">
        <div className="container">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-16 max-w-5xl mx-auto"
          >
            {stats.map((stat, i) => (
              <motion.div
                key={stat.label}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.1 }}
                className="text-center p-6 card-base card-hover rounded-xl"
              >
                <div className="text-3xl sm:text-4xl font-bold text-red-500 gradient-text-red mb-1">
                  {stat.value}
                </div>
                <div className="text-sm text-gray-400">{stat.label}</div>
                {!stat.verified && (
                  <Badge variant="warning" size="sm" className="mt-2">Provider Claimed</Badge>
                )}
              </motion.div>
            ))}
          </motion.div>

          {features.map((category, catIndex) => (
            <motion.section
              key={category.category}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: catIndex * 0.1 }}
              className="mb-20"
            >
              <div className="flex items-center gap-4 mb-10">
                <div className="h-1 w-full bg-gradient-to-r from-red-600 to-transparent" />
                <h2 className="text-heading-lg text-white">{category.category}</h2>
                <div className="h-1 w-full bg-gradient-to-l from-red-600 to-transparent" />
              </div>

              <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
                {category.items.map((feature, i) => (
                  <motion.article
                    key={feature.title}
                    initial={{ opacity: 0, y: 20 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    viewport={{ once: true }}
                    transition={{ delay: i * 0.05 }}
                  >
                    <Card variant="elevated" padding="lg" className="h-full group">
                      <CardContent className="flex flex-col h-full">
                        <div className="h-12 w-12 rounded-xl bg-red-600/20 flex items-center justify-center mb-4 group-hover:scale-110 transition-transform">
                          <feature.icon className="h-6 w-6 text-red-500" />
                        </div>
                        <h3 className="text-heading-sm text-white mb-2">{feature.title}</h3>
                        <p className="text-body-sm text-gray-400 flex-1">{feature.desc}</p>
                      </CardContent>
                    </Card>
                  </motion.article>
                ))}
              </div>
            </motion.section>
          ))}

          <div className="border-t border-gray-800 pt-12">
            <h3 className="text-heading-md text-white text-center mb-4">Provider-Stated Claims</h3>
            <p className="text-gray-400 text-center mb-8 max-w-2xl mx-auto">
              The following are claims made by the provider. We recommend independent verification for critical requirements.
            </p>
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4 max-w-5xl mx-auto">
              {INFRASTRUCTURE_CLAIMS.map((claim, i) => (
                <motion.div
                  key={claim.claim}
                  initial={{ opacity: 0, scale: 0.95 }}
                  whileInView={{ opacity: 1, scale: 1 }}
                  viewport={{ once: true }}
                  transition={{ delay: i * 0.03 }}
                >
                  <div className="p-4 card-base rounded-xl">
                    <div className="font-medium text-white">{claim.claim}</div>
                    <div className="text-sm text-gray-400 mt-1">{claim.detail}</div>
                    {!claim.verified && (
                      <Badge variant="warning" size="sm" className="mt-2">Unverified</Badge>
                    )}
                  </div>
                </motion.div>
              ))}
            </div>
          </div>
        </div>
      </section>

      <section className="section bg-gradient-to-b from-gray-950 to-black border-y border-gray-800">
        <div className="container text-center">
          <h2 className="text-display-sm text-white mb-4">Experience the Difference</h2>
          <p className="text-body-lg text-gray-400 mb-8 max-w-2xl mx-auto">
            Deploy on infrastructure built for performance, security, and reliability.
            Join thousands of developers and gamers on ZENITHZcloud.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <LinkButton href="/contact" size="lg" variant="premium">
              Deploy Now
            </LinkButton>
            <LinkButton href={DISCORD_INVITE} target="_blank" rel="noopener noreferrer" size="lg" variant="secondary">
              Technical Discussion
            </LinkButton>
          </div>
        </div>
      </section>
    </>
  );
}