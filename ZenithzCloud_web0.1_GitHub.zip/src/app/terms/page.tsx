import { Metadata } from 'next';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { DISCORD_INVITE, WEBSITE_URL } from '@/data/plans';
import { generateMetadata } from '@/lib/seo';

export const metadata: Metadata = generateMetadata({
  title: 'Terms of Service',
  description: 'ZENITHZcloud Terms of Service - Terms and conditions for using our hosting services.',
  path: '/terms',
});

const lastUpdated = 'October 26, 2026';
const effectiveDate = 'October 26, 2026';

export default function TermsPage() {
  return (
    <>
      <section className="relative min-h-[40vh] flex items-center overflow-hidden">
        <div className="absolute inset-0 bg-radial-bottom" />
        <div className="absolute inset-0 bg-grid" />

        <div className="relative z-10 container py-16 lg:py-24">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="max-w-3xl"
          >
            <Badge variant="premium" className="mb-4">Legal</Badge>
            <h1 className="text-display-lg text-white mb-4">Terms of Service</h1>
            <p className="text-body-lg text-gray-400 mb-4">
              Last updated: {lastUpdated} | Effective: {effectiveDate}
            </p>
            <p className="text-body text-gray-500">
              By using ZENITHZcloud services, you agree to these terms.
            </p>
          </motion.div>
        </div>
      </section>

      <section className="section">
        <div className="container max-w-4xl">
          <div className="space-y-12">
            <LegalSection number="1" title="Acceptance of Terms">
              <p className="text-gray-300 mb-4">
                By accessing or using ZENITHZcloud services ("Services"), you ("Customer", "You") agree to be bound by these Terms of Service ("Terms").
                If you do not agree, you may not use our Services.
              </p>
            </LegalSection>

            <LegalSection number="2" title="Services Description">
              <p className="text-gray-300 mb-4">
                ZENITHZcloud provides infrastructure hosting services including:
              </p>
              <ul className="list-disc list-inside space-y-2 text-gray-300 mb-4">
                <li>Minecraft server hosting</li>
                <li>Virtual Private Server (VPS) hosting</li>
                <li>Dedicated bare-metal server hosting</li>
                <li>Discord bot hosting</li>
                <li>Related infrastructure and support services</li>
              </ul>
              <p className="text-gray-300">
                Service specifications, pricing, and availability are described on our website and may change with notice.
              </p>
            </LegalSection>

            <LegalSection number="3" title="Account Registration">
              <p className="text-gray-300 mb-4">
                To use certain Services, you must create an account. You agree to:
              </p>
              <ul className="list-disc list-inside space-y-2 text-gray-300 mb-4">
                <li>Provide accurate, current, and complete information</li>
                <li>Maintain the security of your account credentials</li>
                <li>Accept responsibility for all activities under your account</li>
                <li>Notify us immediately of any unauthorized access</li>
              </ul>
              <p className="text-gray-300">
                We reserve the right to refuse service, terminate accounts, or remove content at our discretion.
              </p>
            </LegalSection>

            <LegalSection number="4" title="Billing & Payments">
              <p className="text-gray-300 mb-4">
                <strong>Pricing:</strong> All prices are in Indian Rupees (INR) unless otherwise stated. Taxes may apply.
              </p>
              <p className="text-gray-300 mb-4">
                <strong>Billing Cycle:</strong> Services are billed monthly in advance. Payment is due on the invoice date.
              </p>
              <p className="text-gray-300 mb-4">
                <strong>Payment Methods:</strong> We accept UPI, credit/debit cards, net banking, and cryptocurrency.
              </p>
              <p className="text-gray-300 mb-4">
                <strong>Late Payments:</strong> Services may be suspended for non-payment after 7 days past due.
                A reactivation fee may apply.
              </p>
              <p className="text-gray-300 mb-4">
                <strong>Price Changes:</strong> We may modify prices with 30 days' notice via email and Discord.
              </p>
            </LegalSection>

            <LegalSection number="5" title="Acceptable Use Policy">
              <p className="text-gray-300 mb-4">
                You agree not to use our Services for:
              </p>
              <ul className="list-disc list-inside space-y-2 text-gray-300 mb-4">
                <li>Illegal activities or content violating applicable laws</li>
                <li>Distribution of malware, viruses, or malicious code</li>
                <li>Spam, phishing, or unsolicited bulk communications</li>
                <li>DDoS attacks, port scanning, or network abuse</li>
                <li>Hosting copyrighted content without authorization</li>
                <li>Cryptocurrency mining (except on dedicated servers with prior approval)</li>
                <li>TOR exit nodes, VPN services, or proxy services</li>
                <li>Any activity that degrades service for other customers</li>
              </ul>
              <p className="text-gray-300">
                We reserve the right to suspend or terminate services for violations without refund.
              </p>
            </LegalSection>

            <LegalSection number="6" title="Service Level & Uptime">
              <p className="text-gray-300 mb-4">
                We target 99.97% monthly uptime for all Services. This excludes:
              </p>
              <ul className="list-disc list-inside space-y-2 text-gray-300 mb-4">
                <li>Scheduled maintenance (announced 48 hours in advance)</li>
                <li>Emergency maintenance for security/critical issues</li>
                <li>Force majeure events</li>
                <li>Customer-caused issues (misconfiguration, resource exhaustion)</li>
                <li>DDoS attacks exceeding protection capacity</li>
              </ul>
              <p className="text-gray-300">
                SLA credits for verified downtime exceeding the guarantee are detailed in our SLA document.
              </p>
            </LegalSection>

            <LegalSection number="7" title="Intellectual Property">
              <p className="text-gray-300 mb-4">
                All ZENITHZcloud branding, software, control panels, APIs, and documentation are our property
                or licensed to us. You retain ownership of your content and data. You grant us a limited license
                to host, process, and transmit your data as necessary to provide Services.
              </p>
            </LegalSection>

            <LegalSection number="8" title="Data & Backups">
              <p className="text-gray-300 mb-4">
                <strong>Your Responsibility:</strong> You are responsible for your own data backups.
                While we provide automated backups for certain plans, these are for disaster recovery only
                and not guaranteed for point-in-time recovery.
              </p>
              <p className="text-gray-300 mb-4">
                <strong>Data Location:</strong> Data is stored in the region you select (India, Germany, Singapore).
                You are responsible for compliance with local data protection laws.
              </p>
            </LegalSection>

            <LegalSection number="9" title="Limitation of Liability">
              <p className="text-gray-300 mb-4">
                TO THE MAXIMUM EXTENT PERMITTED BY LAW:
              </p>
              <ul className="list-disc list-inside space-y-2 text-gray-300 mb-4">
                <li>Our total liability shall not exceed the fees paid by you in the 3 months preceding the claim</li>
                <li>We are not liable for indirect, incidental, special, consequential, or punitive damages</li>
                <li>We are not liable for data loss, lost profits, or business interruption</li>
                <li>We do not warrant Services will be uninterrupted, error-free, or secure</li>
              </ul>
            </LegalSection>

            <LegalSection number="10" title="Indemnification">
              <p className="text-gray-300 mb-4">
                You agree to indemnify and hold ZENITHZcloud harmless from any claims, damages, losses,
                or expenses (including legal fees) arising from your use of Services, violation of these Terms,
                or infringement of third-party rights.
              </p>
            </LegalSection>

            <LegalSection number="11" title="Termination">
              <p className="text-gray-300 mb-4">
                Either party may terminate this agreement:
              </p>
              <ul className="list-disc list-inside space-y-2 text-gray-300 mb-4">
                <li>Customer: At any time by cancelling services in the control panel</li>
                <li>ZENITHZcloud: For material breach, non-payment, or AUP violation</li>
                <li>ZENITHZcloud: With 30 days' notice for business reasons</li>
              </ul>
              <p className="text-gray-300">
                Upon termination, services cease immediately. Data is retained per our Privacy Policy.
                No refunds for early termination except as per Refund Policy.
              </p>
            </LegalSection>

            <LegalSection number="12" title="Governing Law & Disputes">
              <p className="text-gray-300 mb-4">
                These Terms are governed by the laws of India. Disputes shall be resolved in the courts of Mumbai, Maharashtra.
                We encourage informal resolution via Discord support before formal proceedings.
              </p>
            </LegalSection>

            <LegalSection number="13" title="Changes to Terms">
              <p className="text-gray-300 mb-4">
                We may modify these Terms with 30 days' notice via email and Discord.
                Continued use after changes constitutes acceptance.
              </p>
            </LegalSection>

            <LegalSection number="14" title="Contact">
              <p className="text-gray-300 mb-4">
                Questions about these Terms:
              </p>
              <ul className="space-y-2 text-gray-300">
                <li>Email: legal@zenithzcloud.com</li>
                <li>Discord: <a href={DISCORD_INVITE} target="_blank" rel="noopener noreferrer" className="text-red-500 hover:underline">discord.gg/9gGknK6VWw</a></li>
                <li>Website: <a href={WEBSITE_URL} target="_blank" rel="noopener noreferrer" className="text-red-500 hover:underline">zenithzcloud.com</a></li>
              </ul>
            </LegalSection>
          </div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="mt-16 p-6 bg-gray-900/50 border border-gray-800 rounded-xl"
          >
            <Badge variant="warning" className="mb-4">Draft Document</Badge>
            <h3 className="text-heading-md text-white mb-3">Important Notice</h3>
            <p className="text-gray-400">
              These Terms of Service are a draft based on standard hosting provider practices and the master prompt specifications.
              They have not been reviewed by legal counsel. The website owner must review, customize, and approve this document
              before it can be considered legally binding. Do not publish this version without legal review.
            </p>
          </motion.div>
        </div>
      </section>
    </>
  );
}

function LegalSection({ number, title, children }: { number: string; title: string; children: React.ReactNode }) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
    >
      <div className="flex items-start gap-4">
        <div className="flex-shrink-0 w-10 h-10 rounded-full bg-red-600/20 flex items-center justify-center text-red-500 font-bold text-lg">
          {number}
        </div>
        <div className="flex-1">
          <h2 className="text-heading-md text-white mb-4">{title}</h2>
          <div className="pl-10 border-l border-gray-800">
            {children}
          </div>
        </div>
      </div>
    </motion.div>
  );
}