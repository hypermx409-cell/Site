'use client';

import * as React from 'react';
import { motion } from 'framer-motion';
import { Mail, MessageSquare, MapPin, Clock, Shield, Check, Loader2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { DISCORD_INVITE } from '@/data/plans';

export default function ContactPage() {
  const [formState, setFormState] = React.useState<'idle' | 'submitting' | 'success' | 'error'>('idle');
  const [formData, setFormData] = React.useState({
    name: '',
    email: '',
    subject: '',
    message: '',
  });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setFormState('submitting');
    // Simulate API call
    await new Promise(resolve => setTimeout(resolve, 1500));
    setFormState('success');
    setFormData({ name: '', email: '', subject: '', message: '' });
    setTimeout(() => setFormState('idle'), 5000);
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    setFormData(prev => ({ ...prev, [e.target.name]: e.target.value }));
  };

  const contactMethods = [
    {
      icon: MessageSquare,
      title: 'Discord (Fastest)',
      description: 'Join our community for instant support, announcements, and peer help.',
      action: 'Join Discord',
      href: DISCORD_INVITE,
      external: true,
      primary: true,
    },
    {
      icon: Mail,
      title: 'Email Support',
      description: 'Send us a detailed ticket. We respond within 4 hours during business hours.',
      action: 'Email Us',
      href: 'mailto:support@zenithzcloud.com',
      external: false,
    },
    {
      icon: MessageSquare,
      title: 'Contact Form',
      description: 'Fill out the form below for sales inquiries or technical questions.',
      action: 'Use Form Below',
      href: '#contact-form',
      external: false,
    },
  ];

  return (
    <>
      <section className="relative min-h-[50vh] flex items-center overflow-hidden">
        <div className="absolute inset-0 bg-radial-bottom" />
        <div className="absolute inset-0 bg-grid" />

        <div className="relative z-10 container py-16 lg:py-24">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="max-w-3xl"
          >
            <Badge variant="premium" className="mb-4">Get in Touch</Badge>
            <h1 className="text-display-lg text-white mb-4">Contact Us</h1>
            <p className="text-body-lg text-gray-400 mb-8">
              Have questions? Our team is ready to help. Choose your preferred contact method below.
            </p>
          </motion.div>
        </div>
      </section>

      <section className="section">
        <div className="container">
          <div className="grid lg:grid-cols-3 gap-8 mb-16">
            {contactMethods.map((method, i) => (
              <motion.article
                key={method.title}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.1 }}
              >
                <Card variant={method.primary ? 'premium' : 'elevated'} padding="lg" className="h-full">
                  <CardContent className="flex flex-col h-full">
                    <div className="h-12 w-12 rounded-xl bg-red-600/20 flex items-center justify-center mb-4">
                      <method.icon className="h-6 w-6 text-red-500" />
                    </div>
                    <h3 className="text-heading-md text-white mb-2">{method.title}</h3>
                    <p className="text-body-sm text-gray-400 flex-1 mb-4">{method.description}</p>
                    <Button
                      variant={method.primary ? 'premium' : 'outline'}
                      className="w-full"
                      asChild
                    >
                      <a
                        href={method.href}
                        target={method.external ? '_blank' : undefined}
                        rel={method.external ? 'noopener noreferrer' : undefined}
                      >
                        {method.action}
                      </a>
                    </Button>
                  </CardContent>
                </Card>
              </motion.article>
            ))}
          </div>

          <div className="grid lg:grid-cols-2 gap-12">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              id="contact-form"
            >
              <Card variant="elevated" padding="xl">
                <h2 className="text-heading-lg text-white mb-6">Send Us a Message</h2>

                {formState === 'success' ? (
                  <motion.div
                    initial={{ opacity: 0, scale: 0.95 }}
                    animate={{ opacity: 1, scale: 1 }}
                    className="text-center py-12"
                  >
                    <Check className="h-16 w-16 text-green-500 mx-auto mb-4" />
                    <h3 className="text-heading-md text-white mb-2">Message Sent!</h3>
                    <p className="text-gray-400 mb-6">We'll get back to you within 4 hours.</p>
                    <Button variant="outline" onClick={() => setFormState('idle')}>
                      Send Another Message
                    </Button>
                  </motion.div>
                ) : (
                  <form onSubmit={handleSubmit} className="space-y-6" noValidate>
                    <div className="grid sm:grid-cols-2 gap-4">
                      <div>
                        <Label htmlFor="name">Name</Label>
                        <Input
                          id="name"
                          name="name"
                          value={formData.name}
                          onChange={handleChange}
                          placeholder="Your name"
                          required
                          disabled={formState === 'submitting'}
                        />
                      </div>
                      <div>
                        <Label htmlFor="email">Email</Label>
                        <Input
                          id="email"
                          name="email"
                          type="email"
                          value={formData.email}
                          onChange={handleChange}
                          placeholder="your@email.com"
                          required
                          disabled={formState === 'submitting'}
                        />
                      </div>
                    </div>

                    <div>
                      <Label htmlFor="subject">Subject</Label>
                      <select
                        id="subject"
                        name="subject"
                        value={formData.subject}
                        onChange={handleChange}
                        className="input-base"
                        required
                        disabled={formState === 'submitting'}
                      >
                        <option value="">Select a topic</option>
                        <option value="sales">Sales & Pricing</option>
                        <option value="technical">Technical Support</option>
                        <option value="billing">Billing & Payments</option>
                        <option value="partnership">Partnership & Reseller</option>
                        <option value="abuse">Abuse Report</option>
                        <option value="other">Other</option>
                      </select>
                    </div>

                    <div>
                      <Label htmlFor="message">Message</Label>
                      <Textarea
                        id="message"
                        name="message"
                        value={formData.message}
                        onChange={handleChange}
                        placeholder="Describe your inquiry in detail..."
                        rows={5}
                        required
                        disabled={formState === 'submitting'}
                      />
                    </div>

                    <Button
                      type="submit"
                      size="lg"
                      variant="premium"
                      className="w-full"
                      loading={formState === 'submitting'}
                    >
                      {formState === 'submitting' ? 'Sending...' : 'Send Message'}
                    </Button>
                  </form>
                )}
              </Card>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: 0.1 }}
            >
              <Card variant="elevated" padding="xl" className="h-full">
                <h2 className="text-heading-lg text-white mb-6">Support Hours & Info</h2>

                <div className="space-y-6 mb-8">
                  {[
                    { icon: Clock, title: 'Support Hours', desc: '24/7/365 via Discord. Email tickets responded within 4 business hours.' },
                    { icon: Shield, title: 'Response Times', desc: 'Critical: < 30 min | High: < 2 hours | Normal: < 4 hours | Low: < 24 hours' },
                    { icon: MapPin, title: 'Headquarters', desc: 'Mumbai, Maharashtra, India (Registered Office)' },
                    { icon: MessageSquare, title: 'Community', desc: 'discord.gg/9gGknK6VWw — 2,000+ members' },
                  ].map((item, i) => (
                    <div key={item.title} className="flex items-start gap-4">
                      <div className="h-10 w-10 rounded-lg bg-red-600/20 flex items-center justify-center flex-shrink-0">
                        <item.icon className="h-5 w-5 text-red-500" />
                      </div>
                      <div>
                        <h3 className="text-white font-medium">{item.title}</h3>
                        <p className="text-sm text-gray-400 mt-1">{item.desc}</p>
                      </div>
                    </div>
                  ))}
                </div>

                <div className="border-t border-gray-800 pt-6">
                  <h3 className="text-white font-medium mb-4">Before You Contact</h3>
                  <ul className="space-y-3 text-sm text-gray-300">
                    {[
                      'Check our FAQ for common questions',
                      'Join Discord for fastest community support',
                      'Have your order/service ID ready for billing issues',
                      'Include error logs for technical problems',
                      'Check status page for ongoing incidents',
                    ].map((item, i) => (
                      <li key={i} className="flex items-center gap-3">
                        <Check className="h-4 w-4 text-green-500 flex-shrink-0" />
                        <span>{item}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              </Card>
            </motion.div>
          </div>
        </div>
      </section>

      <section className="section bg-gradient-to-b from-gray-950 to-black border-y border-gray-800">
        <div className="container">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="grid md:grid-cols-3 gap-8 text-center"
          >
            {[
              { icon: Shield, title: 'DDoS Protected', desc: 'All services include enterprise DDoS mitigation' },
              { icon: Clock, title: '99.97% Uptime', desc: 'Redundant infrastructure with auto-failover' },
              { icon: MessageSquare, title: '24/7 Support', desc: 'Expert team available via Discord and tickets' },
            ].map((item, i) => (
              <div key={item.title}>
                <div className="h-14 w-14 rounded-xl bg-red-600/20 flex items-center justify-center mx-auto mb-4">
                  <item.icon className="h-7 w-7 text-red-500" />
                </div>
                <h3 className="text-heading-sm text-white mb-2">{item.title}</h3>
                <p className="text-gray-400">{item.desc}</p>
              </div>
            ))}
          </motion.div>
        </div>
      </section>
    </>
  );
}