'use client';

import * as React from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import Link from 'next/link';
import { ArrowRight, Check, Cpu, Shield, Zap, Globe, Clock, HardDrive, Loader2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { CPUSelector, PlanCard, PlanComparisonTable } from '@/components/pricing/pricing-components';
import { formatINR, getVPSPlansByCPU, getUniqueVPSGPUs, CPU_FAMILIES, type VPSPlan, type CPUFamily, type AnyPlan, DISCORD_INVITE, VPS_OS_OPTIONS } from '@/data/plans';

const cpuFamilies = getUniqueVPSGPUs();

export default function VPSPage() {
  const [selectedCPU, setSelectedCPU] = React.useState<CPUFamily>(cpuFamilies[0]);
  const [viewMode, setViewMode] = React.useState<'cards' | 'table'>('cards');
  const [orderingPlan, setOrderingPlan] = React.useState<string | null>(null);

  const plans = getVPSPlansByCPU(selectedCPU);

  const handleOrder = (plan: AnyPlan) => {
    setOrderingPlan(plan.id);
    window.open(DISCORD_INVITE, '_blank', 'noopener,noreferrer');
    setTimeout(() => setOrderingPlan(null), 2000);
  };

  return (
    <>
      <section className="relative min-h-[50vh] flex items-center overflow-hidden">
        <div className="absolute inset-0 bg-radial-bottom" />
        <div className="absolute inset-0 bg-grid" />

        <div className="relative z-10 container py-16 lg:py-24">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="max-w-3xl"
          >
            <Badge variant="premium" className="mb-4">VPS Hosting</Badge>
            <h1 className="text-display-lg text-white mb-4">VPS Hosting</h1>
            <p className="text-body-lg text-gray-400 mb-6">
              High-performance virtual private servers on AMD Ryzen 9000 Series and EPYC 7F72.
              NVMe storage, root access, and full OS control.
            </p>
            <div className="flex flex-wrap gap-4 text-sm text-gray-400">
              <div className="flex items-center gap-2">
                <Check className="h-4 w-4 text-green-500" />
                <span>NVMe SSD Storage</span>
              </div>
              <div className="flex items-center gap-2">
                <Check className="h-4 w-4 text-green-500" />
                <span>Root & SSH Access</span>
              </div>
              <div className="flex items-center gap-2">
                <Check className="h-4 w-4 text-green-500" />
                <span>Custom ISO Support</span>
              </div>
              <div className="flex items-center gap-2">
                <Check className="h-4 w-4 text-green-500" />
                <span>Browser Console</span>
              </div>
              <div className="flex items-center gap-2">
                <Check className="h-4 w-4 text-green-500" />
                <span>Snapshots & Backups</span>
              </div>
              <div className="flex items-center gap-2">
                <Check className="h-4 w-4 text-green-500" />
                <span>Resource Monitoring</span>
              </div>
            </div>
          </motion.div>
        </div>
      </section>

      <section className="section">
        <div className="container">
          <div className="mb-8">
            <CPUSelector
              category="vps"
              selectedCPU={selectedCPU}
              onSelect={setSelectedCPU}
            />
          </div>

          <div className="mb-8 flex items-center justify-between">
            <h2 className="text-heading-lg text-white">
              All {CPU_FAMILIES[selectedCPU].name} Plans
            </h2>
            <div className="flex gap-2">
              <Button
                variant={viewMode === 'cards' ? 'default' : 'outline'}
                size="sm"
                onClick={() => setViewMode('cards')}
              >
                Cards
              </Button>
              <Button
                variant={viewMode === 'table' ? 'default' : 'outline'}
                size="sm"
                onClick={() => setViewMode('table')}
              >
                Table
              </Button>
            </div>
          </div>

          <AnimatePresence mode="wait">
            {viewMode === 'cards' ? (
              <motion.div
                key="cards"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -20 }}
                className="grid sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6"
              >
                {plans.map((plan, i) => (
                  <motion.div
                    key={plan.id}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: i * 0.05 }}
                  >
                    <PlanCard plan={plan} highlighted={plan.badge === 'popular'} onOrder={handleOrder} />
                  </motion.div>
                ))}
              </motion.div>
            ) : (
              <motion.div
                key="table"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -20 }}
              >
                <PlanComparisonTable plans={plans} category="vps" onOrder={handleOrder} />
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </section>

      <section className="section bg-gradient-to-b from-gray-950 to-black border-y border-gray-800">
        <div className="container">
          <h2 className="text-display-sm text-white text-center mb-12">VPS Features</h2>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6 mb-12">
            {[
              { icon: Cpu, title: 'AMD Ryzen 9000 Series', desc: 'Latest Zen 5 architecture with exceptional single-thread performance for responsive workloads.' },
              { icon: Cpu, title: 'AMD EPYC 7F72', desc: 'Enterprise-grade EPYC processors with high core counts for multi-threaded applications.' },
              { icon: HardDrive, title: 'Gen 5 NVMe Storage', desc: 'Lightning-fast NVMe SSDs for superior I/O performance and database workloads.' },
              { icon: Shield, title: 'DDoS Protection', desc: 'Cloudflare Magic Transit with 150 Gbps filtering capacity and custom rules.' },
              { icon: Globe, title: 'Full Root Access', desc: 'Complete root/SSH access with browser-based console for emergency recovery.' },
              { icon: Zap, title: 'OS Freedom', desc: 'Ubuntu, Windows, Fedora, Debian, Kali Linux, and Custom ISO support.' },
            ].map((feature, i) => (
              <motion.div
                key={feature.title}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.08 }}
              >
                <Card variant="elevated" padding="lg" className="h-full">
                  <CardContent className="flex flex-col h-full">
                    <div className="h-12 w-12 rounded-xl bg-red-600/20 flex items-center justify-center mb-4">
                      <feature.icon className="h-6 w-6 text-red-500" />
                    </div>
                    <h3 className="text-heading-sm text-white mb-2">{feature.title}</h3>
                    <p className="text-body-sm text-gray-400 flex-1">{feature.desc}</p>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>

          <div className="mb-12">
            <h3 className="text-heading-md text-white mb-4">Supported Operating Systems</h3>
            <div className="flex flex-wrap gap-3">
              {VPS_OS_OPTIONS.map((os) => (
                <Badge key={os} variant="outline" className="text-sm px-4 py-2">
                  {os}
                </Badge>
              ))}
            </div>
          </div>

          <div className="grid md:grid-cols-3 gap-6">
            {[
              { icon: Shield, title: 'Snapshot & Backup', desc: 'Create instant snapshots before changes. Automated daily backups with 7-day retention.' },
              { icon: Globe, title: 'Network Tools', desc: 'IP management, reverse DNS, firewall rules, and bandwidth monitoring in control panel.' },
              { icon: Clock, title: 'Resource Monitoring', desc: 'Real-time CPU, RAM, disk, and network graphs with alerting capabilities.' },
            ].map((feature, i) => (
              <motion.div
                key={feature.title}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.08 }}
              >
                <Card variant="elevated" padding="lg" className="h-full">
                  <CardContent className="flex flex-col h-full">
                    <div className="h-12 w-12 rounded-xl bg-red-600/20 flex items-center justify-center mb-4">
                      <feature.icon className="h-6 w-6 text-red-500" />
                    </div>
                    <h3 className="text-heading-sm text-white mb-2">{feature.title}</h3>
                    <p className="text-body-sm text-gray-400 flex-1">{feature.desc}</p>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      <section className="section">
        <div className="container">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
            >
              <h2 className="text-display-sm text-white mb-4">Full Control Panel Access</h2>
              <p className="text-body-lg text-gray-400 mb-6">
                Manage your VPS with our intuitive control panel. Reinstall OS, manage snapshots,
                configure networking, and monitor resources - all from your browser.
              </p>
              <ul className="space-y-3">
                {[
                  'One-click OS reinstall (Ubuntu, Windows, Fedora, Debian, Kali, Custom ISO)',
                  'Snapshot creation and management',
                  'Automated daily backups with 7-day retention',
                  'Firewall and security group configuration',
                  'Resource usage graphs and alerting',
                  'Console access (VNC/Serial) for recovery',
                  'IP management and reverse DNS',
                  'Startup scripts and cloud-init support',
                ].map((item, i) => (
                  <li key={i} className="flex items-center gap-3 text-gray-300">
                    <Check className="h-5 w-5 text-green-500 flex-shrink-0" />
                    <span>{item}</span>
                  </li>
                ))}
              </ul>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: 0.1 }}
            >
              <div className="aspect-video rounded-2xl border border-gray-800 overflow-hidden bg-black/50 relative">
                <div className="absolute inset-0 bg-gradient-to-br from-red-600/10 via-transparent to-transparent" />
                <div className="relative h-full flex items-center justify-center p-8">
                  <div className="text-center max-w-md">
                    <div className="text-5xl font-bold text-red-500 gradient-text-red mb-2">₹179</div>
                    <div className="text-gray-400 mb-6">Starting per GB/month (Ryzen 9000)</div>
                    <div className="grid grid-cols-3 gap-4 text-center">
                      <div className="p-4 bg-gray-900/50 rounded-xl border border-gray-800">
                        <div className="text-2xl font-bold text-white">2</div>
                        <div className="text-xs text-gray-400">CPU Options</div>
                      </div>
                      <div className="p-4 bg-gray-900/50 rounded-xl border border-gray-800">
                        <div className="text-2xl font-bold text-white">10</div>
                        <div className="text-xs text-gray-400">RAM Configs</div>
                      </div>
                      <div className="p-4 bg-gray-900/50 rounded-xl border border-gray-800">
                        <div className="text-2xl font-bold text-white">7+</div>
                        <div className="text-xs text-gray-400">OS Options</div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      <section className="section bg-gradient-to-b from-gray-950 to-black border-y border-gray-800">
        <div className="container text-center">
          <h2 className="text-display-sm text-white mb-4">Deploy Your VPS Today</h2>
          <p className="text-body-lg text-gray-400 mb-8 max-w-2xl mx-auto">
            Choose your CPU, RAM, and OS. Your VPS will be ready in minutes with full root access.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button asChild size="lg" variant="premium">
              <Link href="/contact">Order VPS</Link>
            </Button>
            <Button asChild size="lg" variant="secondary">
              <Link href={DISCORD_INVITE} target="_blank" rel="noopener noreferrer">
                Ask on Discord
              </Link>
            </Button>
          </div>
        </div>
      </section>
    </>
  );
}