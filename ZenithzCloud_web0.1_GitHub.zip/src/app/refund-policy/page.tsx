import { Metadata } from 'next';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { DISCORD_INVITE, WEBSITE_URL } from '@/data/plans';
import { generateMetadata } from '@/lib/seo';

export const metadata: Metadata = generateMetadata({
  title: 'Refund Policy',
  description: 'ZENITHZcloud Refund Policy - Our money-back guarantee and refund terms for hosting services.',
  path: '/refund-policy',
});

const lastUpdated = 'October 26, 2026';
const effectiveDate = 'October 26, 2026';

export default function RefundPolicyPage() {
  return (
    <>
      <section className="relative min-h-[40vh] flex items-center overflow-hidden">
        <div className="absolute inset-0 bg-radial-bottom" />
        <div className="absolute inset-0 bg-grid" />

        <div className="relative z-10 container py-16 lg:py-24">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="max-w-3xl"
          >
            <Badge variant="premium" className="mb-4">Legal</Badge>
            <h1 className="text-display-lg text-white mb-4">Refund Policy</h1>
            <p className="text-body-lg text-gray-400 mb-4">
              Last updated: {lastUpdated} | Effective: {effectiveDate}
            </p>
            <p className="text-body text-gray-500">
              Our money-back guarantee and refund terms for all hosting services.
            </p>
          </motion.div>
        </div>
      </section>

      <section className="section">
        <div className="container max-w-4xl">
          <div className="space-y-12">
            <LegalSection number="1" title="Money-Back Guarantee">
              <p className="text-gray-300 mb-4">
                We offer a <strong>48-hour money-back guarantee</strong> for new customers on eligible services.
                If you're not satisfied, request a full refund within 48 hours of your first order.
              </p>
              <div className="bg-green-600/10 border border-green-600/30 rounded-xl p-6 mb-6">
                <h3 className="text-white font-semibold mb-3">Eligible Services</h3>
                <ul className="list-disc list-inside space-y-2 text-gray-300">
                  <li>VPS Hosting (all plans)</li>
                  <li>Bot Hosting (all plans)</li>
                </ul>
              </div>
            </LegalSection>

            <LegalSection number="2" title="Non-Refundable Services">
              <p className="text-gray-300 mb-4">
                The following services are <strong>not eligible</strong> for the money-back guarantee:
              </p>
              <ul className="list-disc list-inside space-y-2 text-gray-300 mb-4">
                <li>Minecraft Server Hosting (all CPU tiers)</li>
                <li>Dedicated Servers (all configurations)</li>
                <li>Custom hardware orders</li>
                <li>Add-on services (extra IPs, additional storage, managed services)</li>
                <li>Domain registrations and SSL certificates</li>
                <li>Renewal payments</li>
              </ul>
              <p className="text-gray-300">
                For non-refundable services, we encourage you to contact sales with questions before ordering.
                Our team can provide detailed specifications and help you choose the right plan.
              </p>
            </LegalSection>

            <LegalSection number="3" title="Refund Conditions">
              <p className="text-gray-300 mb-4">
                To qualify for a refund under the money-back guarantee:
              </p>
              <ul className="list-disc list-inside space-y-2 text-gray-300 mb-4">
                <li>You must be a new customer (first order only)</li>
                <li>Request must be submitted within 48 hours of order confirmation</li>
                <li>Service must not have violated our Acceptable Use Policy</li>
                <li>Resource usage must be within normal limits (no excessive load testing)</li>
                <li>No more than one refund per customer/household</li>
              </ul>
            </LegalSection>

            <LegalSection number="4" title="Refund Process">
              <p className="text-gray-300 mb-4">
                To request a refund:
              </p>
              <ol className="list-decimal list-inside space-y-3 text-gray-300 mb-4">
                <li>Open a billing ticket via our Discord or email billing@zenithzcloud.com</li>
                <li>Include your order ID and reason for refund</li>
                <li>Our billing team will review within 2 business days</li>
                <li>Approved refunds are processed to the original payment method</li>
                <li>Refund timing depends on payment provider (typically 5-10 business days)</li>
              </ol>
            </LegalSection>

            <LegalSection number="5" title="Partial Refunds & Prorated Credits">
              <p className="text-gray-300 mb-4">
                For service issues not covered by the money-back guarantee:
              </p>
              <ul className="list-disc list-inside space-y-2 text-gray-300 mb-4">
                <li><strong>SLA Credits:</strong> Verified downtime exceeding 99.97% uptime guarantee may qualify for prorated service credits per our SLA.</li>
                <li><strong>Service Disruptions:</strong> Extended outages caused by our infrastructure may receive account credits at our discretion.</li>
                <li><strong>Billing Errors:</strong> Duplicate charges or incorrect billing will be fully refunded.</li>
              </ul>
            </LegalSection>

            <LegalSection number="6" title="Refund Exclusions">
              <p className="text-gray-300 mb-4">
                Refunds will not be issued for:
              </p>
              <ul className="list-disc list-inside space-y-2 text-gray-300 mb-4">
                <li>Customer misconfiguration or user error</li>
                <li>Failure to read service specifications before ordering</li>
                <li>Change of mind after 48 hours (for eligible services)</li>
                <li>Account suspension/termination for AUP violations</li>
                <li>Force majeure events</li>
                <li>Scheduled maintenance windows</li>
                <li>Third-party service issues (payment processors, DNS, etc.)</li>
              </ul>
            </LegalSection>

            <LegalSection number="7" title="Dedicated Server & Custom Orders">
              <p className="text-gray-300 mb-4">
                Dedicated servers and custom hardware orders require a <strong>non-refundable deposit</strong> (typically 50%)
                to begin procurement. The deposit is applied to the first invoice. Cancellation before delivery
                forfeits the deposit. After delivery, standard Terms of Service termination applies.
              </p>
            </LegalSection>

            <LegalSection number="8" title="Chargebacks">
              <p className="text-gray-300 mb-4">
                Filing a chargeback without contacting us first may result in:
              </p>
              <ul className="list-disc list-inside space-y-2 text-gray-300 mb-4">
                <li>Immediate service suspension</li>
                <li>Account termination</li>
                <li>Loss of any promotional pricing or credits</li>
                <li>Collection proceedings for disputed amounts</li>
              </ul>
              <p className="text-gray-300">
                Please contact billing support before initiating any payment dispute.
              </p>
            </LegalSection>

            <LegalSection number="9" title="Currency & International Refunds">
              <p className="text-gray-300 mb-4">
                All refunds are processed in Indian Rupees (INR) at the original exchange rate.
                International customers may receive slightly different amounts due to currency fluctuations
                and payment processor fees, which are not refundable.
              </p>
            </LegalSection>

            <LegalSection number="10" title="Contact for Refunds">
              <p className="text-gray-300 mb-4">
                To request a refund or ask about this policy:
              </p>
              <ul className="space-y-2 text-gray-300">
                <li>Email: billing@zenithzcloud.com</li>
                <li>Discord: <a href={DISCORD_INVITE} target="_blank" rel="noopener noreferrer" className="text-red-500 hover:underline">discord.gg/9gGknK6VWw</a> (Billing Support channel)</li>
                <li>Website: <a href={WEBSITE_URL} target="_blank" rel="noopener noreferrer" className="text-red-500 hover:underline">zenithzcloud.com</a></li>
              </ul>
            </LegalSection>
          </div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="mt-16 p-6 bg-gray-900/50 border border-gray-800 rounded-xl"
          >
            <Badge variant="warning" className="mb-4">Draft Document</Badge>
            <h3 className="text-heading-md text-white mb-3">Important Notice</h3>
            <p className="text-gray-400">
              This refund policy is a draft based on standard hosting provider practices and the master prompt specifications.
              It has not been reviewed by legal counsel. The website owner must review, customize, and approve this document
              before it can be considered legally binding. Do not publish this version without legal review.
            </p>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="mt-8 text-center"
          >
            <Button asChild variant="secondary" size="lg">
              <a href={DISCORD_INVITE} target="_blank" rel="noopener noreferrer">
                Contact Billing Support on Discord
              </a>
            </Button>
          </motion.div>
        </div>
      </section>
    </>
  );
}

function LegalSection({ number, title, children }: { number: string; title: string; children: React.ReactNode }) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
    >
      <div className="flex items-start gap-4">
        <div className="flex-shrink-0 w-10 h-10 rounded-full bg-red-600/20 flex items-center justify-center text-red-500 font-bold text-lg">
          {number}
        </div>
        <div className="flex-1">
          <h2 className="text-heading-md text-white mb-4">{title}</h2>
          <div className="pl-10 border-l border-gray-800">
            {children}
          </div>
        </div>
      </div>
    </motion.div>
  );
}