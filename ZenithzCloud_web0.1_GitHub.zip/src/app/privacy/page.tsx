import { Metadata } from 'next';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { DISCORD_INVITE, WEBSITE_URL } from '@/data/plans';
import { generateMetadata } from '@/lib/seo';

export const metadata: Metadata = generateMetadata({
  title: 'Privacy Policy',
  description: 'ZENITHZcloud Privacy Policy - How we collect, use, and protect your personal information.',
  path: '/privacy',
});

const lastUpdated = 'October 26, 2026';
const effectiveDate = 'October 26, 2026';

export default function PrivacyPage() {
  return (
    <>
      <section className="relative min-h-[40vh] flex items-center overflow-hidden">
        <div className="absolute inset-0 bg-radial-bottom" />
        <div className="absolute inset-0 bg-grid" />

        <div className="relative z-10 container py-16 lg:py-24">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="max-w-3xl"
          >
            <Badge variant="premium" className="mb-4">Legal</Badge>
            <h1 className="text-display-lg text-white mb-4">Privacy Policy</h1>
            <p className="text-body-lg text-gray-400 mb-4">
              Last updated: {lastUpdated} | Effective: {effectiveDate}
            </p>
            <p className="text-body text-gray-500">
              This policy describes how ZENITHZcloud collects, uses, and protects your information.
            </p>
          </motion.div>
        </div>
      </section>

      <section className="section">
        <div className="container max-w-4xl">
          <div className="space-y-12">
            <LegalSection number="1" title="Information We Collect">
              <p className="text-gray-300 mb-4">
                We collect information you provide directly to us, including:
              </p>
              <ul className="list-disc list-inside space-y-2 text-gray-300 mb-4">
                <li>Account information (name, email, password)</li>
                <li>Billing information (payment details, billing address)</li>
                <li>Support communications (tickets, Discord messages, emails)</li>
                <li>Usage data (server metrics, resource consumption, API calls)</li>
                <li>Technical data (IP addresses, browser type, access logs)</li>
              </ul>
            </LegalSection>

            <LegalSection number="2" title="How We Use Your Information">
              <p className="text-gray-300 mb-4">
                We use collected information to:
              </p>
              <ul className="list-disc list-inside space-y-2 text-gray-300 mb-4">
                <li>Provide, maintain, and improve our hosting services</li>
                <li>Process payments and manage billing</li>
                <li>Send service notifications, updates, and security alerts</li>
                <li>Provide customer support and respond to inquiries</li>
                <li>Detect and prevent fraud, abuse, and security threats</li>
                <li>Comply with legal obligations</li>
              </ul>
            </LegalSection>

            <LegalSection number="3" title="Data Sharing & Disclosure">
              <p className="text-gray-300 mb-4">
                We do not sell your personal information. We may share data with:
              </p>
              <ul className="list-disc list-inside space-y-2 text-gray-300 mb-4">
                <li>Payment processors (Stripe, Razorpay, etc.) for transaction processing</li>
                <li>Cloudflare for DDoS protection and CDN services</li>
                <li>Data center providers for infrastructure hosting</li>
                <li>Legal authorities when required by law or to protect our rights</li>
                <li>Service providers who assist in operating our business (under strict confidentiality)</li>
              </ul>
            </LegalSection>

            <LegalSection number="4" title="Data Retention">
              <p className="text-gray-300 mb-4">
                We retain your personal information for as long as your account is active or as needed to provide services.
                After account closure, we retain data for legal compliance (typically 7 years for billing records)
                and then securely delete or anonymize it.
              </p>
            </LegalSection>

            <LegalSection number="5" title="Security Measures">
              <p className="text-gray-300 mb-4">
                We implement appropriate technical and organizational measures to protect your data:
              </p>
              <ul className="list-disc list-inside space-y-2 text-gray-300 mb-4">
                <li>Encryption in transit (TLS 1.3) and at rest (AES-256)</li>
                <li>Access controls and principle of least privilege</li>
                <li>Regular security assessments and penetration testing</li>
                <li>DDoS protection via Cloudflare Magic Transit</li>
                <li>Automated backup encryption and secure storage</li>
              </ul>
            </LegalSection>

            <LegalSection number="6" title="Your Rights">
              <p className="text-gray-300 mb-4">
                Depending on your jurisdiction, you may have rights to:
              </p>
              <ul className="list-disc list-inside space-y-2 text-gray-300 mb-4">
                <li>Access your personal data</li>
                <li>Request correction of inaccurate data</li>
                <li>Request deletion of your data (subject to legal obligations)</li>
                <li>Object to or restrict processing</li>
                <li>Data portability</li>
                <li>Withdraw consent where processing is based on consent</li>
              </ul>
              <p className="text-gray-300">
                To exercise these rights, contact us at privacy@zenithzcloud.com or via Discord.
              </p>
            </LegalSection>

            <LegalSection number="7" title="Cookies & Tracking">
              <p className="text-gray-300 mb-4">
                We use essential cookies for session management and security. We do not use third-party
                advertising or tracking cookies. Analytics are self-hosted and anonymized.
              </p>
            </LegalSection>

            <LegalSection number="8" title="International Transfers">
              <p className="text-gray-300 mb-4">
                Your data may be processed in India, Germany, and Singapore where our servers are located.
                We ensure appropriate safeguards for cross-border transfers.
              </p>
            </LegalSection>

            <LegalSection number="9" title="Changes to This Policy">
              <p className="text-gray-300 mb-4">
                We may update this policy periodically. Material changes will be communicated via email
                and/or Discord announcement at least 30 days before taking effect.
              </p>
            </LegalSection>

            <LegalSection number="10" title="Contact Us">
              <p className="text-gray-300 mb-4">
                For privacy questions or to exercise your rights:
              </p>
              <ul className="space-y-2 text-gray-300">
                <li>Email: privacy@zenithzcloud.com</li>
                <li>Discord: <a href={DISCORD_INVITE} target="_blank" rel="noopener noreferrer" className="text-red-500 hover:underline">discord.gg/9gGknK6VWw</a></li>
                <li>Website: <a href={WEBSITE_URL} target="_blank" rel="noopener noreferrer" className="text-red-500 hover:underline">zenithzcloud.com</a></li>
              </ul>
            </LegalSection>
          </div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="mt-16 p-6 bg-gray-900/50 border border-gray-800 rounded-xl"
          >
            <Badge variant="warning" className="mb-4">Draft Document</Badge>
            <h3 className="text-heading-md text-white mb-3">Important Notice</h3>
            <p className="text-gray-400">
              This privacy policy is a draft based on standard hosting provider practices and the master prompt specifications.
              It has not been reviewed by legal counsel. The website owner must review, customize, and approve this document
              before it can be considered legally binding. Do not publish this version without legal review.
            </p>
          </motion.div>
        </div>
      </section>
    </>
  );
}

function LegalSection({ number, title, children }: { number: string; title: string; children: React.ReactNode }) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
    >
      <div className="flex items-start gap-4">
        <div className="flex-shrink-0 w-10 h-10 rounded-full bg-red-600/20 flex items-center justify-center text-red-500 font-bold text-lg">
          {number}
        </div>
        <div className="flex-1">
          <h2 className="text-heading-md text-white mb-4">{title}</h2>
          <div className="pl-10 border-l border-gray-800">
            {children}
          </div>
        </div>
      </div>
    </motion.div>
  );
}