import { Metadata } from 'next';
import * as React from 'react';
import { motion } from 'framer-motion';
import { ChevronDown, ChevronUp, HelpCircle, ArrowRight } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { DISCORD_INVITE } from '@/data/plans';
import { generateMetadata } from '@/lib/seo';

export const metadata: Metadata = generateMetadata({
  title: 'FAQ',
  description: 'Frequently asked questions about ZENITHZcloud hosting services, billing, support, and technical specifications.',
  path: '/faq',
});

const faqs = [
  {
    category: 'General',
    questions: [
      {
        q: 'What is ZENITHZcloud?',
        a: 'ZENITHZcloud is a premium infrastructure hosting provider offering Minecraft server hosting, VPS hosting, dedicated servers, and Discord bot hosting. We use enterprise-grade AMD EPYC and Ryzen hardware with Cloudflare Magic Transit DDoS protection.',
      },
      {
        q: 'Where are your servers located?',
        a: 'We currently offer servers in Mumbai, India (owned hardware); Frankfurt, Germany (rented); and Singapore (rented). Eight additional locations are on our roadmap including Tokyo, Dubai, London, Istanbul, Amsterdam, Paris, New York, Sydney, and São Paulo.',
      },
      {
        q: 'What payment methods do you accept?',
        a: 'We accept UPI, credit/debit cards, net banking, and crypto payments. All prices are in Indian Rupees (INR). For international payments, please contact our sales team.',
      },
      {
        q: 'Is there a setup fee?',
        a: 'No, there are no setup fees for any of our services. Provisioning is instant and automated.',
      },
    ],
  },
  {
    category: 'Minecraft Hosting',
    questions: [
      {
        q: 'Which Minecraft versions and server types do you support?',
        a: 'We support all major Minecraft versions (1.12.2 through 1.21+) and server types including Vanilla, Paper, Spigot, Purpur, Forge, Fabric, NeoForge, and Mohist. One-click modpack installation is available for popular packs.',
      },
      {
        q: 'Can I upgrade/downgrade my Minecraft plan?',
        a: 'Yes, you can upgrade or downgrade your plan at any time. RAM changes take effect after a restart. CPU tier changes may require a migration.',
      },
      {
        q: 'Do you offer a custom control panel?',
        a: 'Yes, we provide a custom-built Minecraft control panel with one-click modpack/plugin installation, console access, file manager, scheduled tasks, and real-time resource monitoring.',
      },
      {
        q: 'What DDoS protection do you offer for Minecraft?',
        a: 'Game-specific DDoS protection with custom BPF rules and inline eBPF/XDP filtering at 150 Gbps. Protection is included with all Minecraft plans.',
      },
      {
        q: 'Are backups included?',
        a: 'Yes, automated daily backups with 7-day retention are included. You can also create manual snapshots before major changes.',
      },
    ],
  },
  {
    category: 'VPS Hosting',
    questions: [
      {
        q: 'What operating systems are available?',
        a: 'Ubuntu, Windows Server, Fedora, Debian, Kali Linux, and Custom ISO. You can upload your own ISO for custom installations.',
      },
      {
        q: 'Do I get root access?',
        a: 'Yes, full root/SSH access is provided on all VPS plans. You also get a browser-based console (VNC/Serial) for emergency recovery.',
      },
      {
        q: 'Can I take snapshots and backups?',
        a: 'Yes, instant snapshots are available on-demand. Automated daily backups with 7-day retention are included.',
      },
      {
        q: 'What is the difference between Ryzen 9000 and EPYC 7F72 VPS?',
        a: 'Ryzen 9000 Series uses latest Zen 5 architecture optimized for single-thread performance (available in India only). EPYC 7F72 offers higher core counts for multi-threaded workloads (available in India, Germany, Singapore).',
      },
    ],
  },
  {
    category: 'Dedicated Servers',
    questions: [
      {
        q: 'What hardware do dedicated servers use?',
        a: 'AMD Ryzen 9 and AMD EPYC 7F72 processors. Specific CPU model varies by plan. Custom hardware configurations available on request.',
      },
      {
        q: 'Do I get IPMI/KVM access?',
        a: 'Yes, all dedicated servers include IPMI/KVM over LAN for out-of-band management, allowing OS reinstall and BIOS access remotely.',
      },
      {
        q: 'Are backups included for dedicated servers?',
        a: 'Yes, free automated daily backups with 7-day retention are included with all dedicated server plans.',
      },
      {
        q: 'Can I order custom hardware configurations?',
        a: 'Yes, we offer custom CPU, RAM, storage, and networking configurations. Contact our sales team for a quote.',
      },
    ],
  },
  {
    category: 'Bot Hosting',
    questions: [
      {
        q: 'Which programming languages are supported?',
        a: 'Node.js, Python, Java, Go, and PHP are natively supported. Custom runtimes can be configured on request.',
      },
      {
        q: 'How do I deploy my bot?',
        a: 'Connect your Git repository (GitHub, GitLab, Bitbucket) for automatic deployments. Dependencies are installed automatically (npm, pip, maven, go mod, composer).',
      },
      {
        q: 'Can I use databases with my bot?',
        a: 'Yes, managed Redis, MongoDB, PostgreSQL, and SQLite are available as add-ons.',
      },
      {
        q: 'Is there a process manager?',
        a: 'Yes, built-in process management with auto-restart, log rotation, health checks, and zero-downtime scaling.',
      },
    ],
  },
  {
    category: 'Billing & Support',
    questions: [
      {
        q: 'What is your refund policy?',
        a: 'We offer a 48-hour money-back guarantee for new customers on VPS and bot hosting plans. Dedicated servers and Minecraft plans have specific terms. See our Refund Policy page for details.',
      },
      {
        q: 'How do I contact support?',
        a: '24/7 support via Discord (primary), ticket system, and email. Join our Discord at discord.gg/9gGknK6VWw for fastest response.',
      },
      {
        q: 'Do you offer SLA credits?',
        a: 'We target 99.97% uptime. SLA credits are available per our Terms of Service for verified downtime exceeding the guarantee.',
      },
      {
        q: 'Can I pay monthly or annually?',
        a: 'Monthly billing is standard. Annual billing with discount is available on request. Contact sales for annual pricing.',
      },
    ],
  },
];

export default function FAQPage() {
  return (
    <>
      <section className="relative min-h-[50vh] flex items-center overflow-hidden">
        <div className="absolute inset-0 bg-radial-bottom" />
        <div className="absolute inset-0 bg-grid" />

        <div className="relative z-10 container py-16 lg:py-24">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="max-w-3xl"
          >
            <Badge variant="premium" className="mb-4">Help Center</Badge>
            <h1 className="text-display-lg text-white mb-4">Frequently Asked Questions</h1>
            <p className="text-body-lg text-gray-400 mb-8">
              Find answers to common questions about our services, billing, and technical specifications.
            </p>
            <div className="flex flex-col sm:flex-row gap-4">
              <Button asChild size="lg" variant="premium">
                <a href="/contact">Contact Support</a>
              </Button>
              <Button asChild size="lg" variant="secondary">
                <a href={DISCORD_INVITE} target="_blank" rel="noopener noreferrer">
                  Ask on Discord
                </a>
              </Button>
            </div>
          </motion.div>
        </div>
      </section>

      <section className="section">
        <div className="container">
          <div className="grid lg:grid-cols-[280px_1fr] gap-12">
            <motion.aside
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              className="lg:sticky lg:top-24"
            >
              <nav className="space-y-1" aria-label="FAQ Categories">
                {faqs.map((category, i) => (
                  <div key={category.category} className="mb-4">
                    <h3 className="text-xs font-semibold text-gray-500 uppercase tracking-wider mb-2 px-3">
                      {category.category}
                    </h3>
                    <ul className="space-y-1">
                      {category.questions.map((_, qIndex) => (
                        <li key={qIndex}>
                          <a
                            href={`#faq-${i}-${qIndex}`}
                            className="block px-3 py-2 text-sm text-gray-400 hover:text-white hover:bg-gray-800 rounded-lg transition-colors"
                          >
                            {category.questions[qIndex].q}
                          </a>
                        </li>
                      ))}
                    </ul>
                  </div>
                ))}
              </nav>
            </motion.aside>

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: 0.1 }}
            >
              {faqs.map((category, catIndex) => (
                <div key={category.category} className="mb-12">
                  <div className="flex items-center gap-4 mb-8">
                    <div className="h-1 w-full bg-gray-800" />
                    <h2 className="text-heading-lg text-white">{category.category}</h2>
                    <div className="h-1 w-full bg-gray-800" />
                  </div>

                  <div className="space-y-4">
                    {category.questions.map((faq, qIndex) => (
                      <FAQItem
                        key={`${catIndex}-${qIndex}`}
                        question={faq.q}
                        answer={faq.a}
                        id={`faq-${catIndex}-${qIndex}`}
                        index={catIndex * 10 + qIndex}
                      />
                    ))}
                  </div>
                </div>
              ))}
            </motion.div>
          </div>
        </div>
      </section>

      <section className="section bg-gradient-to-b from-gray-950 to-black border-y border-gray-800">
        <div className="container text-center">
          <h2 className="text-display-sm text-white mb-4">Still Have Questions?</h2>
          <p className="text-body-lg text-gray-400 mb-8 max-w-2xl mx-auto">
            Can't find what you're looking for? Our support team is available 24/7 to help.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button asChild size="lg" variant="premium">
              <a href="/contact">Submit a Ticket</a>
            </Button>
            <Button asChild size="lg" variant="secondary">
              <a href={DISCORD_INVITE} target="_blank" rel="noopener noreferrer">
                Discord Support
              </a>
            </Button>
          </div>
        </div>
      </section>
    </>
  );
}

function FAQItem({ question, answer, id, index }: { question: string; answer: string; id: string; index: number }) {
  const [open, setOpen] = React.useState(false);

  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: index * 0.03 }}
    >
      <Card variant="elevated" padding="none" className="overflow-hidden">
        <button
          onClick={() => setOpen(!open)}
          className="w-full px-6 py-4 flex items-center justify-between text-left focus:outline-none focus:ring-2 focus:ring-red-500 focus:ring-inset"
          aria-expanded={open}
          aria-controls={`${id}-content`}
        >
          <span className="text-white font-medium pr-8">{question}</span>
          {open ? (
            <ChevronUp className="h-5 w-5 text-gray-400 transition-transform" />
          ) : (
            <ChevronDown className="h-5 w-5 text-gray-400 transition-transform" />
          )}
        </button>
        <motion.div
          id={`${id}-content`}
          initial={false}
          animate={{ height: open ? 'auto' : 0, opacity: open ? 1 : 0 }}
          transition={{ duration: 0.2, ease: 'easeInOut' }}
          className="overflow-hidden"
        >
          <CardContent className="px-6 pb-6">
            <div className="text-gray-300 prose prose-sm max-w-none dark">
              <p>{answer}</p>
            </div>
          </CardContent>
        </motion.div>
      </Card>
    </motion.div>
  );
}