'use client';

import * as React from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import Link from 'next/link';
import { ArrowRight, Check, Server, Shield, Zap, Globe, Clock, Cpu, HardDrive, Loader2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { PlanCard, PlanComparisonTable } from '@/components/pricing/pricing-components';
import { formatINR, DEDICATED_PLANS, type DedicatedPlan, type AnyPlan, DISCORD_INVITE } from '@/data/plans';

export default function DedicatedPage() {
  const [viewMode, setViewMode] = React.useState<'cards' | 'table'>('cards');
  const [orderingPlan, setOrderingPlan] = React.useState<string | null>(null);

  const handleOrder = (plan: AnyPlan) => {
    setOrderingPlan(plan.id);
    window.open(DISCORD_INVITE, '_blank', 'noopener,noreferrer');
    setTimeout(() => setOrderingPlan(null), 2000);
  };

  return (
    <>
      <section className="relative min-h-[50vh] flex items-center overflow-hidden">
        <div className="absolute inset-0 bg-radial-bottom" />
        <div className="absolute inset-0 bg-grid" />

        <div className="relative z-10 container py-16 lg:py-24">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="max-w-3xl"
          >
            <Badge variant="premium" className="mb-4">Dedicated Servers</Badge>
            <h1 className="text-display-lg text-white mb-4">Dedicated Servers</h1>
            <p className="text-body-lg text-gray-400 mb-6">
              Bare-metal performance with AMD Ryzen 9 and EPYC 7F72 processors.
              Full hardware isolation, no virtualization overhead.
            </p>
            <div className="flex flex-wrap gap-4 text-sm text-gray-400">
              <div className="flex items-center gap-2">
                <Check className="h-4 w-4 text-green-500" />
                <span>Bare Metal</span>
              </div>
              <div className="flex items-center gap-2">
                <Check className="h-4 w-4 text-green-500" />
                <span>No Virtualization</span>
              </div>
              <div className="flex items-center gap-2">
                <Check className="h-4 w-4 text-green-500" />
                <span>Root Access</span>
              </div>
              <div className="flex items-center gap-2">
                <Check className="h-4 w-4 text-green-500" />
                <span>Free Backups</span>
              </div>
              <div className="flex items-center gap-2">
                <Check className="h-4 w-4 text-green-500" />
                <span>Priority Support</span>
              </div>
              <div className="flex items-center gap-2">
                <Check className="h-4 w-4 text-green-500" />
                <span>Custom Hardware</span>
              </div>
            </div>
          </motion.div>
        </div>
      </section>

      <section className="section">
        <div className="container">
          <div className="mb-8 flex items-center justify-between">
            <h2 className="text-heading-lg text-white">All Dedicated Server Plans</h2>
            <div className="flex gap-2">
              <Button
                variant={viewMode === 'cards' ? 'default' : 'outline'}
                size="sm"
                onClick={() => setViewMode('cards')}
              >
                Cards
              </Button>
              <Button
                variant={viewMode === 'table' ? 'default' : 'outline'}
                size="sm"
                onClick={() => setViewMode('table')}
              >
                Table
              </Button>
            </div>
          </div>

          <AnimatePresence mode="wait">
            {viewMode === 'cards' ? (
              <motion.div
                key="cards"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -20 }}
                className="grid sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6"
              >
                {DEDICATED_PLANS.map((plan, i) => (
                  <motion.div
                    key={plan.id}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: i * 0.05 }}
                  >
                    <PlanCard plan={plan} highlighted={plan.badge === 'popular'} onOrder={handleOrder} />
                  </motion.div>
                ))}
              </motion.div>
            ) : (
              <motion.div
                key="table"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -20 }}
              >
                <PlanComparisonTable plans={DEDICATED_PLANS} category="dedicated" onOrder={handleOrder} />
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </section>

      <section className="section bg-gradient-to-b from-gray-950 to-black border-y border-gray-800">
        <div className="container">
          <h2 className="text-display-sm text-white text-center mb-12">Dedicated Server Features</h2>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6 mb-12">
            {[
              { icon: Server, title: 'True Bare Metal', desc: 'No hypervisor, no shared resources. 100% of CPU, RAM, and I/O dedicated to your workload.' },
              { icon: Cpu, title: 'AMD Ryzen 9 & EPYC 7F72', desc: 'High-frequency Ryzen for single-threaded apps, EPYC for multi-threaded enterprise workloads.' },
              { icon: HardDrive, title: 'Gen 5 SSD Storage', desc: 'Enterprise-grade SSDs with high endurance for database and storage-intensive applications.' },
              { icon: Shield, title: 'DDoS Protection Included', desc: 'Cloudflare Magic Transit with 150 Gbps filtering. Custom rules available on request.' },
              { icon: Globe, title: 'India Location (Owned)', desc: 'Our own hardware in Mumbai data center. Sub-29ms latency for Indian subcontinent.' },
              { icon: Zap, title: 'Custom Configurations', desc: 'Need specific hardware? Contact us for custom CPU, RAM, storage, and networking setups.' },
            ].map((feature, i) => (
              <motion.div
                key={feature.title}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.08 }}
              >
                <Card variant="elevated" padding="lg" className="h-full">
                  <CardContent className="flex flex-col h-full">
                    <div className="h-12 w-12 rounded-xl bg-red-600/20 flex items-center justify-center mb-4">
                      <feature.icon className="h-6 w-6 text-red-500" />
                    </div>
                    <h3 className="text-heading-sm text-white mb-2">{feature.title}</h3>
                    <p className="text-body-sm text-gray-400 flex-1">{feature.desc}</p>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>

          <div className="grid md:grid-cols-3 gap-6">
            {[
              { icon: Shield, title: 'Free Backups', desc: 'Automated daily backups with 7-day retention included at no extra cost.' },
              { icon: Clock, title: 'Priority Support', desc: 'Dedicated support channel with faster response times for dedicated customers.' },
              { icon: Cpu, title: 'Hardware RAID', desc: 'RAID-1/5/10 options available. Hot-swap drive bays for zero-downtime maintenance.' },
            ].map((feature, i) => (
              <motion.div
                key={feature.title}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.08 }}
              >
                <Card variant="elevated" padding="lg" className="h-full">
                  <CardContent className="flex flex-col h-full">
                    <div className="h-12 w-12 rounded-xl bg-red-600/20 flex items-center justify-center mb-4">
                      <feature.icon className="h-6 w-6 text-red-500" />
                    </div>
                    <h3 className="text-heading-sm text-white mb-2">{feature.title}</h3>
                    <p className="text-body-sm text-gray-400 flex-1">{feature.desc}</p>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      <section className="section">
        <div className="container">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
            >
              <h2 className="text-display-sm text-white mb-4">Enterprise-Grade Infrastructure</h2>
              <p className="text-body-lg text-gray-400 mb-6">
                Our dedicated servers run on enterprise hardware in our Mumbai data center.
                Full IPMI/KVM access, redundant power, and 24/7 remote hands.
              </p>
              <ul className="space-y-3 mb-8">
                {[
                  'IPMI/KVM over LAN for out-of-band management',
                  'Redundant power supplies (N+1)',
                  '10 Gbps network uplink available',
                  'Private VLAN and cross-connect options',
                  'Hardware RAID controller with BBU',
                  'Hot-swap drive bays (2.5" / 3.5")',
                  'Custom BIOS/UEFI configuration on request',
                  'Dedicated 1 Gbps unmetered port included',
                ].map((item, i) => (
                  <li key={i} className="flex items-center gap-3 text-gray-300">
                    <Check className="h-5 w-5 text-green-500 flex-shrink-0" />
                    <span>{item}</span>
                  </li>
                ))}
              </ul>
              <Button asChild size="lg" variant="premium">
                <Link href="/contact">Request Custom Quote</Link>
              </Button>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: 0.1 }}
            >
              <div className="aspect-video rounded-2xl border border-gray-800 overflow-hidden bg-black/50 relative">
                <div className="absolute inset-0 bg-gradient-to-br from-red-600/10 via-transparent to-transparent" />
                <div className="relative h-full flex items-center justify-center p-8">
                  <div className="text-center max-w-md">
                    <div className="text-5xl font-bold text-red-500 gradient-text-red mb-2">₹3,200</div>
                    <div className="text-gray-400 mb-6">Starting per month</div>
                    <div className="grid grid-cols-3 gap-4 text-center">
                      <div className="p-4 bg-gray-900/50 rounded-xl border border-gray-800">
                        <div className="text-2xl font-bold text-white">11</div>
                        <div className="text-xs text-gray-400">Configurations</div>
                      </div>
                      <div className="p-4 bg-gray-900/50 rounded-xl border border-gray-800">
                        <div className="text-2xl font-bold text-white">256 GB</div>
                        <div className="text-xs text-gray-400">Max RAM</div>
                      </div>
                      <div className="p-4 bg-gray-900/50 rounded-xl border border-gray-800">
                        <div className="text-2xl font-bold text-white">8 TB</div>
                        <div className="text-xs text-gray-400">Max Storage</div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      <section className="section bg-gradient-to-b from-gray-950 to-black border-y border-gray-800">
        <div className="container text-center">
          <h2 className="text-display-sm text-white mb-4">Need Custom Hardware?</h2>
          <p className="text-body-lg text-gray-400 mb-8 max-w-2xl mx-auto">
            Our team can configure custom dedicated servers with specific CPU models, RAID configurations,
            private networking, and specialized storage requirements.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button asChild size="lg" variant="premium">
              <Link href="/contact">Contact Sales</Link>
            </Button>
            <Button asChild size="lg" variant="secondary">
              <Link href={DISCORD_INVITE} target="_blank" rel="noopener noreferrer">
                Discord Support
              </Link>
            </Button>
          </div>
        </div>
      </section>
    </>
  );
}