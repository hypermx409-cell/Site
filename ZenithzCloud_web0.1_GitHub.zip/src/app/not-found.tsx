import { Metadata } from 'next';
import Link from 'next/link';
import { Home, Search, RotateCcw } from 'lucide-react';
import { generateMetadata } from '@/lib/seo';

export const metadata: Metadata = generateMetadata({
  title: 'Page Not Found',
  description: 'The page you\'re looking for doesn\'t exist or has been moved.',
  path: '/404',
  noIndex: true,
});

export const dynamic = 'force-dynamic';

export default function NotFoundPage() {
  return (
    <div className="min-h-[70vh] flex items-center justify-center px-4">
      <div className="text-center max-w-md animate-fade-in">
        <div className="mb-8">
          <div className="inline-block text-9xl font-bold text-red-500/30 animate-pulse-slow">
            404
          </div>
        </div>

        <h1 className="text-display-md text-white mb-4">Page Not Found</h1>
        <p className="text-body-lg text-gray-400 mb-8">
          The page you're looking for doesn't exist or has been moved.
          Let's get you back on track.
        </p>

        <div className="flex flex-col sm:flex-row gap-4 justify-center">
          <Link
            href="/"
            className="inline-flex items-center justify-center whitespace-nowrap rounded-md text-sm font-medium ring-offset-black transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-red-500 focus-visible:ring-offset-2 bg-gradient-to-r from-red-600 to-red-700 text-white hover:from-red-700 hover:to-red-800 shadow-lg shadow-red-600/25 h-11 rounded-lg px-8 text-base"
          >
            <Home className="h-5 w-5 mr-2" />
            Go Home
          </Link>
          <Link
            href="/contact"
            className="inline-flex items-center justify-center whitespace-nowrap rounded-md text-sm font-medium ring-offset-black transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-red-500 focus-visible:ring-offset-2 border border-gray-700 bg-gray-900 text-gray-100 hover:bg-gray-800 hover:border-gray-600 h-11 rounded-lg px-8 text-base"
          >
            Contact Support
          </Link>
        </div>

        <div className="mt-12 grid grid-cols-3 gap-4 text-center">
          <Link href="/games/minecraft" className="p-4 card-base card-hover rounded-xl group">
            <Search className="h-6 w-6 text-gray-400 mx-auto mb-2 group-hover:text-red-500 transition-colors" />
            <p className="text-sm text-gray-300">Game Hosting</p>
          </Link>
          <Link href="/vps" className="p-4 card-base card-hover rounded-xl group">
            <RotateCcw className="h-6 w-6 text-gray-400 mx-auto mb-2 group-hover:text-red-500 transition-colors" />
            <p className="text-sm text-gray-300">VPS Hosting</p>
          </Link>
          <Link href="/dedicated" className="p-4 card-base card-hover rounded-xl group">
            <Home className="h-6 w-6 text-gray-400 mx-auto mb-2 group-hover:text-red-500 transition-colors" />
            <p className="text-sm text-gray-300">Dedicated</p>
          </Link>
        </div>
      </div>
    </div>
  );
}