'use client';

import Link from 'next/link';
import { motion } from 'framer-motion';
import { ArrowRight, Check, Server, Shield, Zap, Globe, Clock, Cpu } from 'lucide-react';
import { LinkButton } from '@/components/ui/link-button';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { ServerRackCanvas } from '@/components/three/server-rack';
import { formatINR, DISCORD_INVITE } from '@/data/plans';

const features = [
  {
    icon: Cpu,
    title: 'Enterprise Hardware',
    description: 'AMD EPYC 7F72, Ryzen 9000 Series, and Intel Xeon Platinum processors for maximum performance.',
  },
  {
    icon: Shield,
    title: 'DDoS Protection',
    description: 'Cloudflare Magic Transit with custom BPF rules, inline eBPF/XDP filtering at 150 Gbps.',
  },
  {
    icon: Zap,
    title: 'Instant Setup',
    description: 'Automated provisioning gets your server online in minutes, not hours.',
  },
  {
    icon: Globe,
    title: 'Global Locations',
    description: 'India (owned), Germany, Singapore (rented), with 8+ locations coming soon.',
  },
  {
    icon: Server,
    title: '99.97% Uptime',
    description: 'Redundant infrastructure with automatic recovery and backup systems.',
  },
  {
    icon: Clock,
    title: '24/7 Support',
    description: 'Expert support team available around the clock via Discord and tickets.',
  },
];

const stats = [
  { value: '2.4 Tbps', label: 'Largest Mitigated Attack' },
  { value: '< 1 μs', label: 'Attack Detection' },
  { value: '150 Gbps', label: 'Filtering Capacity' },
  { value: '99.97%', label: 'Uptime SLA' },
];

export default function HomePage() {
  return (
    <>
      <section className="relative min-h-[90vh] flex items-center overflow-hidden">
        <div className="absolute inset-0 bg-radial" />
        <div className="absolute inset-0 bg-grid" />
        <div className="absolute inset-0 bg-gradient-to-t from-black via-transparent to-transparent z-10" />

        <div className="relative z-20 container py-20 lg:py-32">
          <div className="grid lg:grid-cols-2 gap-12 lg:gap-16 items-center">
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
              className="max-w-2xl"
            >
              <Badge variant="premium" className="mb-6 animate-pulse-slow">
                <span className="mr-2 relative flex h-2 w-2">
                  <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-red-500 opacity-75" />
                  <span className="relative inline-flex rounded-full h-2 w-2 bg-red-500" />
                </span>
                Now Offering AMD Ryzen 9000 Series VPS
              </Badge>

              <h1 className="text-display-xl text-white gradient-text mb-6 text-balance">
                Infrastructure Hosting
                <br />
                <span className="gradient-text-red">Redefined</span>
              </h1>

              <p className="text-body-lg text-gray-300 mb-8 max-w-xl">
                Premium Minecraft, VPS, Dedicated Server, and Discord Bot hosting powered by
                AMD EPYC & Ryzen hardware. Enterprise DDoS protection, unlimited bandwidth,
                and 24/7 expert support.
              </p>

              <div className="flex flex-col sm:flex-row gap-4 mb-12">
                <LinkButton href="/contact" size="xl" variant="premium">
                  Get Started
                  <ArrowRight className="ml-2 h-5 w-5" />
                </LinkButton>
                <LinkButton href={DISCORD_INVITE} target="_blank" rel="noopener noreferrer" size="xl" variant="secondary">
                  Join Discord
                </LinkButton>
              </div>

              <div className="flex flex-wrap items-center gap-6 text-sm text-gray-400">
                <div className="flex items-center gap-2">
                  <Check className="h-4 w-4 text-green-500" />
                  <span>No setup fees</span>
                </div>
                <div className="flex items-center gap-2">
                  <Check className="h-4 w-4 text-green-500" />
                  <span>Instant deployment</span>
                </div>
                <div className="flex items-center gap-2">
                  <Check className="h-4 w-4 text-green-500" />
                  <span>Cancel anytime</span>
                </div>
              </div>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, x: 30 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.6, delay: 0.1 }}
              className="relative"
            >
              <div className="relative aspect-[4/3] max-w-lg mx-auto">
                <ServerRackCanvas className="w-full h-full" />
              </div>
              <div className="absolute -bottom-6 -left-6 right-6 flex justify-center gap-4 md:gap-8">
                {stats.map((stat, i) => (
                  <motion.div
                    key={stat.label}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.4, delay: 0.3 + i * 0.1 }}
                    className="text-center bg-black/50 border border-gray-800 rounded-xl p-4 backdrop-blur-sm"
                  >
                    <div className="text-2xl sm:text-3xl font-bold text-red-500 gradient-text-red">
                      {stat.value}
                    </div>
                    <div className="text-xs text-gray-400 mt-1">{stat.label}</div>
                  </motion.div>
                ))}
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      <section className="section bg-gradient-to-b from-gray-950 to-black border-y border-gray-800">
        <div className="container">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center max-w-3xl mx-auto mb-16"
          >
            <h2 className="text-display-md text-white mb-4">Our Services</h2>
            <p className="text-body-lg text-gray-400">
              Choose from specialized hosting solutions tailored for gaming, applications, and automation.
            </p>
          </motion.div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            {[
              {
                href: '/games/minecraft',
                icon: Server,
                title: 'Minecraft Hosting',
                description: 'Intel Xeon & AMD EPYC from ₹29/GB',
                plans: '16 configurations',
                badge: 'Popular',
              },
              {
                href: '/vps',
                icon: Cpu,
                title: 'VPS Hosting',
                description: 'Ryzen 9000 & EPYC 7F72 from ₹179/GB',
                plans: '14 configurations',
                badge: 'New',
              },
              {
                href: '/dedicated',
                icon: Server,
                title: 'Dedicated Servers',
                description: 'Bare metal Ryzen 9/EPYC from ₹3,200/mo',
                plans: '11 configurations',
              },
              {
                href: '/bothosting',
                icon: Zap,
                title: 'Bot Hosting',
                description: 'EPYC 7F72 NVMe from ₹59/mo',
                plans: '6 configurations',
              },
            ].map((service, i) => (
              <motion.article
                key={service.title}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.1 }}
              >
                <Link
                  href={service.href}
                  className="group block h-full card-base card-hover p-6 hover:border-red-500/30 transition-all duration-300"
                >
                  <div className="flex items-start gap-4">
                    <div className="h-12 w-12 rounded-xl bg-gradient-to-br from-red-600 to-red-700 flex items-center justify-center flex-shrink-0 group-hover:scale-110 transition-transform">
                      <service.icon className="h-6 w-6 text-white" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center justify-between gap-2">
                        <h3 className="text-heading-sm text-white group-hover:text-red-400 transition-colors">
                          {service.title}
                        </h3>
                        {service.badge && (
                          <Badge variant="premium" size="sm">
                            {service.badge}
                          </Badge>
                        )}
                      </div>
                      <p className="mt-2 text-body-sm text-gray-400">{service.description}</p>
                      <p className="mt-1 text-caption font-mono">{service.plans}</p>
                    </div>
                  </div>
                  <ArrowRight className="mt-4 h-5 w-5 text-gray-500 group-hover:text-red-500 group-hover:translate-x-1 transition-all" />
                </Link>
              </motion.article>
            ))}
          </div>
        </div>
      </section>

      <section className="section">
        <div className="container">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center max-w-3xl mx-auto mb-16"
          >
            <h2 className="text-display-md text-white mb-4">Why Choose ZENITHZcloud?</h2>
            <p className="text-body-lg text-gray-400">
              Enterprise-grade infrastructure with transparent pricing and no hidden fees.
            </p>
          </motion.div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {features.map((feature, i) => (
              <motion.div
                key={feature.title}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.08 }}
              >
                <Card variant="elevated" padding="lg" className="h-full">
                  <CardContent className="flex flex-col h-full">
                    <div className="h-10 w-10 rounded-lg bg-red-600/20 flex items-center justify-center mb-4">
                      <feature.icon className="h-5 w-5 text-red-500" />
                    </div>
                    <h3 className="text-heading-sm text-white mb-2">{feature.title}</h3>
                    <p className="text-body-sm text-gray-400 flex-1">{feature.description}</p>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      <section className="section bg-gradient-to-b from-gray-950 to-black border-y border-gray-800">
        <div className="container">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
            >
              <Badge variant="premium" className="mb-4">Minecraft Server Hosting</Badge>
              <h2 className="text-display-sm text-white mb-4">Best-in-Class Game Hosting</h2>
              <p className="text-body-lg text-gray-400 mb-6">
                From budget-friendly Intel Xeon v4 at ₹29/GB to premium AMD Ryzen 9 at ₹189/GB.
                Support for Vanilla, Paper, Spigot, Forge, and Fabric with one-click modpack installation.
              </p>
              <ul className="space-y-3 mb-8">
                {[
                  'DDR4 RAM & Gen 5 SATA SSD storage',
                  'Custom Minecraft control panel',
                  'Plugin & mod management with one-click add-ons',
                  'Automatic backups & recovery',
                  'DDoS protection with game-specific filtering',
                  'Multiple locations: India, Germany, Singapore',
                ].map((item, i) => (
                  <li key={i} className="flex items-center gap-3 text-gray-300">
                    <Check className="h-5 w-5 text-green-500 flex-shrink-0" />
                    <span>{item}</span>
                  </li>
                ))}
              </ul>
              <LinkButton href="/games/minecraft" size="lg" variant="premium">
                View Minecraft Plans
              </LinkButton>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: 0.1 }}
              className="relative"
            >
              <div className="aspect-video rounded-2xl border border-gray-800 overflow-hidden bg-black/50">
                <div className="absolute inset-0 bg-gradient-to-br from-red-600/10 via-transparent to-transparent" />
                <div className="relative h-full flex items-center justify-center p-8">
                  <div className="text-center max-w-md">
                    <div className="text-6xl font-bold text-red-500 gradient-text-red mb-2">₹29</div>
                    <div className="text-gray-400 mb-6">Starting per GB/month</div>
                    <div className="grid grid-cols-3 gap-4 text-center">
                      <div className="p-4 bg-gray-900/50 rounded-xl border border-gray-800">
                        <div className="text-2xl font-bold text-white">4</div>
                        <div className="text-xs text-gray-400">CPU Families</div>
                      </div>
                      <div className="p-4 bg-gray-900/50 rounded-xl border border-gray-800">
                        <div className="text-2xl font-bold text-white">16</div>
                        <div className="text-xs text-gray-400">RAM Options</div>
                      </div>
                      <div className="p-4 bg-gray-900/50 rounded-xl border border-gray-800">
                        <div className="text-2xl font-bold text-white">3</div>
                        <div className="text-xs text-gray-400">Locations</div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      <section className="section">
        <div className="container">
          <div className="text-center max-w-3xl mx-auto mb-16">
            <h2 className="text-display-md text-white mb-4">Ready to Deploy?</h2>
            <p className="text-body-lg text-gray-400">
              Join thousands of customers running on ZENITHZcloud infrastructure.
              Get started in minutes with instant setup.
            </p>
          </div>

          <div className="grid md:grid-cols-2 gap-6 max-w-4xl mx-auto">
            <Card variant="premium" padding="xl" className="text-center">
              <CardContent className="flex flex-col items-center">
                <div className="h-16 w-16 rounded-xl bg-gradient-to-br from-red-600 to-red-700 flex items-center justify-center mb-6">
                  <svg className="h-8 w-8 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3L4 14h7v7l9-11h-7z" />
                  </svg>
                </div>
                <h3 className="text-heading-lg text-white mb-2">Deploy in Minutes</h3>
                <p className="text-gray-400 mb-6 max-w-sm">
                  Automated provisioning means your server is ready almost instantly after ordering.
                </p>
                <LinkButton href="/contact" size="lg" variant="premium" className="w-full sm:w-auto">
                  Start Now
                </LinkButton>
              </CardContent>
            </Card>

            <Card variant="elevated" padding="xl" className="text-center">
              <CardContent className="flex flex-col items-center">
                <div className="h-16 w-16 rounded-xl bg-gray-800 flex items-center justify-center mb-6 border border-gray-700">
                  <svg className="h-8 w-8 text-gray-300" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z" />
                  </svg>
                </div>
                <h3 className="text-heading-lg text-white mb-2">Need Help Deciding?</h3>
                <p className="text-gray-400 mb-6 max-w-sm">
                  Our community on Discord can help you choose the perfect plan for your needs.
                </p>
                <LinkButton href={DISCORD_INVITE} target="_blank" rel="noopener noreferrer" size="lg" variant="secondary" className="w-full sm:w-auto">
                  Join Discord
                </LinkButton>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>
    </>
  );
}