import { MetadataRoute } from 'next';
import { siteConfig } from '@/lib/seo';

export default function sitemap(): MetadataRoute.Sitemap {
  const baseUrl = siteConfig.url;

  const routes = [
    '',
    '/games',
    '/games/minecraft',
    '/vps',
    '/dedicated',
    '/bothosting',
    '/features',
    '/locations',
    '/faq',
    '/contact',
    '/privacy',
    '/terms',
    '/refund-policy',
  ];

  return routes.map((route) => ({
    url: `${baseUrl}${route}`,
    lastModified: new Date(),
    changeFrequency: route === '' ? 'daily' : route.includes('/games') || route === '/vps' || route === '/dedicated' || route === '/bothosting' ? 'weekly' : 'monthly',
    priority: route === '' ? 1 : route.includes('/games') || route === '/vps' || route === '/dedicated' || route === '/bothosting' ? 0.8 : 0.6,
  }));
}