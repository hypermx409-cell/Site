import { Metadata } from 'next';
import { motion } from 'framer-motion';
import { MapPin, Check, Clock, Server, AlertTriangle, Wifi, ArrowRight } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { LOCATIONS_DATA, type Location, DISCORD_INVITE } from '@/data/plans';
import { generateMetadata } from '@/lib/seo';

export const metadata: Metadata = generateMetadata({
  title: 'Server Locations',
  description: 'Global server locations in India, Germany, Singapore with 8+ coming soon. Low latency hosting for your applications and game servers.',
  path: '/locations',
});

const locations = Object.entries(LOCATIONS_DATA) as [Location, typeof LOCATIONS_DATA[keyof typeof LOCATIONS_DATA]][];

const availableLocations = locations.filter(([, data]) => data.status === 'available' || data.status === 'advertised');
const comingSoonLocations = locations.filter(([, data]) => data.status === 'coming-soon');

export default function LocationsPage() {
  return (
    <>
      <section className="relative min-h-[50vh] flex items-center overflow-hidden">
        <div className="absolute inset-0 bg-radial-bottom" />
        <div className="absolute inset-0 bg-grid" />

        <div className="relative z-10 container py-16 lg:py-24">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="max-w-3xl"
          >
            <Badge variant="premium" className="mb-4">Global Infrastructure</Badge>
            <h1 className="text-display-lg text-white mb-4">Server Locations</h1>
            <p className="text-body-lg text-gray-400 mb-8">
              Deploy close to your users. Owned hardware in Mumbai, rented infrastructure in Frankfurt and Singapore,
              with 8+ locations on our roadmap.
            </p>
            <div className="flex flex-col sm:flex-row gap-4">
              <Button asChild size="lg" variant="premium">
                <a href="/contact">Deploy Now</a>
              </Button>
              <Button asChild size="lg" variant="secondary">
                <a href={DISCORD_INVITE} target="_blank" rel="noopener noreferrer">
                  Request Location
                </a>
              </Button>
            </div>
          </motion.div>
        </div>
      </section>

      <section className="section">
        <div className="container">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="mb-12"
          >
            <h2 className="text-display-sm text-white mb-4">Available Now</h2>
            <p className="text-body-lg text-gray-400 max-w-2xl">
              These locations are live and ready for deployment. India runs on our owned hardware;
              Germany and Singapore use premium rented infrastructure.
            </p>
          </motion.div>

          <div className="grid md:grid-cols-3 gap-6 mb-16">
            {availableLocations.map(([key, data], i) => (
              <motion.article
                key={key}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.1 }}
              >
                <Card variant="elevated" padding="lg" className="h-full relative">
                  <Badge
                    variant={data.status === 'available' ? 'success' : 'warning'}
                    className="absolute top-4 right-4"
                  >
                    {data.status === 'available' ? 'Available' : 'Advertised'}
                  </Badge>
                  <CardContent className="flex flex-col h-full">
                    <div className="flex items-center gap-3 mb-4">
                      <span className="text-3xl">{data.flag}</span>
                      <div>
                        <h3 className="text-heading-md text-white">{data.name}</h3>
                        <p className="text-sm text-gray-400">{data.country}</p>
                      </div>
                    </div>

                    <div className="space-y-3 mb-6">
                      <div className="flex items-center gap-3 text-gray-300">
                        <Server className="h-5 w-5 text-gray-400" />
                        <span>Provider: <span className="text-white capitalize">{data.providerType}</span></span>
                      </div>
                      {data.latencyMs && (
                        <div className="flex items-center gap-3 text-gray-300">
                          <Clock className="h-5 w-5 text-gray-400" />
                          <span>
                            Provider-reported latency: <span className="text-white font-mono">{data.latencyMs}ms</span>
                            {!data.latencyVerified && <Badge variant="warning" size="sm" className="ml-2">Unverified</Badge>}
                          </span>
                        </div>
                      )}
                      <div className="flex items-center gap-3 text-gray-300">
                        <Wifi className="h-5 w-5 text-gray-400" />
                        <span>DDoS Protected: <span className="text-white">Yes</span></span>
                      </div>
                    </div>

                    <div className="mt-auto pt-4 border-t border-gray-800">
                      <Button variant="outline" className="w-full" asChild>
                        <a href="/contact">Deploy Here</a>
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              </motion.article>
            ))}
          </div>

          {availableLocations.some(([, data]) => data.latencyMs && !data.latencyVerified) && (
            <div className="mb-12 p-4 bg-yellow-600/10 border border-yellow-600/30 rounded-xl">
              <div className="flex items-start gap-3">
                <AlertTriangle className="h-5 w-5 text-yellow-500 mt-0.5 flex-shrink-0" />
                <div className="text-sm text-yellow-300">
                  <strong>Note:</strong> Latency figures are provider-reported and not independently verified.
                  Actual latency varies by ISP, routing, and network conditions.
                </div>
              </div>
            </div>
          )}
        </div>
      </section>

      <section className="section bg-gradient-to-b from-gray-950 to-black border-y border-gray-800">
        <div className="container">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="mb-12"
          >
            <h2 className="text-display-sm text-white mb-4">Coming Soon</h2>
            <p className="text-body-lg text-gray-400 max-w-2xl">
              We're actively expanding our global footprint. Join our Discord to vote for the next location.
            </p>
          </motion.div>

          <div className="grid md:grid-cols-3 lg:grid-cols-4 gap-6">
            {comingSoonLocations.map(([key, data], i) => (
              <motion.article
                key={key}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.08 }}
              >
                <Card variant="outlined" padding="lg" className="h-full opacity-60 relative">
                  <Badge variant="secondary" className="absolute top-4 right-4">Coming Soon</Badge>
                  <CardContent className="flex flex-col h-full items-center text-center">
                    <span className="text-4xl mb-4">{data.flag}</span>
                    <h3 className="text-heading-md text-white mb-1">{data.name}</h3>
                    <p className="text-sm text-gray-400 mb-4">{data.country}</p>
                    <Button variant="ghost" size="sm" disabled>Notify Me</Button>
                  </CardContent>
                </Card>
              </motion.article>
            ))}
          </div>
        </div>
      </section>

      <section className="section">
        <div className="container">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="mb-12 text-center"
          >
            <h2 className="text-display-sm text-white mb-4">Location-Aware Services</h2>
            <p className="text-body-lg text-gray-400 max-w-2xl mx-auto">
              Not all services are available in every location. Check service availability per region.
            </p>
          </motion.div>

          <div className="overflow-x-auto rounded-xl border border-gray-800">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-gray-800 bg-gray-900/50">
                  <th className="px-4 py-3 text-left font-medium text-gray-300">Service</th>
                  <th className="px-4 py-3 text-center font-medium text-gray-300">India (Mumbai)</th>
                  <th className="px-4 py-3 text-center font-medium text-gray-300">Germany (Frankfurt)</th>
                  <th className="px-4 py-3 text-center font-medium text-gray-300">Singapore</th>
                </tr>
              </thead>
              <tbody>
                {[
                  { service: 'Minecraft Hosting', india: true, germany: true, singapore: true },
                  { service: 'VPS (Ryzen 9000)', india: true, germany: false, singapore: false },
                  { service: 'VPS (EPYC 7F72)', india: true, germany: true, singapore: true },
                  { service: 'Dedicated Servers', india: true, germany: false, singapore: false },
                  { service: 'Bot Hosting', india: true, germany: true, singapore: true },
                ].map((row, i) => (
                  <tr key={row.service} className={i % 2 === 0 ? 'bg-black/30' : ''}>
                    <td className="px-4 py-3 text-white font-medium border-b border-gray-800/50">{row.service}</td>
                    <td className="px-4 py-3 text-center border-b border-gray-800/50">
                      {row.india ? <Check className="h-5 w-5 text-green-500 mx-auto" /> : <span className="text-gray-500">—</span>}
                    </td>
                    <td className="px-4 py-3 text-center border-b border-gray-800/50">
                      {row.germany ? <Check className="h-5 w-5 text-green-500 mx-auto" /> : <span className="text-gray-500">—</span>}
                    </td>
                    <td className="px-4 py-3 text-center border-b border-gray-800/50">
                      {row.singapore ? <Check className="h-5 w-5 text-green-500 mx-auto" /> : <span className="text-gray-500">—</span>}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </section>

      <section className="section bg-gradient-to-b from-gray-950 to-black border-y border-gray-800">
        <div className="container text-center">
          <h2 className="text-display-sm text-white mb-4">Want a Location We Don't Have?</h2>
          <p className="text-body-lg text-gray-400 mb-8 max-w-2xl mx-auto">
            We prioritize new locations based on community demand. Let us know where you need servers.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button asChild size="lg" variant="premium">
              <a href={DISCORD_INVITE} target="_blank" rel="noopener noreferrer">
                Request on Discord
              </a>
            </Button>
            <Button asChild size="lg" variant="secondary">
              <a href="/contact">Contact Sales</a>
            </Button>
          </div>
        </div>
      </section>
    </>
  );
}