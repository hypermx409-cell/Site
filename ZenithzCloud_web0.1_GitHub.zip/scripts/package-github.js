#!/usr/bin/env node
/**
 * Package for GitHub Repository
 * Creates a clean source ZIP excluding build artifacts, dependencies, and secrets
 */

const fs = require('fs');
const path = require('path');
const { execSync } = require('child_process');

const ROOT_DIR = path.resolve(__dirname, '..');
const DIST_DIR = path.join(ROOT_DIR, 'dist');
const TEMP_DIR = path.join(ROOT_DIR, '.temp-github-package');
const ZIP_NAME = 'ZenithzCloud_web0.1_GitHub.zip';
const ZIP_PATH = path.join(DIST_DIR, ZIP_NAME);

// Files/directories to include (everything else excluded)
const INCLUDE_PATTERNS = [
  'src',
  'src/**',
  'public',
  'public/**',
  'package.json',
  'package-lock.json',
  'tsconfig.json',
  'next.config.*',
  'tailwind.config.*',
  'postcss.config.*',
  '.gitignore',
  'README.md',
  'docs',
  'docs/**',
  'scripts',
  'scripts/**',
];

// Files/directories to explicitly exclude
const EXCLUDE_PATTERNS = [
  'node_modules',
  '.next',
  '.turbo',
  'dist',
  '.git',
  '*.log',
  '.env*',
  '.vercel',
  '*.zip',
  '.DS_Store',
  'coverage',
  '.nyc_output',
  '*.tsbuildinfo',
  '.temp-github-package',
];

function ensureDir(dir) {
  if (!fs.existsSync(dir)) {
    fs.mkdirSync(dir, { recursive: true });
  }
}

function runCommand(cmd, cwd = ROOT_DIR) {
  console.log(`$ ${cmd}`);
  try {
    execSync(cmd, { cwd, stdio: 'inherit' });
    return true;
  } catch (error) {
    console.error(`Command failed: ${cmd}`);
    return false;
  }
}

function createGitIgnore() {
  const gitignorePath = path.join(ROOT_DIR, '.gitignore');
  const content = `# Dependencies
node_modules
.pnp
.pnp.js

# Build outputs
.next
out
build
dist

# Testing
coverage
.nyc_output

# Environment
.env
.env.local
.env.production
.env.development

# IDE
.idea
.vscode
*.swp
*.swo
*~

# OS
.DS_Store
Thumbs.db

# Logs
*.log
npm-debug.log*
yarn-debug.log*
yarn-error.log*

# Vercel
.vercel

# TypeScript
*.tsbuildinfo

# Package outputs
*.zip
`;

  if (!fs.existsSync(gitignorePath)) {
    fs.writeFileSync(gitignorePath, content);
    console.log('Created .gitignore');
  }
}

function copyFilesSync(src, dest) {
  if (!fs.existsSync(src)) return;
  
  const stat = fs.statSync(src);
  if (stat.isDirectory()) {
    if (!fs.existsSync(dest)) {
      fs.mkdirSync(dest, { recursive: true });
    }
    for (const item of fs.readdirSync(src)) {
      copyFilesSync(path.join(src, item), path.join(dest, item));
    }
  } else {
    fs.copyFileSync(src, dest);
  }
}

function shouldExclude(relativePath) {
  for (const pattern of EXCLUDE_PATTERNS) {
    // Convert glob pattern to regex
    // ** matches any number of directories (including zero)
    // * matches any characters except /
    const regexStr = pattern
      .replace(/\./g, '\\.')
      .replace(/\*\*/g, '.*')
      .replace(/\*/g, '[^/]*');
    const regex = new RegExp('^' + regexStr + '$');
    if (regex.test(relativePath)) return true;
    // Also check path segments
    const segments = relativePath.split('/');
    for (const segment of segments) {
      if (regex.test(segment)) return true;
    }
  }
  return false;
}

function shouldInclude(relativePath) {
  for (const pattern of INCLUDE_PATTERNS) {
    // Convert glob pattern to regex
    const regexStr = pattern
      .replace(/\./g, '\\.')
      .replace(/\*\*/g, '.*')
      .replace(/\*/g, '[^/]*');
    const regex = new RegExp('^' + regexStr + '$');
    if (regex.test(relativePath)) return true;
    // Check if any parent directory matches
    const segments = relativePath.split('/');
    for (let i = 1; i <= segments.length; i++) {
      const prefix = segments.slice(0, i).join('/');
      if (regex.test(prefix)) return true;
    }
  }
  return false;
}

function main() {
  console.log('📦 Creating GitHub repository package...\n');

  ensureDir(DIST_DIR);
  createGitIgnore();

  // Clean up temp dir
  if (fs.existsSync(TEMP_DIR)) {
    fs.rmSync(TEMP_DIR, { recursive: true, force: true });
  }
  fs.mkdirSync(TEMP_DIR, { recursive: true });

  // Copy files that should be included
  console.log('Copying source files...');
  let copiedCount = 0;
  
  function walkDir(dir, baseDir = ROOT_DIR) {
    const items = fs.readdirSync(dir);
    for (const item of items) {
      const srcPath = path.join(dir, item);
      const relPath = path.relative(ROOT_DIR, srcPath);
      
      if (shouldExclude(relPath)) continue;
      if (!shouldInclude(relPath)) continue;

      const destPath = path.join(TEMP_DIR, relPath);
      const stat = fs.statSync(srcPath);
      
      if (stat.isDirectory()) {
        if (!fs.existsSync(destPath)) {
          fs.mkdirSync(destPath, { recursive: true });
        }
        walkDir(srcPath);
      } else {
        const destDir = path.dirname(destPath);
        if (!fs.existsSync(destDir)) {
          fs.mkdirSync(destDir, { recursive: true });
        }
        fs.copyFileSync(srcPath, destPath);
        copiedCount++;
      }
    }
  }

  walkDir(ROOT_DIR);

  console.log(`Copied ${copiedCount} files`);

  // Remove existing ZIP
  if (fs.existsSync(ZIP_PATH)) {
    fs.unlinkSync(ZIP_PATH);
  }

  // Create ZIP from temp directory
  console.log('\nCreating ZIP...');
  const cmd = `cd "${TEMP_DIR}" && zip -r "${ZIP_PATH}" .`;
  
  const { execSync } = require('child_process');
  try {
    execSync(cmd, { stdio: 'inherit' });
    
    const stats = fs.statSync(ZIP_PATH);
    const sizeMB = (stats.size / (1024 * 1024)).toFixed(2);
    console.log(`\n✅ GitHub package created: ${ZIP_PATH}`);
    console.log(`   Size: ${sizeMB} MB`);
    console.log(`\nContents (first 30):`);
    require('child_process').execSync(`unzip -l "${ZIP_PATH}" | head -30`, { stdio: 'inherit' });
  } catch (error) {
    console.error('\n❌ Failed to create GitHub package');
    process.exit(1);
  } finally {
    // Clean up temp dir
    if (fs.existsSync(TEMP_DIR)) {
      fs.rmSync(TEMP_DIR, { recursive: true, force: true });
    }
  }
}

main();