#!/usr/bin/env node
/**
 * Package for Vercel Deployment
 * Creates a deployment-ready ZIP with source code for Vercel to build
 */

const fs = require('fs');
const path = require('path');
const { execSync } = require('child_process');

const ROOT_DIR = path.resolve(__dirname, '..');
const DIST_DIR = path.join(ROOT_DIR, 'dist');
const TEMP_DIR = path.join(ROOT_DIR, '.temp-vercel-package');
const ZIP_NAME = 'ZenithzCloud_web0.1_Vercel.zip';
const ZIP_PATH = path.join(DIST_DIR, ZIP_NAME);

// Files/directories to include
const INCLUDE_PATTERNS = [
  'src',
  'src/**',
  'public',
  'public/**',
  'package.json',
  'package-lock.json',
  'tsconfig.json',
  'next.config.*',
  'tailwind.config.*',
  'postcss.config.*',
  '.gitignore',
  'README.md',
  'docs',
  'docs/**',
  'scripts',
  'scripts/**',
];

// Files/directories to explicitly exclude
const EXCLUDE_PATTERNS = [
  'node_modules/**',
  '.next/**',
  '.turbo/**',
  'dist/**',
  '.git/**',
  '*.log',
  '.env*',
  '.vercel/**',
  '*.zip',
  '.DS_Store',
  'coverage/**',
  '.nyc_output/**',
  '*.tsbuildinfo',
  '.temp-vercel-package/**',
];

function ensureDir(dir) {
  if (!fs.existsSync(dir)) {
    fs.mkdirSync(dir, { recursive: true });
  }
}

function runCommand(cmd, cwd = ROOT_DIR) {
  console.log(`$ ${cmd}`);
  try {
    execSync(cmd, { cwd, stdio: 'inherit' });
    return true;
  } catch (error) {
    console.error(`Command failed: ${cmd}`);
    return false;
  }
}

function shouldExclude(relativePath) {
  for (const pattern of EXCLUDE_PATTERNS) {
    const regexStr = pattern
      .replace(/\./g, '\\.')
      .replace(/\*\*/g, '__DOUBLE_STAR__')
      .replace(/\*/g, '[^/]*')
      .replace(/__DOUBLE_STAR__/g, '.*');
    const regex = new RegExp('^' + regexStr + '$');
    if (regex.test(relativePath)) return true;
    const segments = relativePath.split('/');
    for (const segment of segments) {
      if (regex.test(segment)) return true;
    }
  }
  return false;
}

function shouldInclude(relativePath) {
  for (const pattern of INCLUDE_PATTERNS) {
    const regexStr = pattern
      .replace(/\./g, '\\.')
      .replace(/\*\*/g, '__DOUBLE_STAR__')
      .replace(/\*/g, '[^/]*')
      .replace(/__DOUBLE_STAR__/g, '.*');
    const regex = new RegExp('^' + regexStr + '$');
    if (regex.test(relativePath)) return true;
    const segments = relativePath.split('/');
    for (let i = 1; i <= segments.length; i++) {
      const prefix = segments.slice(0, i).join('/');
      if (regex.test(prefix)) return true;
    }
  }
  return false;
}

function main() {
  console.log('📦 Creating Vercel deployment package...\n');

  ensureDir(DIST_DIR);

  // Clean up temp dir
  if (fs.existsSync(TEMP_DIR)) {
    fs.rmSync(TEMP_DIR, { recursive: true, force: true });
  }
  fs.mkdirSync(TEMP_DIR, { recursive: true });

  // Copy files that should be included
  console.log('Copying source files...');
  let copiedCount = 0;

  function walkDir(dir) {
    const items = fs.readdirSync(dir);
    for (const item of items) {
      const srcPath = path.join(dir, item);
      const relPath = path.relative(ROOT_DIR, srcPath);

      if (shouldExclude(relPath)) continue;
      if (!shouldInclude(relPath)) continue;

      const destPath = path.join(TEMP_DIR, relPath);
      const stat = fs.statSync(srcPath);

      if (stat.isDirectory()) {
        if (!fs.existsSync(destPath)) {
          fs.mkdirSync(destPath, { recursive: true });
        }
        walkDir(srcPath);
      } else {
        const destDir = path.dirname(destPath);
        if (!fs.existsSync(destDir)) {
          fs.mkdirSync(destDir, { recursive: true });
        }
        fs.copyFileSync(srcPath, destPath);
        copiedCount++;
      }
    }
  }

  walkDir(ROOT_DIR);

  console.log(`Copied ${copiedCount} files`);

  // Remove existing ZIP
  if (fs.existsSync(ZIP_PATH)) {
    fs.unlinkSync(ZIP_PATH);
  }

  // Create ZIP from temp directory
  console.log('\nCreating ZIP...');
  const cmd = `cd "${TEMP_DIR}" && zip -r "${ZIP_PATH}" .`;

  try {
    execSync(cmd, { stdio: 'inherit' });

    const stats = fs.statSync(ZIP_PATH);
    const sizeMB = (stats.size / (1024 * 1024)).toFixed(2);
    console.log(`\n✅ Vercel package created: ${ZIP_PATH}`);
    console.log(`   Size: ${sizeMB} MB`);
    console.log(`\nThis package contains source code for Vercel to build.`);
    console.log(`Vercel will run: npm install && npm run build`);
    console.log(`\nContents (first 30):`);
    execSync(`unzip -l "${ZIP_PATH}" | head -30`, { stdio: 'inherit' });
  } catch (error) {
    console.error('\n❌ Failed to create Vercel package');
    process.exit(1);
  } finally {
    // Clean up temp dir
    if (fs.existsSync(TEMP_DIR)) {
      fs.rmSync(TEMP_DIR, { recursive: true, force: true });
    }
  }
}

main();