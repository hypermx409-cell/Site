#!/usr/bin/env node
/**
 * Post-build verification
 * Checks that the build completed successfully and key files exist
 */

const fs = require('fs');
const path = require('path');

const ROOT_DIR = path.resolve(__dirname, '..');
const BUILD_DIR = path.join(ROOT_DIR, '.next');

const REQUIRED_FILES = [
  'BUILD_ID',
  'required-server-files.json',
];

const REQUIRED_DIRS = [
  'server/app',
  'static',
];

function main() {
  console.log('🔍 Verifying build output...\n');

  let allGood = true;

  // Check .next directory exists
  if (!fs.existsSync(BUILD_DIR)) {
    console.error('❌ .next directory not found - build may have failed');
    process.exit(1);
  }

  // Check required files
  for (const file of REQUIRED_FILES) {
    const filePath = path.join(BUILD_DIR, file);
    if (fs.existsSync(filePath)) {
      console.log(`✅ ${file}`);
    } else {
      console.error(`❌ Missing: ${file}`);
      allGood = false;
    }
  }

  // Check required directories
  for (const dir of REQUIRED_DIRS) {
    const dirPath = path.join(BUILD_DIR, dir);
    if (fs.existsSync(dirPath)) {
      console.log(`✅ ${dir}/`);
    } else {
      console.error(`❌ Missing directory: ${dir}/`);
      allGood = false;
    }
  }

  // Check for server pages
  const serverAppDir = path.join(BUILD_DIR, 'server/app');
  if (fs.existsSync(serverAppDir)) {
    const pages = fs.readdirSync(serverAppDir, { recursive: true })
      .filter(f => f.endsWith('.js') || f.endsWith('.html'))
      .length;
    console.log(`✅ Server pages compiled: ${pages} files`);
  }

  // Check static assets (optional - may not exist in all environments)
  const staticDir = path.join(BUILD_DIR, 'static');
  if (fs.existsSync(staticDir)) {
    const chunksDir = path.join(staticDir, 'chunks');
    if (fs.existsSync(chunksDir)) {
      const chunks = fs.readdirSync(chunksDir, { recursive: true })
        .filter(f => f.endsWith('.js')).length;
      console.log(`✅ Static JS chunks: ${chunks}`);
    } else {
      console.log('ℹ️  Static chunks directory not found (may be expected on some platforms)');
    }
  }

  if (allGood) {
    console.log('\n✅ Build verification passed!');
    process.exit(0);
  } else {
    console.error('\n❌ Build verification failed!');
    process.exit(1);
  }
}

main();