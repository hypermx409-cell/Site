# ZENITHZcloud Website

Premium infrastructure hosting website for ZENITHZcloud - Minecraft, VPS, Dedicated Servers, and Discord Bot hosting.

## 🚀 Quick Start

```bash
# Install dependencies
npm install

# Development server
npm run dev

# Production build
npm run build

# Preview production build
npm start

# Linting
npm run lint

# Type checking
npm run type-check
```

## 📁 Project Structure

```
src/
├── app/                    # Next.js App Router pages
│   ├── games/
│   │   └── minecraft/      # Minecraft hosting page
│   ├── vps/                # VPS hosting page
│   ├── dedicated/          # Dedicated servers page
│   ├── bothosting/         # Bot hosting page
│   ├── features/           # Features & infrastructure
│   ├── locations/          # Server locations
│   ├── faq/                # FAQ page
│   ├── contact/            # Contact page
│   ├── privacy/            # Privacy policy
│   ├── terms/              # Terms of service
│   ├── refund-policy/      # Refund policy
│   ├── layout.tsx          # Root layout
│   ├── page.tsx            # Homepage
│   ├── globals.css         # Global styles
│   ├── sitemap.ts          # Sitemap generation
│   └── robots.ts           # Robots.txt
├── components/
│   ├── ui/                 # Base UI components
│   ├── layout/             # Header, Footer
│   ├── sections/           # Page sections
│   ├── pricing/            # Pricing components
│   └── three/              # 3D components (React Three Fiber)
├── data/
│   └── plans.ts            # Central pricing & plan data
├── lib/
│   ├── utils.ts            # Utility functions
│   └── seo.ts              # SEO metadata helpers
└── docs/
    └── SOURCE_AUDIT.md     # Source verification report
```

## 🛠 Tech Stack

- **Framework:** Next.js 15 (App Router)
- **Language:** TypeScript
- **Styling:** Tailwind CSS v4
- **Animations:** Framer Motion
- **3D Graphics:** React Three Fiber / Three.js
- **Icons:** Lucide React
- **UI Primitives:** Radix UI
- **Deployment:** Vercel

## 🎨 Design System

### Colors
- **Primary:** Red 600 (`#dc2626`) - ZENITHZ brand
- **Background:** Black (`#000000`) / Gray 950
- **Surfaces:** Gray 900, Gray 800
- **Text:** White, Gray 300, Gray 400
- **Accents:** Red 500, Green 500, Yellow 500

### Typography
- **Display:** Geist Sans (variable font)
- **Body:** Geist Sans
- **Mono:** Geist Mono

### Principles
- No glassmorphism/frosted glass
- Deep black/charcoal surfaces
- Strong contrast and hierarchy
- Sharp borders, clean separators
- Generous negative space

## 📊 Pricing Data

All pricing and plan specifications are centralized in `/src/data/plans.ts`.

**Key Features:**
- Type-safe plan definitions
- CPU family configurations
- Location data with status
- Infrastructure claims tracking
- Formatting utilities

**⚠️ Important:** Data is based on master prompt specifications. Live website was not accessible during development. All values marked `verified: false` need confirmation before launch.

## 🔧 Configuration

### Environment Variables
Create `.env.local` for local development:

```env
# Optional: Analytics, error tracking, etc.
NEXT_PUBLIC_GA_ID=
SENTRY_DSN=
```

### Vercel Deployment
1. Connect repository to Vercel
2. Framework preset: Next.js
3. Build command: `npm run build`
4. Output directory: `.next` (default)
5. No additional configuration needed

## 🧪 Testing

```bash
# Type checking
npm run type-check

# Linting
npm run lint

# Build verification
npm run build
```

## 📦 Creating Deployment Packages

After successful build:

```bash
# Create GitHub-ready ZIP (excludes node_modules, .next, etc.)
npm run package:github

# Create Vercel deployment ZIP
npm run package:vercel
```

Outputs saved to `/dist/`.

## 📋 Pre-Launch Checklist

- [ ] Verify all pricing against live website
- [ ] Legal review: Privacy Policy, Terms, Refund Policy
- [ ] Add actual logo and favicon files to `/public/`
- [ ] Configure analytics and error tracking
- [ ] Test all CTAs and navigation
- [ ] Verify mobile responsiveness
- [ ] Run accessibility audit
- [ ] Confirm Discord invite link works
- [ ] Check all external links
- [ ] Review SOURCE_AUDIT.md for unverified claims

## 📄 License

Proprietary - ZENITHZcloud. All rights reserved.

## 🤝 Support

- **Discord:** https://discord.gg/9gGknK6VWw
- **Website:** https://zenithzcloud.com/
- **Email:** support@zenithzcloud.com