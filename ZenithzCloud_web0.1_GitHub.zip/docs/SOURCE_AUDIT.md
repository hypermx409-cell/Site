# ZenithzCloud Website - Source Audit Report

**Generated:** 2026-10-26  
**Auditor:** AI Assistant (Nemotron 3 Ultra)  
**Target Website:** https://zenithzcloud.com/  
**Status:** Live website was **not accessible** during development

---

## Accessibility Status

| URL | Status | Notes |
|-----|--------|-------|
| https://zenithzcloud.com/ | ❌ Unreachable | Connection timeout / DNS resolution failed |
| https://zenithzcloud.com/games | ❌ Unreachable | Same as above |
| https://zenithzcloud.com/games/minecraft | ❌ Unreachable | Same as above |
| https://zenithzcloud.com/games/minecraft/intel | ❌ Unreachable | Same as above |
| https://zenithzcloud.com/vps | ❌ Unreachable | Same as above |
| https://zenithzcloud.com/dedicated | ❌ Unreachable | Same as above |
| https://zenithzcloud.com/bothosting | ❌ Unreachable | Same as above |

**Network Tools:** `curl`, `wget`, `dig`, `nslookup`, `host`, `ping` were unavailable in the sandbox environment.

---

## Data Sources Used

Since the live website could not be accessed, all data in this implementation is derived from:

1. **Master Prompt Specifications** - The detailed requirements document provided in the project brief
2. **Historical Knowledge** - Common hosting industry patterns and pricing structures

---

## Verified vs Unverified Data

### ✅ Explicitly Provided in Master Prompt (Treated as Baseline)

#### Minecraft Hosting
| CPU Family | Price/GB | RAM Configurations | Verified |
|------------|----------|-------------------|----------|
| Intel Xeon v4 | ₹29 | 2-256 GB (16 tiers) | ❌ No |
| AMD EPYC 7F72 | ₹59 | 2-256 GB (16 tiers) | ❌ No |
| Intel Xeon Platinum | ₹69 | 2-256 GB (16 tiers)* | ❌ No |
| AMD Ryzen 9 | ₹189 | 2-256 GB (16 tiers)* | ❌ No |

*vCPU allocations for Platinum and Ryzen 9 are **assumed** based on EPYC 7F72 pattern. **Need live verification.**

#### VPS Hosting
| CPU Family | Price/GB | Plans Provided | Verified |
|------------|----------|----------------|----------|
| AMD Ryzen 9000 | ₹179 | 10 plans (4-32 GB) | ❌ No |
| AMD EPYC 7F72 | ₹144 | **Matrix missing** - placeholder data used | ❌ No |

**Critical Gap:** AMD EPYC 7F72 VPS pricing matrix was referenced but not provided in detail. Placeholder plans created at ₹144/GB need live verification.

#### Dedicated Servers
| RAM | vCPU | Storage | Price | Verified |
|-----|------|---------|-------|----------|
| 8 GB | 4 | 256 GB | ₹3,200 | ❌ No |
| 12 GB | 6 | 384 GB | ₹4,800 | ❌ No |
| 16 GB | 8 | 512 GB | ₹6,400 | ❌ No |
| 24 GB | 12 | 768 GB | ₹9,600 | ❌ No |
| 32 GB | 16 | 1 TB | ₹12,800 | ❌ No |
| 48 GB | 24 | 1.5 TB | ₹19,200 | ❌ No |
| 64 GB | 32 | 2 TB | ₹25,600 | ❌ No |
| 96 GB | 48 | 3 TB | ₹38,400 | ❌ No |
| 128 GB | 64 | 4 TB | ₹51,200 | ❌ No |
| 192 GB | 96 | 6 TB | ₹76,800 | ❌ No |
| 256 GB | 128 | 8 TB | ₹102,400 | ❌ No |

**Critical Gap:** CPU model per plan not specified. Prompt mentions "AMD Ryzen 9 and AMD EPYC 7F72 hardware mentioned" but no mapping. Implemented as mixed.

#### Bot Hosting
| Plan | RAM | NVMe | vCPU | Price | Verified |
|------|-----|------|------|-------|----------|
| Starter | 1 GB | 5 GB | 1 | ₹59 | ❌ No |
| Pro | 2 GB | 10 GB | 1 | ₹118 | ❌ No |
| Advanced | 4 GB | 20 GB | 2 | ₹236 | ❌ No |
| Elite | 8 GB | 40 GB | 4 | ₹472 | ❌ No |
| Diamond | 12 GB | 60 GB | 6 | ₹708 | ❌ No |
| Ultimate | 16 GB | 80 GB | 8 | ₹944 | ❌ No |

**CPU:** Prompt says "Advertised CPU: AMD EPYC 7F72" but also "references Ryzen 9". Implemented as EPYC 7F72.

#### Game Availability
| Game | Status | Verified |
|------|--------|----------|
| Minecraft | Available | ❌ No |
| Counter-Strike: Global Offensive | Coming Soon | ❌ No |
| Rust | Coming Soon | ❌ No |
| ARK: Survival Evolved | Coming Soon | ❌ No |
| Valheim | Coming Soon | ❌ No |
| Garry's Mod | Coming Soon | ❌ No |

#### Locations
| Location | Status | Latency | Provider | Verified |
|----------|--------|---------|----------|----------|
| India (Mumbai) | Available | < 29ms | Owned | ❌ No |
| Germany (Frankfurt) | Advertised | < 39ms | Rented | ❌ No |
| Singapore | Advertised | < 45ms | Rented | ❌ No |
| Tokyo | Coming Soon | - | Unknown | ❌ No |
| UAE (Dubai) | Coming Soon | - | Unknown | ❌ No |
| London | Coming Soon | - | Unknown | ❌ No |
| Turkey (Istanbul) | Coming Soon | - | Unknown | ❌ No |
| Netherlands (Amsterdam) | Coming Soon | - | Unknown | ❌ No |
| France (Paris) | Coming Soon | - | Unknown | ❌ No |
| USA (New York) | Coming Soon | - | Unknown | ❌ No |
| Australia (Sydney) | Coming Soon | - | Unknown | ❌ No |
| Brazil (São Paulo) | Coming Soon | - | Unknown | ❌ No |

**Latency Disclaimer:** All latency figures are provider-reported, not independently verified.

#### Infrastructure Claims (All Unverified)
| Claim | Detail | Verified |
|-------|--------|----------|
| DDoS Protection | Cloudflare Magic Transit | ❌ No |
| Game-Specific Filtering | Custom BPF rules | ❌ No |
| Inline eBPF/XDP | 150 Gbps capacity | ❌ No |
| Largest Mitigated Attack | 2.4 Tbit/s | ❌ No |
| Attack Detection | < 1 microsecond | ❌ No |
| Uptime | 99.97% | ❌ No |
| Instant Setup | Automated provisioning | ❌ No |
| Auto Recovery & Backups | Included | ❌ No |
| 24/7 Support | Live chat & tickets | ❌ No |
| Resource Scaling | Vertical scaling | ❌ No |
| Global Infrastructure | Multi-region | ❌ No |

---

## Legal Pages Status

| Page | Status | Notes |
|------|--------|-------|
| Privacy Policy | 📝 Draft | Marked as requiring legal review |
| Terms of Service | 📝 Draft | Marked as requiring legal review |
| Refund Policy | 📝 Draft | Marked as requiring legal review |

**Action Required:** Website owner must review, customize, and approve all legal documents with qualified legal counsel before publication.

---

## Order Links & CTAs

| Service | Order Destination | Verified |
|---------|-------------------|----------|
| All Services | Discord (https://discord.gg/9gGknK6VWw) | ❌ No |
| Custom/Enterprise | Contact Form → Discord | ❌ No |

**Implementation Note:** Since exact checkout URLs could not be verified, all "Order Now" buttons redirect to Discord with a note to contact sales. This is safer than fabricating checkout flows.

---

## Assets Needed from Live Site

| Asset | Status | Action |
|-------|--------|--------|
| Logo (SVG/PNG) | ❌ Missing | Download from live site when accessible |
| Favicon (ico, png, svg) | ❌ Missing | Download from live site when accessible |
| OG Image (1200x630) | ❌ Missing | Create based on brand guidelines |
| Product screenshots | ❌ Missing | Capture from live site or create mockups |

---

## Recommendations Before Launch

### Critical (Must Fix)
1. **Verify all pricing** against live website when accessible
2. **Confirm CPU-to-plan mappings** for Intel Xeon Platinum, AMD Ryzen 9, and Dedicated servers
3. **Obtain AMD EPYC 7F72 VPS pricing matrix** from live site
4. **Legal review** of Privacy Policy, Terms of Service, Refund Policy
5. **Download and add** actual logo and favicon files
6. **Test order flows** with actual checkout URLs

### High Priority
1. **Verify latency claims** - add disclaimer if provider-reported only
2. **Confirm location availability** - especially Germany/Singapore "rented" status
3. **Validate infrastructure claims** - add "provider-claimed" badges where appropriate
4. **Test all CTAs** - ensure Discord links work and lead to correct channels

### Medium Priority
1. **Add analytics** (Google Analytics, Plausible, or similar)
2. **Configure error tracking** (Sentry)
3. **Set up uptime monitoring** for status page
4. **Create email templates** for order confirmations, notifications

---

## File References

- **Central Pricing Data:** `/src/data/plans.ts`
- **Legal Pages:** `/src/app/privacy/`, `/src/app/terms/`, `/src/app/refund-policy/`
- **Components using pricing data:** `/src/components/pricing/`
- **Pages:** `/src/app/games/minecraft/`, `/src/app/vps/`, `/src/app/dedicated/`, `/src/app/bothosting/`

---

## Sign-Off Required

Before production deployment, the following must be signed off:

- [ ] **Technical Lead:** Code review, build passes, tests pass
- [ ] **Product Owner:** All pricing verified against source of truth
- [ ] **Legal Counsel:** Privacy Policy, Terms, Refund Policy approved
- [ ] **Brand Owner:** Logo, favicon, colors, copy approved
- [ ] **Security Review:** No secrets in repo, headers configured, dependencies audited

---

*This audit document should be updated when the live website becomes accessible and actual data can be verified.*